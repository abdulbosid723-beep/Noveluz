# NovelUZ — Catalog-First Premium Platform

Uzbek-language reading platform for web novels, ranobe, manhwa, manga and manhua: cover-rich catalog,
TZ-compliant smart search, immersive reader and a protected admin panel.

Built from the [NovelUZ Master Prompt v3.0](docs/MASTER_PROMPT_v3.md) (approved design: **Option 2 —
premium dark, cover-rich, catalog-first**). Implementation status and real gate evidence live in
[PROGRESS.md](PROGRESS.md); limitations in [docs/KNOWN_ISSUES.md](docs/KNOWN_ISSUES.md).

## Stack

| Layer | Technology                                                                                                  |
| ----- | ----------------------------------------------------------------------------------------------------------- |
| Web   | Next.js 16 App Router, React 19, TypeScript (strict), Tailwind CSS 4, TanStack Query, React Hook Form + Zod |
| API   | Fastify 5, Zod 4 (`fastify-type-provider-zod`), Pino, OpenAPI 3.1 at `/api/openapi.json`                    |
| Data  | PostgreSQL 16+ (`pg_trgm`, `unaccent`, `fuzzystrmatch`, `tsvector`), Prisma 7 (`@prisma/adapter-pg`)        |
| Cache | Redis (optional) with bounded in-process LRU fallback                                                       |
| Auth  | Argon2id, 15-min access JWT + rotating refresh tokens in httpOnly cookies                                   |
| Tests | Vitest (unit + DB-backed integration via Fastify inject), Playwright Chromium E2E                           |

## Repository layout

```text
apps/api        Fastify API, Prisma schema/migrations/seed, tests
apps/web        Next.js App Router site + admin panel, Playwright tests
packages/shared Zod schemas, DTO types, Uzbek dictionary, search normalization
scripts/        verify, placeholder + production-integrity audits, local PostgreSQL, smoke test
docs/           design brief, design system, decisions, API, search, security, deployment guides
```

## Prerequisites

- Linux or macOS (Windows via WSL2), Node.js ≥ 22.12, pnpm 12 (`corepack enable`)
- Docker with Compose v2 **or** the bundled PostgreSQL fallback (Linux x64 only, `pnpm db:local`)

## Quick start

```bash
cp .env.example .env              # local-only values; set SEED_ADMIN_PASSWORD if you want a fixed admin password
pnpm install
pnpm db:up                         # docker compose postgres + redis (falls back to embedded PostgreSQL)
pnpm db:migrate                    # prisma migrate deploy
pnpm db:seed                       # idempotent demo catalog (original works and covers)
pnpm dev                           # API http://localhost:4000 · Web http://localhost:3000
```

The browser only talks to `http://localhost:3000`; `/api/*` is proxied to the API so auth cookies stay first-party.

### Demo administrator

`pnpm db:seed` creates a development-only admin with `SEED_ADMIN_EMAIL`. If `SEED_ADMIN_PASSWORD` is empty a random
password is generated and printed once. Seeding an admin is refused when `NODE_ENV=production`.

## Commands

| Command                                     | What it runs                                                                              |
| ------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `pnpm typecheck`                            | `tsc --noEmit` for shared, API (after `prisma generate`) and web (after `next typegen`)   |
| `pnpm lint`                                 | ESLint (typescript-eslint strict type-checked + Next core-web-vitals)                     |
| `pnpm check:placeholders`                   | scans sources for TODO/FIXME, `any`, `@ts-ignore`, `alert(`, `console.log`, dead handlers |
| `pnpm check:production-integrity`           | anti-fake audit + live HTTP API ↔ PostgreSQL write/restart/read/cleanup                   |
| `pnpm test:unit` / `test:integration`       | Vitest; integration uses a real `TEST_DATABASE_URL` database                              |
| `pnpm test:search` / `test:security`        | search (TZ-01…TZ-08) and security integration suites                                      |
| `pnpm build`                                | shared `tsc`, API `tsc`, web `next build`                                                 |
| `pnpm test:e2e`                             | migrates + seeds the test DB, starts built API + `next start`, runs Playwright Chromium   |
| `pnpm verify`                               | typecheck → lint → placeholders → integrity → unit → integration → build → e2e            |
| `pnpm db:up` / `db:down` / `db:local`       | start/stop databases; `db:local start                                                     | stop | status | run -- <cmd>` |
| `pnpm db:migrate` / `db:seed` / `db:studio` | Prisma migrate deploy / seed / studio                                                     |
| `pnpm perf:seed` / `perf:search`            | 10 000-novel fixture and search p95 benchmark                                             |
| `pnpm smoke`                                | smoke test against running web + API                                                      |

## Troubleshooting

- `Invalid environment configuration` — copy `.env.example` to `.env`; secrets must be ≥ 32 characters.
- `cannot connect to PostgreSQL` — run `pnpm db:up`, check `DATABASE_URL`.
- No Docker: `pnpm db:local start` (Linux x64) runs real PostgreSQL binaries from `.local/pgdata`.
- Redis down: the API logs one warning and continues with the in-memory cache.

import { z } from 'zod';
import { NovelTypeSchema, RoleSchema } from '../constants/enums.js';
import { PageQuerySchema, SlugSchema } from './common.js';

export const AdminNovelListQuerySchema = PageQuerySchema.extend({
  q: z.string().trim().max(100).optional(),
  type: NovelTypeSchema.optional(),
  state: z.enum(['all', 'published', 'draft']).default('all'),
});

export const TaxonomyInputSchema = z.object({
  name: z.string().trim().min(1, 'Nomni kiriting').max(60),
  slug: SlugSchema,
});
export type TaxonomyInput = z.infer<typeof TaxonomyInputSchema>;
export const TaxonomyPatchSchema = TaxonomyInputSchema.partial();

export const AdminUserListQuerySchema = PageQuerySchema.extend({
  q: z.string().trim().max(100).optional(),
  role: RoleSchema.optional(),
  sort: z.enum(['createdAt', 'username', 'lastLoginAt']).default('createdAt'),
});
export const RolePatchSchema = z.object({ role: RoleSchema }).strict();
export const BanPatchSchema = z
  .object({ isBanned: z.boolean(), reason: z.string().trim().max(300).optional() })
  .strict();

export const AdminCommentListQuerySchema = PageQuerySchema.extend({
  novelId: z.uuid().optional(),
  chapterId: z.uuid().optional(),
  spoiler: z.enum(['true', 'false']).optional(),
  state: z.enum(['all', 'active', 'deleted']).default('all'),
});
export const CommentModerateSchema = z
  .object({
    isDeleted: z.boolean().optional(),
    isSpoiler: z.boolean().optional(),
    reason: z.string().trim().min(1, 'Sababni kiriting').max(300),
  })
  .strict();

export const SettingsPatchSchema = z
  .object({
    announcementText: z.string().trim().max(300).nullable().optional(),
    announcementActive: z.boolean().optional(),
    maintenanceMode: z.boolean().optional(),
    maintenanceMessage: z.string().trim().max(500).nullable().optional(),
  })
  .strict();
export type SettingsPatch = z.infer<typeof SettingsPatchSchema>;

export const AuditLogQuerySchema = PageQuerySchema.extend({
  action: z.string().trim().max(80).optional(),
  entityType: z.string().trim().max(40).optional(),
  actorUserId: z.uuid().optional(),
});

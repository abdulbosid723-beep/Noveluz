import { z } from 'zod';
import {
  AgeRatingSchema,
  CatalogSortSchema,
  ChapterKindSchema,
  LIMITS,
  NovelStatusSchema,
  NovelTypeSchema,
  RankingPeriodSchema,
} from '../constants/enums.js';
import { ChapterNumberSchema, PageQuerySchema, SlugSchema } from './common.js';

export const CatalogQuerySchema = PageQuerySchema.extend({
  type: NovelTypeSchema.optional(),
  status: NovelStatusSchema.optional(),
  genre: SlugSchema.optional(),
  tag: SlugSchema.optional(),
  year: z.coerce.number().int().min(1900).max(2100).optional(),
  sort: CatalogSortSchema.default('updated'),
  order: z.enum(['asc', 'desc']).default('desc'),
  q: z.string().trim().max(100).optional(),
});
export type CatalogQuery = z.infer<typeof CatalogQuerySchema>;

export const TopQuerySchema = z.object({
  period: RankingPeriodSchema.default('week'),
  limit: z.coerce.number().int().min(1).max(50).default(10),
});

export const ChapterReadParamsSchema = z.object({
  slug: SlugSchema,
  chapterNumber: ChapterNumberSchema,
});
export const ChapterReadQuerySchema = z.object({
  volume: z.coerce.number().int().min(0).max(999).default(1),
  preview: z.enum(['1']).optional(),
});

export const ViewEventSchema = z.object({
  chapterId: z.uuid().optional(),
});

const AliasNameSchema = z.string().trim().min(1).max(200);

export const NovelInputSchema = z.object({
  title: z.string().trim().min(1, 'Nomni kiriting').max(200),
  slug: SlugSchema,
  description: z.string().trim().min(1, 'Tavsifni kiriting').max(LIMITS.descriptionMaxLength),
  type: NovelTypeSchema,
  status: NovelStatusSchema,
  ageRating: AgeRatingSchema,
  author: z.string().trim().min(1, 'Muallifni kiriting').max(200),
  translatorGroup: z.string().trim().max(200).nullable(),
  releaseYear: z.number().int().min(1900).max(2100).nullable(),
  coverAssetId: z.uuid().nullable(),
  bannerAssetId: z.uuid().nullable(),
  isPublished: z.boolean(),
  isFeatured: z.boolean(),
  featuredOrder: z.number().int().min(0).max(1000).nullable(),
  aliases: z.array(AliasNameSchema).max(LIMITS.aliasesMax),
  genreIds: z.array(z.uuid()).max(30),
  tagIds: z.array(z.uuid()).max(50),
});
export type NovelInput = z.infer<typeof NovelInputSchema>;

export const NovelPatchSchema = NovelInputSchema.partial().extend({
  /** Optimistic concurrency: the `updatedAt` the editor loaded. */
  expectedUpdatedAt: z.iso.datetime().optional(),
});
export type NovelPatch = z.infer<typeof NovelPatchSchema>;

export const AliasesPutSchema = z.object({ aliases: z.array(AliasNameSchema).max(LIMITS.aliasesMax) });
export const FeaturedPatchSchema = z.object({
  isFeatured: z.boolean(),
  featuredOrder: z.number().int().min(0).max(1000).nullable(),
});
export const ContributorsPutSchema = z.object({
  contributors: z
    .array(
      z.object({
        userId: z.uuid(),
        canEditNovel: z.boolean(),
        canEditChapters: z.boolean(),
      }),
    )
    .max(50),
});

export const ChapterPageInputSchema = z.object({
  assetId: z.uuid(),
  altText: z.string().trim().max(300).nullable(),
});

const ChapterBaseSchema = z.object({
  volumeNumber: z.number().int().min(0).max(999),
  chapterNumber: ChapterNumberSchema,
  title: z.string().trim().max(200).nullable(),
  kind: ChapterKindSchema,
  contentText: z.string().max(LIMITS.chapterTextMaxLength).nullable(),
  pages: z.array(ChapterPageInputSchema).max(400),
  isPublished: z.boolean(),
  isVip: z.boolean(),
});

function chapterContentConsistent(v: {
  kind?: 'TEXT' | 'IMAGES' | undefined;
  contentText?: string | null | undefined;
  pages?: unknown[] | undefined;
}): boolean {
  if (v.kind === 'TEXT') return typeof v.contentText === 'string' && v.contentText.trim().length > 0;
  if (v.kind === 'IMAGES') return Array.isArray(v.pages) && v.pages.length > 0;
  return true;
}

export const ChapterInputSchema = ChapterBaseSchema.refine(chapterContentConsistent, {
  message: 'Matnli bob uchun matn, rasmli bob uchun kamida bitta sahifa kerak',
  path: ['contentText'],
});
export type ChapterInput = z.infer<typeof ChapterInputSchema>;

export const ChapterPatchSchema = ChapterBaseSchema.partial()
  .extend({ expectedUpdatedAt: z.iso.datetime().optional() })
  .refine(chapterContentConsistent, {
    message: 'Matnli bob uchun matn, rasmli bob uchun kamida bitta sahifa kerak',
    path: ['contentText'],
  });
export type ChapterPatch = z.infer<typeof ChapterPatchSchema>;

export const BulkChaptersSchema = z.object({
  chapters: z.array(ChapterInputSchema).min(1).max(LIMITS.bulkChaptersMax),
});
export type BulkChaptersInput = z.infer<typeof BulkChaptersSchema>;

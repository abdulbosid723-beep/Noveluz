import { z } from 'zod';
import { LIMITS, ListTypeSchema, ReaderFontSchema, ReaderThemeSchema } from '../constants/enums.js';
import { PageQuerySchema } from './common.js';

export const BookmarkQuerySchema = PageQuerySchema.extend({
  listType: ListTypeSchema.optional(),
});
export const BookmarkPutSchema = z.object({ listType: ListTypeSchema }).strict();

export const ProgressPutSchema = z
  .object({
    chapterId: z.uuid(),
    scrollPercent: z.number().min(0).max(100),
    /** Client timestamp (ms since epoch) — older writes than stored are ignored. */
    clientUpdatedAt: z.number().int().positive(),
  })
  .strict();
export type ProgressPut = z.infer<typeof ProgressPutSchema>;

export const RatingPutSchema = z.object({ score: z.number().int().min(1).max(5) }).strict();

export const CommentListQuerySchema = PageQuerySchema.extend({
  chapterId: z.uuid().optional(),
});
export const CommentCreateSchema = z
  .object({
    body: z.string().trim().min(1, 'Izoh bo‘sh bo‘lmasin').max(LIMITS.commentMaxLength, 'Izoh juda uzun'),
    isSpoiler: z.boolean().default(false),
    chapterId: z.uuid().nullable().optional(),
    parentId: z.uuid().nullable().optional(),
  })
  .strict();
export type CommentCreateInput = z.infer<typeof CommentCreateSchema>;

export const CommentPatchSchema = z
  .object({
    body: z.string().trim().min(1).max(LIMITS.commentMaxLength).optional(),
    isSpoiler: z.boolean().optional(),
  })
  .strict();

export const ReaderPreferenceSchema = z
  .object({
    theme: ReaderThemeSchema,
    fontFamily: ReaderFontSchema,
    fontSize: z.number().int().min(LIMITS.readerFontMin).max(LIMITS.readerFontMax),
    lineHeight: z.number().min(1.3).max(2.2),
    contentWidth: z.number().int().min(560).max(960),
  })
  .strict();
export type ReaderPreferenceInput = z.infer<typeof ReaderPreferenceSchema>;

export const DEFAULT_READER_PREFERENCE: ReaderPreferenceInput = {
  theme: 'DARK',
  fontFamily: 'LITERATA',
  fontSize: 19,
  lineHeight: 1.75,
  contentWidth: 720,
};

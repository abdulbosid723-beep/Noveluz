import { z } from 'zod';
import { LIMITS } from '../constants/enums.js';

export const UuidSchema = z.uuid();
export const IdParamSchema = z.object({ id: z.uuid() });
export const NovelIdParamSchema = z.object({ novelId: z.uuid() });
export const SlugSchema = z
  .string()
  .min(1)
  .max(100)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug faqat kichik lotin harflari, raqam va chiziqchadan iborat bo‘lishi kerak');
export const SlugParamSchema = z.object({ slug: SlugSchema });

export const PageQuerySchema = z.object({
  page: z.coerce.number().int().min(1).max(10_000).default(1),
  limit: z.coerce.number().int().min(1).max(LIMITS.pageSizeMax).default(20),
});

/**
 * Canonical decimal chapter number: `14`, `14.5` (max 2 decimals), never `14.50`.
 */
export const ChapterNumberSchema = z.coerce
  .number()
  .min(0)
  .max(999_999)
  .refine((n) => Math.round(n * 100) === n * 100, 'Bob raqami ko‘pi bilan 2 ta kasr xonaga ega bo‘lishi mumkin');

export function formatChapterNumber(n: number | string): string {
  const value = typeof n === 'string' ? Number(n) : n;
  return String(Math.round(value * 100) / 100);
}

export const BooleanQuerySchema = z.enum(['true', 'false', '1', '0']).transform((v) => v === 'true' || v === '1');

export interface PageMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface ApiSuccess<T, M = PageMeta> {
  data: T;
  meta?: M;
  requestId: string;
}

export interface ApiErrorBody {
  error: {
    code: ApiErrorCode;
    message: string;
    details?: Record<string, unknown>;
  };
  requestId: string;
}

export type ApiErrorCode =
  | 'VALIDATION_ERROR'
  | 'UNAUTHENTICATED'
  | 'FORBIDDEN'
  | 'NOT_FOUND'
  | 'CONFLICT'
  | 'PAYLOAD_TOO_LARGE'
  | 'UNSUPPORTED_MEDIA'
  | 'RATE_LIMITED'
  | 'MAINTENANCE'
  | 'CSRF_REJECTED'
  | 'INTERNAL_ERROR';

export function pageMeta(page: number, limit: number, total: number): PageMeta {
  return { page, limit, total, totalPages: total === 0 ? 0 : Math.ceil(total / limit) };
}

import { z } from 'zod';
import { SearchScopeSchema } from '../constants/enums.js';
import { SEARCH_MAX_RAW_QUERY_LENGTH } from '../search/normalize.js';

export const CatalogSearchQuerySchema = z.object({
  q: z.string().max(SEARCH_MAX_RAW_QUERY_LENGTH, 'So‘rov juda uzun').default(''),
  scope: SearchScopeSchema.default('all'),
  page: z.coerce.number().int().min(1).max(500).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(10),
});
export type CatalogSearchQuery = z.infer<typeof CatalogSearchQuerySchema>;

export const ChapterSearchQuerySchema = z.object({
  q: z.string().max(SEARCH_MAX_RAW_QUERY_LENGTH, 'So‘rov juda uzun').default(''),
  novelId: z.uuid().optional(),
  page: z.coerce.number().int().min(1).max(500).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(10),
});
export type ChapterSearchQuery = z.infer<typeof ChapterSearchQuerySchema>;

export const SuggestionQuerySchema = z.object({
  q: z.string().max(SEARCH_MAX_RAW_QUERY_LENGTH).default(''),
});

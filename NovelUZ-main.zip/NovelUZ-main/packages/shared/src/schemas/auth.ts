import { z } from 'zod';
import { LIMITS } from '../constants/enums.js';

export const UsernameSchema = z
  .string()
  .trim()
  .min(3, 'Foydalanuvchi nomi kamida 3 belgidan iborat bo‘lsin')
  .max(32, 'Foydalanuvchi nomi 32 belgidan oshmasin')
  .regex(/^[a-zA-Z0-9_.]+$/, 'Faqat lotin harflari, raqamlar, nuqta va pastki chiziq');

export const EmailSchema = z.string().trim().max(254).pipe(z.email('Elektron pochta manzili noto‘g‘ri'));

export const PasswordSchema = z
  .string()
  .min(10, 'Parol kamida 10 belgidan iborat bo‘lsin')
  .max(128, 'Parol juda uzun')
  .refine((p) => /[a-zA-Z]/.test(p) && /\d/.test(p), 'Parolda kamida bitta harf va bitta raqam bo‘lsin');

export const RegisterSchema = z.object({
  username: UsernameSchema,
  email: EmailSchema,
  password: PasswordSchema,
});
export type RegisterInput = z.infer<typeof RegisterSchema>;

export const LoginSchema = z.object({
  login: z.string().trim().min(3, 'Login yoki pochtani kiriting').max(254),
  password: z.string().min(1, 'Parolni kiriting').max(128),
});
export type LoginInput = z.infer<typeof LoginSchema>;

export const ProfileUpdateSchema = z
  .object({
    username: UsernameSchema.optional(),
    bio: z.string().trim().max(LIMITS.bioMaxLength, 'Bio juda uzun').nullable().optional(),
    avatarAssetId: z.uuid().nullable().optional(),
  })
  .strict();
export type ProfileUpdateInput = z.infer<typeof ProfileUpdateSchema>;

export const PasswordChangeSchema = z
  .object({
    currentPassword: z.string().min(1, 'Joriy parolni kiriting').max(128),
    newPassword: PasswordSchema,
  })
  .strict()
  .refine((v) => v.currentPassword !== v.newPassword, {
    message: 'Yangi parol joriy paroldan farq qilishi kerak',
    path: ['newPassword'],
  });
export type PasswordChangeInput = z.infer<typeof PasswordChangeSchema>;

/** Validates a post-login return path against open redirects. */
export function safeReturnPath(value: string | null | undefined): string {
  if (!value) return '/';
  if (!value.startsWith('/') || value.startsWith('//') || value.startsWith('/\\')) return '/';
  if (/[\r\n]/.test(value)) return '/';
  return value.slice(0, 512);
}

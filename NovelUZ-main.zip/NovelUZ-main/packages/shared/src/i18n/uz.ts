import type { AgeRating, ListType, NovelStatus, NovelType, Role } from '../constants/enums.js';
import type { MatchType } from '../search/ranking.js';

export const typeLabels: Readonly<Record<NovelType, string>> = {
  NOVEL: 'Novel',
  MANHWA: 'Manhwa',
  MANGA: 'Manga',
  MANHUA: 'Manhua',
};

export const statusLabels: Readonly<Record<NovelStatus, string>> = {
  ONGOING: 'Davom etmoqda',
  COMPLETED: 'Yakunlangan',
  HIATUS: 'Tanaffusda',
  DROPPED: 'To‘xtatilgan',
};

export const ageLabels: Readonly<Record<AgeRating, string>> = {
  ALL: '0+',
  AGE_12: '12+',
  AGE_16: '16+',
  AGE_18: '18+',
};

export const listTypeLabels: Readonly<Record<ListType, string>> = {
  READING: 'O‘qiyapman',
  PLANNED: 'Rejada',
  COMPLETED: 'Tugatdim',
  DROPPED: 'Tashladim',
  FAVORITE: 'Sevimlilar',
};

export const roleLabels: Readonly<Record<Role, string>> = {
  READER: 'O‘quvchi',
  TRANSLATOR: 'Tarjimon',
  MODERATOR: 'Moderator',
  ADMIN: 'Administrator',
};

export const matchTypeLabels: Readonly<Record<MatchType, string>> = {
  EXACT_TITLE: 'Aniq nom',
  EXACT_ALIAS: 'Muqobil nom',
  TYPO: 'Imlo o‘xshashligi',
  PREFIX: 'Nomning boshi',
  SUBSTRING: 'Matndagi moslik',
  TAXONOMY: 'Janr yoki teg',
};

export const errorMessages = {
  VALIDATION_ERROR: 'Kiritilgan ma’lumotlar noto‘g‘ri',
  UNAUTHENTICATED: 'Avval tizimga kiring',
  FORBIDDEN: 'Bu amal uchun ruxsatingiz yo‘q',
  NOT_FOUND: 'Topilmadi',
  CONFLICT: 'Ma’lumot allaqachon mavjud yoki boshqa joyda o‘zgartirilgan',
  PAYLOAD_TOO_LARGE: 'Fayl juda katta',
  UNSUPPORTED_MEDIA: 'Fayl turi qo‘llab-quvvatlanmaydi',
  RATE_LIMITED: 'Juda ko‘p so‘rov yuborildi. Birozdan so‘ng qayta urinib ko‘ring',
  MAINTENANCE: 'Saytda texnik ishlar olib borilmoqda',
  CSRF_REJECTED: 'So‘rov manbasi tasdiqlanmadi',
  INTERNAL_ERROR: 'Kutilmagan xatolik yuz berdi',
} as const;

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/** Uzbek relative time (`3 soat oldin`, `kecha`) rendered for Asia/Tashkent. */
export function relativeTimeUz(iso: string, now: Date = new Date()): string {
  const then = new Date(iso);
  const diff = now.getTime() - then.getTime();
  if (Number.isNaN(diff)) return '';
  if (diff < MINUTE) return 'hozirgina';
  if (diff < HOUR) return `${Math.floor(diff / MINUTE)} daqiqa oldin`;
  if (diff < DAY) return `${Math.floor(diff / HOUR)} soat oldin`;
  if (diff < 2 * DAY) return 'kecha';
  if (diff < 7 * DAY) return `${Math.floor(diff / DAY)} kun oldin`;
  if (diff < 30 * DAY) return `${Math.floor(diff / (7 * DAY))} hafta oldin`;
  return formatDateUz(iso);
}

const MONTHS = [
  'yanvar',
  'fevral',
  'mart',
  'aprel',
  'may',
  'iyun',
  'iyul',
  'avgust',
  'sentabr',
  'oktabr',
  'noyabr',
  'dekabr',
];

export function formatDateUz(iso: string): string {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Tashkent',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(new Date(iso));
  const get = (t: string): string => parts.find((p) => p.type === t)?.value ?? '';
  const monthIndex = Number(get('month')) - 1;
  return `${Number(get('day'))}-${MONTHS[monthIndex] ?? ''}, ${get('year')}`;
}

export function formatCountUz(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace('.0', '')} mln`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1).replace('.0', '')} ming`;
  return String(n);
}

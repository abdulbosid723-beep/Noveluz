import { describe, expect, it } from 'vitest';
import { compactText, levenshtein, maxTypoEdits, normalizeText, prepareQuery, slugify } from './normalize.js';
import { safeReturnPath } from '../schemas/auth.js';

describe('normalizeText', () => {
  it('lowercases, trims and collapses whitespace', () => {
    expect(normalizeText('  Solo   LEVELING  ')).toBe('solo leveling');
  });

  it('transliterates Russian-style Cyrillic to Latin (TZ-05)', () => {
    expect(normalizeText('Соло Левелинг')).toBe('solo leveling');
  });

  it('maps Uzbek-specific Cyrillic letters', () => {
    expect(normalizeText('Ўлмас қирол')).toBe('olmas qirol');
    expect(normalizeText('Ғалаба ҳикояси')).toBe('galaba hikoyasi');
    expect(normalizeText('шаҳар чироқлари')).toBe('shahar chiroqlari');
    expect(normalizeText('ёшлик юлдузи ярим')).toBe('yoshlik yulduzi yarim');
    expect(normalizeText('жаннат')).toBe('jannat');
  });

  it('treats every apostrophe variant of oʻ and gʻ identically (TZ-05)', () => {
    const variants = ['Oʻlmas qirol', "O'lmas qirol", 'O’lmas qirol', 'O`lmas qirol', 'Oʼlmas qirol', 'O‘lmas qirol'];
    for (const v of variants) expect(normalizeText(v)).toBe('olmas qirol');
    expect(normalizeText('Gʻalaba')).toBe(normalizeText('Ғалаба'));
  });

  it('removes tutuq belgisi and the Cyrillic hard sign consistently', () => {
    expect(normalizeText('Maʼno')).toBe('mano');
    expect(normalizeText('Маъно')).toBe('mano');
  });

  it('normalizes hyphen variants and punctuation to word boundaries', () => {
    expect(normalizeText('Qora–qal’a: ilk bob!!')).toBe('qora qala ilk bob');
    expect(normalizeText('tun_yulduzi—2')).toBe('tun yulduzi 2');
  });

  it('strips accents but keeps digits', () => {
    expect(normalizeText('Café Noir 2049')).toBe('cafe noir 2049');
  });

  it('handles mixed scripts in one string', () => {
    expect(normalizeText('Solo левелинг')).toBe('solo leveling');
  });

  it('returns empty string for punctuation-only input', () => {
    expect(normalizeText('  ?!… —  ')).toBe('');
  });
});

describe('compactText / slugify', () => {
  it('removes spaces for glued-word matching', () => {
    expect(compactText('Solo Leveling')).toBe('sololeveling');
  });
  it('creates url-safe slugs', () => {
    expect(slugify('Oʻlmas qirol: 2-qism')).toBe('olmas-qirol-2-qism');
  });
});

describe('prepareQuery', () => {
  it('strips a credible content-type suffix as a soft hint', () => {
    const q = prepareQuery('Solo Leveling manhwa');
    expect(q.text).toBe('solo leveling');
    expect(q.typeHint).toBe('MANHWA');
    expect(q.raw).toBe('solo leveling manhwa');
  });

  it('keeps the suffix when no credible base title remains', () => {
    const q = prepareQuery('ab manga');
    expect(q.text).toBe('ab manga');
    expect(q.typeHint).toBeNull();
    expect(prepareQuery('manga').text).toBe('manga');
  });

  it('flags empty normalized queries', () => {
    expect(prepareQuery('   ').isEmpty).toBe(true);
    expect(prepareQuery('!!!').isEmpty).toBe(true);
  });

  it('truncates overly long input to the documented maximum', () => {
    expect(prepareQuery('a'.repeat(500)).text.length).toBe(120);
  });
});

describe('fuzzy helpers', () => {
  it('scales the typo budget with length', () => {
    expect(maxTypoEdits(3)).toBe(0);
    expect(maxTypoEdits(4)).toBe(0);
    expect(maxTypoEdits(6)).toBe(1);
    expect(maxTypoEdits(12)).toBe(2);
  });

  it('computes Levenshtein distance', () => {
    expect(levenshtein('solo leving', 'solo leveling')).toBe(2);
    expect(levenshtein('sololevelingg', 'sololeveling')).toBe(1);
    expect(levenshtein('', 'abc')).toBe(3);
    expect(levenshtein('abc', 'abc')).toBe(0);
  });
});

describe('safeReturnPath', () => {
  it('accepts local paths only', () => {
    expect(safeReturnPath('/novel/abc')).toBe('/novel/abc');
    expect(safeReturnPath('https://evil.example')).toBe('/');
    expect(safeReturnPath('//evil.example')).toBe('/');
    expect(safeReturnPath('/\\evil.example')).toBe('/');
    expect(safeReturnPath(undefined)).toBe('/');
  });
});

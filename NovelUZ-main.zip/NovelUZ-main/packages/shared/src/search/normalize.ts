/**
 * Uzbek-aware text normalization shared by the API (stored search columns)
 * and by every incoming search query. The SAME function must be applied to
 * both sides; see docs/SEARCH.md for the full mapping table.
 *
 * Lossy decisions (documented): `oʻ → o`, `gʻ → g`, `ў → o`, `ғ → g`,
 * tutuq belgisi (ʼ / ъ) is removed, Cyrillic `х → x` (Uzbek Latin convention),
 * `ҳ → h`, `ц → ts`, `щ → sh`.
 */

const CYRILLIC_TO_LATIN: Readonly<Record<string, string>> = {
  а: 'a',
  б: 'b',
  в: 'v',
  г: 'g',
  д: 'd',
  е: 'e',
  ё: 'yo',
  ж: 'j',
  з: 'z',
  и: 'i',
  й: 'y',
  к: 'k',
  л: 'l',
  м: 'm',
  н: 'n',
  о: 'o',
  п: 'p',
  р: 'r',
  с: 's',
  т: 't',
  у: 'u',
  ф: 'f',
  х: 'x',
  ц: 'ts',
  ч: 'ch',
  ш: 'sh',
  щ: 'sh',
  ъ: '',
  ы: 'i',
  ь: '',
  э: 'e',
  ю: 'yu',
  я: 'ya',
  ў: 'o',
  ғ: 'g',
  қ: 'q',
  ҳ: 'h',
  і: 'i',
  ї: 'yi',
  є: 'ye',
  ң: 'ng',
  ә: 'a',
  ө: 'o',
  ү: 'u',
};

/** Every apostrophe-like character used for oʻ, gʻ and the tutuq belgisi. */
const APOSTROPHES = /[\u0027\u0060\u00B4\u02B9\u02BB\u02BC\u02BD\u02BE\u02BF\u2018\u2019\u201B\u2032]/g;
const COMBINING_MARKS = /\p{M}+/gu;
const NON_ALNUM = /[^\p{L}\p{N}]+/gu;
const WHITESPACE = /\s+/g;

export const SEARCH_MAX_QUERY_LENGTH = 120;
export const SEARCH_MAX_RAW_QUERY_LENGTH = 200;

function transliterate(input: string): string {
  let out = '';
  for (const ch of input) {
    const mapped = CYRILLIC_TO_LATIN[ch];
    out += mapped ?? ch;
  }
  return out;
}

/** Canonical normalized form: lowercase Latin words separated by single spaces. */
export function normalizeText(input: string): string {
  const lowered = input.normalize('NFKC').toLowerCase();
  const latin = transliterate(lowered).replace(APOSTROPHES, '');
  const unaccented = latin.normalize('NFD').replace(COMBINING_MARKS, '').normalize('NFC');
  return unaccented.replace(NON_ALNUM, ' ').replace(WHITESPACE, ' ').trim();
}

/** Space-free variant used for glued-word typo matching (`sololevelingg`). */
export function compactText(input: string): string {
  return normalizeText(input).replace(/ /g, '');
}

/** URL-safe slug derived from the normalized form. */
export function slugify(input: string): string {
  return normalizeText(input).replace(/ /g, '-').slice(0, 96).replace(/-+$/g, '');
}

export type SearchTypeHint = 'NOVEL' | 'MANHWA' | 'MANGA' | 'MANHUA';

const TYPE_SUFFIXES: Readonly<Record<string, SearchTypeHint>> = {
  manhwa: 'MANHWA',
  manxva: 'MANHWA',
  manhva: 'MANHWA',
  manga: 'MANGA',
  manhua: 'MANHUA',
  manxua: 'MANHUA',
  novel: 'NOVEL',
  novella: 'NOVEL',
  ranobe: 'NOVEL',
  roman: 'NOVEL',
};

/** Minimum length of the remaining base title for a suffix to be stripped. */
const MIN_BASE_AFTER_SUFFIX = 3;

export interface PreparedQuery {
  /** Normalized full query, as typed. */
  readonly raw: string;
  /** Normalized query used for matching (suffix removed when credible). */
  readonly text: string;
  readonly compact: string;
  readonly typeHint: SearchTypeHint | null;
  readonly isEmpty: boolean;
}

export function prepareQuery(input: string): PreparedQuery {
  const raw = normalizeText(input).slice(0, SEARCH_MAX_QUERY_LENGTH).trim();
  let text = raw;
  let typeHint: SearchTypeHint | null = null;
  const lastSpace = raw.lastIndexOf(' ');
  if (lastSpace > 0) {
    const suffix = raw.slice(lastSpace + 1);
    const base = raw.slice(0, lastSpace).trim();
    const hint = TYPE_SUFFIXES[suffix];
    if (hint && base.replace(/ /g, '').length >= MIN_BASE_AFTER_SUFFIX) {
      text = base;
      typeHint = hint;
    }
  }
  return { raw, text, compact: text.replace(/ /g, ''), typeHint, isEmpty: text.length === 0 };
}

/**
 * Maximum Levenshtein distance accepted for tier-3 typo matches, based on the
 * compact query length. Short queries never fuzzy-match (prevents a 3-letter
 * query matching unrelated short titles).
 */
export function maxTypoEdits(compactLength: number): number {
  if (compactLength <= 4) return 0;
  if (compactLength <= 8) return 1;
  return 2;
}

/** Plain JS Levenshtein used by unit tests and suggestion post-filtering. */
export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    const cur = [i];
    for (let j = 1; j <= b.length; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      const del = (prev[j] ?? 0) + 1;
      const ins = (cur[j - 1] ?? 0) + 1;
      const sub = (prev[j - 1] ?? 0) + cost;
      cur.push(Math.min(del, ins, sub));
    }
    prev = cur;
  }
  return prev[b.length] ?? 0;
}

/** Match tiers (lower is better). Tier order is lexicographic and always wins over score. */
export const MATCH_TIERS = {
  EXACT_TITLE: 1,
  EXACT_ALIAS: 2,
  TYPO: 3,
  PREFIX: 4,
  SUBSTRING: 5,
  TAXONOMY: 6,
} as const;

export type MatchType = keyof typeof MATCH_TIERS;

export type MatchField = 'title' | 'alias' | 'author' | 'translatorGroup' | 'genre' | 'tag' | 'description';

export const MATCH_TYPES: readonly MatchType[] = [
  'EXACT_TITLE',
  'EXACT_ALIAS',
  'TYPO',
  'PREFIX',
  'SUBSTRING',
  'TAXONOMY',
];

export function tierToMatchType(tier: number): MatchType {
  const found = MATCH_TYPES.find((t) => MATCH_TIERS[t] === tier);
  return found ?? 'TAXONOMY';
}

/**
 * Score bands per tier (displayScore is a 0–100 relevance score, NOT a
 * probability). Bands never overlap, so score order agrees with tier order.
 */
export const SCORE_BANDS: Readonly<Record<MatchType, { readonly min: number; readonly max: number }>> = {
  EXACT_TITLE: { min: 100, max: 100 },
  EXACT_ALIAS: { min: 94, max: 96 },
  TYPO: { min: 80, max: 90 },
  PREFIX: { min: 66, max: 78 },
  SUBSTRING: { min: 48, max: 64 },
  TAXONOMY: { min: 25, max: 45 },
};

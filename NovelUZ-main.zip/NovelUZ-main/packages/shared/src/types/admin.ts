import type { AgeRating, ChapterKind, NovelStatus, NovelType, Role } from '../constants/enums.js';
import type { AssetRef, ChapterPageDto, TaxonomyRef } from './dto.js';

export interface AdminStats {
  novels: { published: number; draft: number };
  chapters: { published: number; draft: number };
  users: { total: number; banned: number };
  views: { total: number; last7Days: number };
  search: {
    sampleCount: number;
    p50Ms: number | null;
    p95Ms: number | null;
    cacheHitRatio: number | null;
  };
  recentChapters: Array<{
    id: string;
    novelTitle: string;
    novelId: string;
    chapterNumber: string;
    volumeNumber: number;
    publishedAt: string;
  }>;
}

export interface ZeroResultQuery {
  normalizedQuery: string;
  count: number;
  lastSeenAt: string;
}

export interface AdminNovelRow {
  id: string;
  slug: string;
  title: string;
  type: NovelType;
  status: NovelStatus;
  isPublished: boolean;
  isFeatured: boolean;
  featuredOrder: number | null;
  chapterCount: number;
  draftChapterCount: number;
  cover: AssetRef | null;
  updatedAt: string;
}

export interface AdminNovelDetail {
  id: string;
  slug: string;
  title: string;
  description: string;
  type: NovelType;
  status: NovelStatus;
  ageRating: AgeRating;
  author: string;
  translatorGroup: string | null;
  releaseYear: number | null;
  cover: AssetRef | null;
  banner: AssetRef | null;
  isPublished: boolean;
  isFeatured: boolean;
  featuredOrder: number | null;
  aliases: string[];
  genres: TaxonomyRef[];
  tags: TaxonomyRef[];
  contributors: Array<{ userId: string; username: string; canEditNovel: boolean; canEditChapters: boolean }>;
  updatedAt: string;
  duplicateAliasWarnings: Array<{ alias: string; otherNovelTitle: string }>;
}

export interface AdminChapterDetail {
  id: string;
  novelId: string;
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  kind: ChapterKind;
  contentText: string | null;
  pages: ChapterPageDto[];
  isPublished: boolean;
  isVip: boolean;
  wordCount: number;
  updatedAt: string;
}

export interface BulkChapterResult {
  created: number;
  failed: Array<{ index: number; chapterNumber: string; message: string }>;
}

export interface TaxonomyRow extends TaxonomyRef {
  usageCount: number;
}

export interface AdminUserRow {
  id: string;
  username: string;
  email: string;
  role: Role;
  isBanned: boolean;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface AdminCommentRow {
  id: string;
  body: string;
  isSpoiler: boolean;
  isDeleted: boolean;
  createdAt: string;
  user: { id: string; username: string };
  novel: { id: string; title: string; slug: string };
  chapter: { id: string; chapterNumber: string; volumeNumber: number } | null;
}

export interface AuditLogRow {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  metadata: Record<string, unknown>;
  createdAt: string;
  actor: { id: string; username: string } | null;
}

export interface ReindexJobDto {
  id: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCEEDED' | 'FAILED';
  processed: number;
  total: number;
  error: string | null;
  createdAt: string;
  finishedAt: string | null;
}

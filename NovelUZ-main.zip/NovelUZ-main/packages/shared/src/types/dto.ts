import type { AgeRating, ChapterKind, ListType, NovelStatus, NovelType, Role } from '../constants/enums.js';
import type { MatchField, MatchType } from '../search/ranking.js';
import type { ReaderPreferenceInput } from '../schemas/social.js';

export interface AssetRef {
  id: string;
  url: string;
  width: number | null;
  height: number | null;
}

export interface TaxonomyRef {
  id: string;
  slug: string;
  name: string;
}

export interface ChapterPointer {
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  publishedAt: string | null;
}

export interface NovelCard {
  id: string;
  slug: string;
  title: string;
  type: NovelType;
  status: NovelStatus;
  ageRating: AgeRating;
  author: string;
  cover: AssetRef | null;
  ratingAvg: number;
  ratingCount: number;
  viewsCount: number;
  chapterCount: number;
  genres: TaxonomyRef[];
  latestChapter: ChapterPointer | null;
  updatedAt: string;
}

export interface FeaturedNovel extends NovelCard {
  excerpt: string;
  banner: AssetRef | null;
  firstChapter: ChapterPointer | null;
}

export interface ChapterListItem {
  id: string;
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  kind: ChapterKind;
  isVip: boolean;
  isPublished: boolean;
  wordCount: number;
  viewsCount: number;
  publishedAt: string | null;
}

export interface ViewerNovelState {
  bookmark: { listType: ListType; lastReadChapterId: string | null; scrollPercent: number } | null;
  rating: number | null;
}

export interface NovelDetail extends NovelCard {
  description: string;
  aliases: string[];
  translatorGroup: string | null;
  releaseYear: number | null;
  banner: AssetRef | null;
  tags: TaxonomyRef[];
  chapters: ChapterListItem[];
  publishedAt: string | null;
  viewer: ViewerNovelState | null;
}

export interface ChapterPageDto {
  id: string;
  position: number;
  altText: string | null;
  image: AssetRef;
}

export interface ChapterRead {
  id: string;
  novel: { id: string; slug: string; title: string; type: NovelType; cover: AssetRef | null };
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  kind: ChapterKind;
  isVip: boolean;
  isPublished: boolean;
  wordCount: number;
  publishedAt: string | null;
  contentText: string | null;
  pages: ChapterPageDto[];
  prev: ChapterPointer | null;
  next: ChapterPointer | null;
}

export interface LatestChapterItem {
  id: string;
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  isVip: boolean;
  publishedAt: string;
  novel: { id: string; slug: string; title: string; type: NovelType; cover: AssetRef | null };
}

export interface RankingItem extends NovelCard {
  rank: number;
  periodViews: number;
}

export interface SearchHit {
  novel: NovelCard;
  matchType: MatchType;
  matchField: MatchField;
  matchedText: string;
  tier: number;
  displayScore: number;
}

export interface SearchSuggestion {
  slug: string;
  title: string;
  type: NovelType;
}

export interface CatalogSearchResult {
  results: SearchHit[];
  suggestions: SearchSuggestion[];
}

export interface SearchMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  latencyMs: number;
  cacheHit: boolean;
  typeHint: NovelType | null;
  normalizedQuery: string;
}

export interface SnippetSegment {
  text: string;
  highlight: boolean;
}

export interface ChapterSearchHit {
  chapterId: string;
  volumeNumber: number;
  chapterNumber: string;
  title: string | null;
  novel: { id: string; slug: string; title: string; type: NovelType };
  snippet: SnippetSegment[];
  rank: number;
}

export interface PublicUser {
  id: string;
  username: string;
  role: Role;
  avatar: AssetRef | null;
  bio: string | null;
  createdAt: string;
}

export interface MeUser extends PublicUser {
  email: string;
  lastLoginAt: string | null;
  readerPreference: ReaderPreferenceInput | null;
}

export interface CommentItem {
  id: string;
  novelId: string;
  chapterId: string | null;
  parentId: string | null;
  depth: number;
  body: string | null;
  isSpoiler: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  edited: boolean;
  user: { id: string; username: string; avatar: AssetRef | null } | null;
  likesCount: number;
  likedByMe: boolean;
  replies: CommentItem[];
}

export interface BookmarkItem {
  listType: ListType;
  scrollPercent: number;
  updatedAt: string;
  lastReadChapter: ChapterPointer | null;
  novel: NovelCard;
}

export interface ContinueReadingItem {
  novel: NovelCard;
  chapter: ChapterPointer;
  scrollPercent: number;
  updatedAt: string;
}

export interface SiteSettingsDto {
  announcementText: string | null;
  announcementActive: boolean;
  maintenanceMode: boolean;
  maintenanceMessage: string | null;
  updatedAt: string;
}

export interface UploadDto extends AssetRef {
  mimeType: string;
  bytes: number;
  sha256: string;
  createdAt: string;
}

import { z } from 'zod';

export const NOVEL_TYPES = ['NOVEL', 'MANHWA', 'MANGA', 'MANHUA'] as const;
export const NOVEL_STATUSES = ['ONGOING', 'COMPLETED', 'HIATUS', 'DROPPED'] as const;
export const AGE_RATINGS = ['ALL', 'AGE_12', 'AGE_16', 'AGE_18'] as const;
export const ROLES = ['READER', 'TRANSLATOR', 'MODERATOR', 'ADMIN'] as const;
export const CHAPTER_KINDS = ['TEXT', 'IMAGES'] as const;
export const LIST_TYPES = ['READING', 'PLANNED', 'COMPLETED', 'DROPPED', 'FAVORITE'] as const;
export const READER_THEMES = ['DARK', 'LIGHT', 'SEPIA'] as const;
export const READER_FONTS = ['LITERATA', 'JAKARTA', 'SYSTEM_SERIF'] as const;
export const SEARCH_SCOPES = ['all', 'NOVEL', 'MANHWA', 'MANGA', 'MANHUA', 'AUTHOR'] as const;
export const RANKING_PERIODS = ['day', 'week', 'month'] as const;
export const CATALOG_SORTS = ['updated', 'rating', 'views', 'chapters', 'title'] as const;

export const NovelTypeSchema = z.enum(NOVEL_TYPES);
export const NovelStatusSchema = z.enum(NOVEL_STATUSES);
export const AgeRatingSchema = z.enum(AGE_RATINGS);
export const RoleSchema = z.enum(ROLES);
export const ChapterKindSchema = z.enum(CHAPTER_KINDS);
export const ListTypeSchema = z.enum(LIST_TYPES);
export const ReaderThemeSchema = z.enum(READER_THEMES);
export const ReaderFontSchema = z.enum(READER_FONTS);
export const SearchScopeSchema = z.enum(SEARCH_SCOPES);
export const RankingPeriodSchema = z.enum(RANKING_PERIODS);
export const CatalogSortSchema = z.enum(CATALOG_SORTS);

export type NovelType = z.infer<typeof NovelTypeSchema>;
export type NovelStatus = z.infer<typeof NovelStatusSchema>;
export type AgeRating = z.infer<typeof AgeRatingSchema>;
export type Role = z.infer<typeof RoleSchema>;
export type ChapterKind = z.infer<typeof ChapterKindSchema>;
export type ListType = z.infer<typeof ListTypeSchema>;
export type ReaderTheme = z.infer<typeof ReaderThemeSchema>;
export type ReaderFont = z.infer<typeof ReaderFontSchema>;
export type SearchScope = z.infer<typeof SearchScopeSchema>;
export type RankingPeriod = z.infer<typeof RankingPeriodSchema>;
export type CatalogSort = z.infer<typeof CatalogSortSchema>;

export const STAFF_ROLES: readonly Role[] = ['TRANSLATOR', 'MODERATOR', 'ADMIN'];

export const LIMITS = {
  pageSizeMax: 60,
  commentMaxLength: 4000,
  commentMaxDepth: 3,
  bioMaxLength: 500,
  descriptionMaxLength: 6000,
  chapterTextMaxLength: 400_000,
  uploadMaxBytes: 8 * 1024 * 1024,
  uploadMaxPixels: 40_000_000,
  aliasesMax: 30,
  bulkChaptersMax: 50,
  readerFontMin: 14,
  readerFontMax: 28,
} as const;

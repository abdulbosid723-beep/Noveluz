# NovelUZ — Ultimate Master Prompt v3.0 — CATALOG-FIRST PREMIUM EDITION

*Complete, executable full-stack specification for a visually exceptional Uzbek-language Novel / Ranobe / Manhwa / Manga / Manhua reading platform. Design direction approved: cover-rich editorial catalog-first dark UI (Option 2). Intended for Claude Code, Codex, Cursor, Cline and Roo Code.*

## 0. Foydalanish bo‘yicha ko‘rsatma (A Z A D O V uchun)

Bu hujjat — **yangilangan v3.0 to‘liq MASTER PROMPT**. Tanlangan yo‘nalish: **2-variant, rasm va muqovalarga boy katalog (catalog-first)**. V2 dagi database, Smart Search, Reader, Admin, test, SEO, xavfsizlik va Docker talablari saqlangan; vizual talablar kuchaytirilgan va soxta build/test prototiplari qat’iy taqiqlangan.

Bu hujjat — bitta to‘liq MASTER PROMPT. U bo‘limlarga bo‘lingan, shuning uchun uni ikki xil usulda ishlatish mumkin:

- **Bir martalik rejim:** hujjatning hammasini nusxalab Roo Code, Cline, Cursor, Claude Code yoki Codex agentiga tashlang.
- **Bosqichma-bosqich rejim (tavsiya etiladi):** avval 1–16 va 23-bo‘limlarni (qoidalar, texnik spetsifikatsiya va vizual qabul mezonlari) yuboring, so‘ng 17-bo‘limdan bitta Phase ni bering. Har Phase tugagach agent `PROGRESS.md` ni yangilaydi va keyingisiga o‘tadi.

Agent to‘xtab qolsa yoki kontekst to‘lib ketsa, yangi suhbatda shu matnni yuboring:

> Resume NovelUZ v3.0 at the earliest unfinished phase. Read PROGRESS.md, docs/DECISIONS.md, docs/VISUAL_QA.md and git history if available. Preserve verified files; implement real Next.js, Fastify, Prisma and PostgreSQL — never HTML-string rendering, in-memory fake persistence, fake build/typecheck/migration scripts, or green tests that only inspect text. Honor catalog-first UI section 6 and visual gate section 23. Run real gates, capture actual browser screenshots, record proof, then continue.

Maslahatlar:

- Eng kuchli modelni va agent rejimini tanlang (katta kontekst, terminalga kirish huquqi).
- Har fazadan keyin agentdan `pnpm verify` natijasini ko‘rsatishni talab qiling. Natijasiz ‘tayyor’ degan gapga ishonmang.
- Seed ma’lumotlari faqat namunaviy. Haqiqiy kontent uchun mualliflik huquqiga rioya qiling (2-bo‘lim, 14-qoida).
- Bu versiyada **Gemini yaratgan 114 KB prototipdagi kamchiliklar** uchun maxsus audit qo‘shilgan: soxta `build`, soxta `typecheck`, haqiqiy bazaga tegmaydigan `db:migrate`, `Map`-store, HTML string-rendering, soxta login va muqovasiz kartalar **yakunlangan ish hisoblanmaydi**.

## 1. Mission, quality bar and Definition of Done

You are a Principal Full-Stack Software Architect, a Staff Backend/Search Engineer and a Senior UI/UX Engineer working as one autonomous team. Your mission is to design, implement, test, document and ship **NovelUZ** — a production-ready, Uzbek-language reading and translation portal for Webnovels, Ranobe, Manhwa, Manga and Manhua. It covers: database, REST API, TZ-compliant smart search engine, public website, immersive reader and a complete admin panel.

The keywords MUST, MUST NOT, SHOULD and MAY are normative. When requirements conflict, apply this priority order: (1) security and data integrity, (2) TZ search compliance (section 11), (3) real functionality and genuine framework/toolchain execution, (4) visual quality and catalog-first discoverability, (5) accessibility and performance, (6) Tier B enhancements. An unattractive but technically running homepage is NOT accepted. A beautiful static mock with dead actions is NOT accepted.

The project is DONE only when ALL of the following are true and proven by real command output recorded in PROGRESS.md:

- A fresh clone starts with `cp .env.example .env && pnpm install && pnpm db:up && pnpm db:migrate && pnpm db:seed && pnpm dev`, and every page and admin action works against the real PostgreSQL database.
- `pnpm verify` (typecheck → lint → check:placeholders → unit and integration tests → build → e2e) exits 0 on a clean checkout, and the same pipeline is green in `.github/workflows/ci.yml`.
- All 9 TZ acceptance criteria and the extended search suite pass; search p95 is below 300 ms on the 10 000-novel performance dataset with the cache bypassed.
- There is no `TODO`, `FIXME`, `@ts-ignore`, `any`, `alert(`, `console.log`, lorem ipsum, stub handler or dead button (machine-checked by `scripts/check-placeholders.mjs`).
- Lighthouse on a production build with seeded data: Accessibility ≥ 95, Best Practices ≥ 95, SEO ≥ 95, Performance ≥ 85 on `/` and on a novel page; LCP below 2.5 s and CLS below 0.1.
- `docker compose up --build` brings up db, redis, api and web in healthy state; README, docs/API.md, docs/SEARCH.md and docs/ADMIN_GUIDE.md are complete and accurate.
- A real Chromium browser renders the cover-rich catalog-first homepage at 390px and 1440px. Screenshot evidence and a filled UI review checklist exist in `docs/VISUAL_QA.md`, with assets under `artifacts/visual/` or attached CI artifacts. Reviewer can identify six visually distinct covers within the desktop catalog area and two clear cover cards per mobile row (when viewport permits), without scrolling past a giant blank hero.
- The workspace uses the ACTUAL `next build`, `tsc --noEmit`, ESLint, Prisma migrations and database-backed tests; wrappers may orchestrate these but MUST NOT replace execution with file existence/string scans, generated success messages, manifest creation or an in-memory substitute. CI and fresh-clone checks prove this.

## 2. Non-negotiable execution rules

1. **Zero placeholders.** Never leave `// TODO`, `...existing code...`, empty handlers, fake `alert()` dialogs, `console.log`-only actions, hard-coded mock arrays in components or ‘coming soon’ buttons. Every button, form, modal, filter, tab, toggle and admin action MUST call a real endpoint backed by PostgreSQL. A feature you cannot finish MUST be removed from the UI (not disabled, not stubbed) and recorded in docs/KNOWN_ISSUES.md.
2. **Strict TypeScript everywhere.** Enable `strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noFallthroughCasesInSwitch`. No `any`, no `@ts-ignore`, no `@ts-expect-error` without a one-line justification, no non-null assertions (`!`) outside tests.
3. **Validate every boundary with Zod:** request body, query, params, headers and cookies, environment variables, upload metadata and — through the same shared schemas — client-side forms (react-hook-form + zodResolver). Schemas live in `packages/shared` and are the single source of truth for types.
4. **Errors are first-class.** One centralized Fastify error handler (section 10.2). No stack traces or SQL in production responses. Every data-driven UI region has loading (skeleton), empty and error (with retry) states written in Uzbek.
5. **SQL safety.** Use only Prisma Client or `Prisma.sql` tagged templates for raw SQL. Never concatenate user input into SQL. Convert `bigint` results of raw queries to `number`.
6. **Real data only.** Every number, badge and list in the UI comes from the API. No fabricated statistics and no hard-coded demo content outside seed scripts.
7. **Security by default** (section 10.4): hashed secrets, httpOnly cookies, CSRF and origin checks, rate limits, upload sniffing, output escaping, least-privilege RBAC.
8. **Determinism.** Seeds are idempotent (upsert). Tests are isolated and never depend on `sleep`, wall-clock time or execution order.
9. **Honesty.** Never claim a command passed unless you ran it and recorded the real (trimmed) output in PROGRESS.md. Never weaken, skip or delete a test to make it pass: fix the code, or fix the test only when the spec says it is wrong and log that in docs/DECISIONS.md.
10. **Layered architecture.** API: route → schema → handler → service → Prisma. Web: route/page → feature component → hook/service → API client. No business logic in route files or presentational components. Files SHOULD stay under 300 lines.
11. **Accessibility and i18n from day one:** WCAG 2.2 AA, keyboard operability, visible focus, `lang='uz'` on the html element, and all user-facing strings in a typed Uzbek dictionary (no hard-coded literals in JSX).
12. **Dependencies:** prefer few, popular, actively maintained MIT/Apache/BSD libraries. Justify every non-obvious dependency in docs/DECISIONS.md. Versions are pinned by the lockfile.
13. **Time and locale:** store UTC; render in `Asia/Tashkent`; relative time in Uzbek (‘3 soat oldin’, ‘kecha’).
14. **Content and IP:** seed data MUST use original sample text and generated placeholder covers. Never copy copyrighted chapters, blurbs or cover art from real works.
15. **Git hygiene:** Conventional Commits; commit at the end of each phase only after its gate passes; never commit `.env`, uploads or secrets.
16. **No fake green gates.** Scripts named `build`, `typecheck`, `lint`, `db:migrate`, `test:*`, `verify` MUST execute the actual tools against the real app. No grep-based pseudo-TS checker, hard-coded `PASS`, manifest-only build, SQL text checker, or mocked browser passed off as E2E.
17. **No fake application architecture.** No custom `.mjs` HTML template server replacing Next.js, and no `Map`/array acting as the primary application data store. Use Prisma/PostgreSQL for persistent content. Redis/in-memory LRU may only cache authoritative DB results and must be safe to clear.
18. **Visual content is first-class.** Never ship a homepage consisting of text blocks, thin borders, statistical KPI boxes and empty/identical covers. Cover art, typography, rhythm, density and browseability are Tier A requirements, with precise acceptance rules in sections 6, 12, 17 and 23.
19. **No counterfeit readiness.** A scaffold, CLI-only test, static HTML prototype, readme promise or uploaded ZIP is NOT the finished website. `IMPLEMENTED`, `BUILD VERIFIED`, `BROWSER VERIFIED`, `DB VERIFIED` and `DEPLOYED` are distinct statuses.


## 3. Agent operating protocol (read before writing any code)

1. **Ledger first.** Create `PROGRESS.md` (checklist of phases 0–12 with status `[ ]`, `[~]`, `[x]` and a ‘Gate evidence’ block per phase) and `docs/DECISIONS.md` (one line per decision: context → choice → reason). Update both at the end of every phase.
2. **Phase loop:** Inspect → Plan (list the files you will change) → Implement in reviewable commits → Self-review → Run real phase gates → Capture browser screenshots for visual phases → Fix → Record → Commit. Do not write many files blindly in a single tool call; use meaningful file-by-file or batch patches.
3. **Resume protocol:** at the start of every session read PROGRESS.md, docs/DECISIONS.md and `git log --oneline -20`, then continue from the first unchecked phase. Never recreate existing files; open and extend them. Before declaring a phase complete run `pnpm check:placeholders`.
4. **Ambiguity rule:** if this prompt is ambiguous, choose the simplest option that satisfies the acceptance criteria, record it in docs/DECISIONS.md and keep going. Ask the human only when blocked by missing credentials or an irreversible destructive action.
5. **Version policy:** do not trust memory for fast-moving libraries (Next.js, React, Tailwind, Prisma, Fastify, TanStack Query, Zod, Playwright). Before installing, check the current stable version (`npm view <pkg> version`), read peer dependencies, and read the installed package README or types when unsure about an API. Follow the conventions of the installed major version (for example: async `cookies()` and `headers()` and explicit fetch caching in newer Next.js; CSS-first configuration in newer Tailwind; where the datasource URL lives in newer Prisma).
6. **Long files:** write complete files; never output ‘rest of file unchanged’ markers. Split any file that grows beyond ~300 lines into modules.
7. **Terminal discipline:** run servers in the background and read their logs; never run destructive commands outside the repository; fix root causes instead of suppressing errors.
8. **Loop guard:** if a gate fails three times for the same reason, write the diagnosis to docs/KNOWN_ISSUES.md, apply the simplest correct fix and continue. Never loop silently.

## 4. Scope tiers

- **Tier A (mandatory, phases 0–12):** everything described in sections 5–20 and 23. It must be 100% working at the final gate.
- **Tier B (enhancements, section 21):** implement only after the Tier A final gate is green. Each one sits behind a `FEATURE_*` flag that defaults to off, and its UI is completely hidden when the flag is off.
- **Out of scope:** native mobile apps, ML recommendations, a multi-language UI (the UI is Uzbek only), real-money payments (except Tier B5) and automated machine translation.
- **Explicit simplification:** Tier A has no payment system. ‘VIP’ means early-access chapters that staff unlock manually (see 9.4 and 12.4).

---

## 5. Chosen stack, repository layout and developer commands

Choose one coherent stack and do not mix incompatible alternatives. Versions must be resolved and pinned during Phase 0, based on official documentation and package peer dependency requirements; do not blindly hard-code the versions mentioned in the older prompt.

**Architecture**

| Layer | Choice | Hard requirements |
| --- | --- | --- |
| Package management | `pnpm` workspaces, Node.js active LTS | One root lockfile, reproducible installs with `--frozen-lockfile` in CI |
| Web | Next.js App Router + React + strict TypeScript | Server Components by default; Client Components only for interactive features |
| UI | Tailwind CSS + CSS variables + `lucide-react` | **Cover-rich catalog-first editorial design**, real responsive components, WCAG 2.2 AA |
| Forms | React Hook Form + Zod resolver | Use shared input schemas and show field-specific Uzbek errors |
| API | Fastify + TypeScript + Zod | Typed handlers, centralized errors, structured logging |
| Database | PostgreSQL 16+ + Prisma | Real relations, transactions, indexed search, migrations committed |
| Search | PostgreSQL `pg_trgm`, `unaccent`, `fuzzystrmatch`, `tsvector` | No external hosted search dependency for Tier A |
| Cache | Redis with bounded process-local LRU fallback | Correct invalidation, cache-agnostic correctness |
| State | TanStack Query for API state; narrow local state otherwise | Avoid duplicate global stores |
| Authentication | Argon2id + short-lived access JWT + rotating refresh token | Secure cookies, hashed refresh tokens in database, CSRF/origin defenses |
| Tests | Vitest + Fastify inject + Playwright | DB-backed integration, E2E, accessibility and performance tests |
| Files | Local storage adapter for development; S3-compatible adapter for deployment | Upload records live in PostgreSQL; no blobs in Git |
| Containers | Docker Compose | PostgreSQL, Redis, API, Web with health checks |

**Monorepo layout.** The following is the architectural baseline; create additional folders where required, but preserve these responsibilities.

```text
noveluz/
├── apps/
│   ├── api/
│   │   ├── prisma/
│   │   │   ├── schema.prisma
│   │   │   ├── migrations/
│   │   │   └── seed.ts
│   │   ├── src/
│   │   │   ├── app.ts
│   │   │   ├── server.ts
│   │   │   ├── config/
│   │   │   ├── plugins/
│   │   │   ├── middleware/
│   │   │   ├── modules/{auth,novels,chapters,search,users,comments,admin,uploads}/
│   │   │   ├── services/
│   │   │   ├── repositories/
│   │   │   ├── lib/
│   │   │   └── jobs/
│   │   ├── tests/{unit,integration,performance}/
│   │   └── package.json
│   └── web/
│       ├── src/
│       │   ├── app/
│       │   │   ├── (public)/
│       │   │   ├── (auth)/
│       │   │   ├── (account)/
│       │   │   ├── admin/
│       │   │   ├── robots.ts
│       │   │   └── sitemap.ts
│       │   ├── components/{ui,layout,home,catalog,cards,reader,search,admin}/
│       │   ├── features/
│       │   ├── hooks/
│       │   ├── lib/{api,auth,i18n,seo}/
│       │   └── styles/
│       ├── public/
│       ├── tests/{e2e,visual}/
│       └── package.json
├── packages/
│   ├── shared/src/{schemas,types,constants,search,i18n}/
│   └── config/
├── scripts/{check-placeholders.mjs,check-production-integrity.mjs,wait-for-health.mjs,smoke-test.mjs}/
├── infra/{postgres,nginx}/
├── docs/{DECISIONS.md,KNOWN_ISSUES.md,UI_BRIEF.md,DESIGN_SYSTEM.md,VISUAL_QA.md,API.md,SEARCH.md,ADMIN_GUIDE.md,DEPLOYMENT.md,SECURITY.md}/
├── artifacts/visual/               # Screenshot evidence (small/curated, otherwise CI artifacts)
├── .github/workflows/ci.yml
├── .env.example
├── .gitignore
├── pnpm-workspace.yaml
├── package.json
├── pnpm-lock.yaml
├── docker-compose.yml
├── Dockerfile.api
├── Dockerfile.web
├── PROGRESS.md
└── README.md
```

Root scripts MUST exist and have working definitions: `dev`, `build`, `typecheck`, `lint`, `format:check`, `check:placeholders`, `check:production-integrity`, `test:unit`, `test:integration`, `test:e2e`, `test:search`, `test:security`, `verify`, `db:up`, `db:down`, `db:migrate`, `db:seed`, `db:reset:test`, `db:studio`, `perf:seed`, `perf:search`, and `smoke`. Ensure commands run from a clean clone, not merely from one agent's shell session. `check:production-integrity` MUST verify the real Next and TypeScript build scripts plus a live API-to-Postgres write/read/cleanup smoke test in the configured test environment. `pnpm verify` MUST call implemented checks in a stable order: real typecheck, lint, placeholder check, production-integrity check, unit tests, integration tests, actual Next.js/API production builds, real-browser Playwright E2E smoke tests. Do not create test commands that succeed by silently skipping a required suite.

**Configuration contract.** `.env.example` documents all inputs without real secrets: `NODE_ENV`, `DATABASE_URL`, `TEST_DATABASE_URL`, `REDIS_URL`, `API_PORT`, `WEB_PORT`, `NEXT_PUBLIC_API_BASE_URL`, `APP_ORIGIN`, `ACCESS_TOKEN_SECRET`, `REFRESH_TOKEN_SECRET`, `COOKIE_DOMAIN`, `STORAGE_DRIVER`, `UPLOAD_DIR`, optional `S3_ENDPOINT`, `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `LOG_LEVEL`, `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD`, and `FEATURE_*`. Use explicit development-safe values and local URLs only. Environment validation MUST fail fast with actionable errors. Never print secrets.

**Important consistency fixes relative to legacy specifications:** a local reader theme switch does not need a PostgreSQL call, while an action affecting persistent content does. Do not make a fake backend request merely to satisfy wording about all controls being database-backed. Generated original cover illustrations are permitted in seeds; empty image placeholders in finished UI are not. All generated demo credentials must be development-only, never a public production backdoor.

---

## 6. Visual identity — PREMIUM COVER-RICH CATALOG-FIRST (USER-SELECTED OPTION 2)

**NON-NEGOTIABLE APPROVED DIRECTION: Option 2.** NovelUZ is a **cover-first discovery platform**, not a dashboard, developer portal, landing-page template or a huge cinematic hero with little content. The visitor should instantly see books, manga/manhwa covers, editorial curation and a reason to click. Prioritize a **dense but breathable, richly illustrated catalog**. Imagine the information density of strong reading portals, executed with a distinctive NovelUZ visual language; DO NOT copy any existing site pixel for pixel or use unlicensed covers.

### 6.1 Core visual concept

- Character: premium editorial library + modern manga/manhwa storefront. Atmospheric charcoal/navy, warm cream text, restrained violet/indigo highlights, occasional amber for genuine featured/rating indicators. Content/artwork provides most of the color.
- The primary visual assets are **original, genuinely different cover artworks**. Display cover images as the dominant content inside every card. Do not use gradient rectangles with initials as final covers; do not repeat one placeholder image across titles.
- Page feeling: browsing an established fiction platform, not opening an empty SaaS dashboard. Use clear headings, readable typography, purposeful density, consistent vertical rhythm and properly designed hover/focus states.
- Navigation is compact. The hero is a **short curated highlight**, not a full-screen billboard. The first complete row of cover cards should be visible on common laptop screens or begin immediately below the compact feature strip.
- No random statistics/KPI blocks such as "1000+ readers" or "98% speed" on the public homepage. Do not show fabricated telemetry, ``p95 < 300ms`` or developer TZ testing controls in the public design. Those belong to documented reports or an admin diagnostics view.
- Do not sprinkle ubiquitous glassmorphism/glow/blur everywhere. Use thoughtful surfaces and shadows; visual identity comes from curated artwork and typography, not oversized radial gradients.

### 6.2 Design tokens (CSS variables; may refine after screenshot review)

```css
:root {
  --bg-base: #0b0d13;
  --bg-surface: #131722;
  --bg-elevated: #1a2030;
  --bg-soft: #181b27;
  --bg-overlay: rgba(8, 10, 17, 0.88);
  --primary: #818cf8;
  --primary-hover: #a5b4fc;
  --accent: #f4ba61;
  --success: #34d399;
  --danger: #fb7185;
  --text-primary: #f5f6fb;
  --text-secondary: #afb8ce;
  --text-muted: #8792a8;
  --border: rgba(220, 228, 250, .12);
  --radius-xs: 6px;
  --radius-sm: 9px;
  --radius-md: 14px;
  --radius-lg: 20px;
  --content-max: 1440px;
  --header-height: 70px;
}
```

This is a palette, not permission to use low-contrast text. Check actual contrast ratios against all component backgrounds. Use `Plus Jakarta Sans` (UI/headings) and `Literata` (reading text). Implement restrained type scale: page masthead 26–36px; section headers 20–26px; card titles 13–15px; card metadata 11–13px. Prioritize two readable title lines over clipped one-line titles.

### 6.3 Homepage visual structure — above the fold MUST feel alive

Desktop **1440px** shell: centered content max 1360–1440px with ~24–36px gutters, 70px header and optional slim 24–30px announcement. Primary content begins early. Use an editorial composition in this order:

1. **Top navigation**: original NovelUZ wordmark; `Bosh sahifa`, `Katalog`, `Yangi boblar`, `Reyting`; prominent but compact search input/button; profile/entry. Avoid giant empty navigation gaps and meaningless badges. Sticky with subtle solid/blur surface.
2. **Compact featured shelf**: one highlighted work (cover + editorial text + real `O‘qish` action) with 2–4 featured mini-cover choices or compact "Bugun tavsiya" cards. Typical desktop height **300–390px**, not `min-height:100vh` and not a 700px generic gradient hero. Artwork, not a blank background, is the focus. If featured items absent, show an attractive catalog introduction using actual available content.
3. **Immediately discoverable cover grid**: `Trenddagi asarlar` or `Tavsiya etilganlar`, **six cover cards per row** where layout/side rail permits at wide desktop (four/five if rail constrains); real cover images 2:3, distinct colors/art and meaningful metadata. A row of covers should be visible with minimal scrolling.
4. **Genre chips and filters**: category/type and genre controls above first or second catalog section, never consume half the viewport. Filters update real results and URL state.
5. **New chapters**: compact rows with small original cover, chapter number, work title, publish time and click-through.
6. **Top ranking**: editorial numbered list with thumbnail, title and reader-relevant metadata, daily/weekly/monthly tabs supported by dated view aggregates; rail beside catalog on wide screens and separate block below on narrower screens.
7. **Continue reading**: only for authenticated users with actual progress; do not show arbitrary 68% sample progress to everyone.
8. **Footer**: small, useful, consistent, with functional navigation and legal links.

**First viewport design constraint:** at 1440×900, screenshots should contain header, compact featured content and the start of a substantial cover collection. At 390×844, header, one meaningful feature and the first 2-column cover row appear without an excessive spacer. Browsers and font scaling differ; treat these as review targets, not dishonest universal guarantees.

### 6.4 Cards: the signature NovelUZ component

- Cover is vertically oriented at approximately **2:3 ratio**. Use a real `Image` or `<img>` with layout dimensions; optimize load, preserve crop, and handle failure with a polished but honest fallback.
- Each card: cover; subtle type chip on the image (`Novel`, `Manhwa` etc); optional genuine rating; 2-line Uzbek title; compact chapter/status line. Entire semantic link navigates to the actual work page.
- Hover/focus: subtle elevation/outline + cover zoom around 1.025–1.045; keyboard focus visible; no wild 3D tilt, massive glow or delayed pointer response.
- Desktop width typically ~165–205px for main grid; spacing 16–22px. Mobile width determined by two equal columns with 12px gaps, readable text and stable thumbnails.
- Handle 70-character titles, absent ratings, long aliases, missing cover errors, empty datasets, 404 assets, loading states and unpublished items. Do not mask failure with duplicate fake books.
- No lorem ipsum or generic cover labels. Seed **18+ original works** and **18+ distinct attractive original covers** for the visual demo. Prefer professionally composed licensed/original artwork. If full illustration generation is unavailable, create varied original illustrated SVG editorial covers featuring genuinely distinct scenes/shapes/figures with clean title treatment and meaningful texture; never pretend crude gradients satisfy the same requirement. Clearly record asset limitations.

### 6.5 Responsive layout contract

| Width | Catalog grid | Featured / navigation behavior |
| --- | --- | --- |
| ≥1440 | 5–6 columns depending on sidebar | compact featured shelf + ranking rail; navigation and search visible |
| 1024–1439 | 4–5 columns | rail may move below; feature compresses without squashing poster |
| 768–1023 | 3–4 columns | simplified feature; accessible menu/search |
| 360–767 | **2 cover columns** | visible mobile header, search icon, compact curated feature; no horizontal scroll |
| 320–359 | 2 if comfortably legible, else 1 | preserve touch targets and prevent clipped content |

At 360, 390, 768, 1024, 1440 and 1920 CSS px verify actual Chromium screenshots; also check 200% zoom, long headings and keyboard navigation. Mobile needs complete Tier A feature parity, not a fake mockup. Maintain approximate WCAG 2.2 AA target spacing, prefer reduced motion and prevent layout shifts.

### 6.6 Imagery, motion and states

- Create original NovelUZ SVG logo/wordmark and coherent iconography via `lucide-react`. No generic "AI logo" gradient box with a book emoji.
- For each hero/cover image, add meaningful `alt` (or empty alt for purely redundant decorative art), fixed aspect ratio, blur/low-res loading where useful and fallback error state. No remote copyrighted artwork, hotlinking, watermarks or random external image URLs.
- `prefers-reduced-motion` disables nonessential motion; standard transitions 120–220ms. Never let animation obstruct reading or meaningful interactions.
- Loading: real cover-grid skeletons at stable dimensions; empty state with actionable filter reset; error state with `Qayta urinish` that actually retries data. Offline states must distinguish connectivity from query no-results.
- Editorial copy MUST be natural Uzbek Latin; dictionary-driven labels, no English leftovers on the visible UI. Keep badges minimal and purposeful.

### 6.7 Required actual design artifacts

Before implementing the full UI, create `docs/UI_BRIEF.md`, `docs/DESIGN_SYSTEM.md`, and a simple wireframe/route component map in documentation. After implementation capture actual browser screenshots into `artifacts/visual/` or CI artifacts: `home-desktop-1440.png`, `home-mobile-390.png`, `catalog-desktop.png`, `catalog-mobile.png`, `novel-detail.png`, `reader-desktop.png`, `admin-desktop.png`. Screenshots MUST come from a running Next.js application with a running API and seeded DB. Do not attach Figma-style fantasy mockups as proof of working screens. Capture and inspect screenshots for blank zones, repetitive cards, clipping, 404 covers and awkward visual hierarchy.

### 6.8 Usability and editorial hierarchy acceptance

A user visiting for the first time should (a) immediately recognize a manga/webnovel catalog, (b) identify a featured title and several distinct covers, (c) find search/catalog navigation, and (d) reach a real work detail and chapter in two to three purposeful clicks. The homepage MUST NOT resemble a text-only directory, empty GitHub Pages boilerplate, CLI tool, or "school project" static template. Visual review is a hard gate, not an optional polish task. Use section 23's acceptance checklist. If design fails, revise layout and assets before Phase 6 PASS.

---

## 7. PostgreSQL schema, data invariants and migrations

Create a complete Prisma schema under `apps/api/prisma/schema.prisma`. Define explicit enums, UUID keys, timestamps and referential actions. Keep money out of Tier A. Use `Decimal` rather than `Float` for chapter numbering where decimals are necessary; convert safely for API JSON. Do not use floating point as a uniqueness key. Store consistent normalized search fields in the same write transaction as their source text.

### 7.1 Core models

1. **User:** `id`, unique case-insensitive `username` and `email`, `passwordHash`, `role` (`READER | TRANSLATOR | MODERATOR | ADMIN`), `avatarAssetId?`, `bio?`, `isBanned`, `createdAt`, `updatedAt`, `lastLoginAt?`. Normalize email and username before uniqueness enforcement; implement DB indexes that prevent case-variant duplicates.
2. **RefreshSession:** `id`, `userId`, `tokenHash` (unique), `familyId`, `expiresAt`, `revokedAt?`, `createdAt`, `lastUsedAt?`, `userAgent?`, `ipHash?`; rotated atomically and revoked on logout/reuse.
3. **Novel:** `id`, unique `slug`, `title`, `normalizedTitle`, `description`, `type` (`NOVEL | MANHWA | MANGA | MANHUA`), `status` (`ONGOING | COMPLETED | HIATUS | DROPPED`), `author`, `normalizedAuthor`, `translatorGroup?`, `normalizedTranslatorGroup?`, `releaseYear?`, `ageRating` (`ALL | AGE_12 | AGE_16 | AGE_18`), `coverAssetId?`, `bannerAssetId?`, `viewsCount`, `ratingAvg`, `ratingCount`, `chapterCount`, `isFeatured`, `featuredOrder?`, `publishedAt?`, `createdAt`, `updatedAt`.
4. **NovelAlias:** `id`, `novelId`, `name`, `normalizedName`, `locale?`, `createdAt`, unique `(novelId, normalizedName)`; indexed for exact, trigram and prefix search. This **replaces** duplicate `aliases String[]` columns.
5. **Genre** and **Tag:** `id`, unique `slug`, unique normalized `name`, `createdAt`; **NovelGenre** and **NovelTag** join models with composite unique keys, appropriate cascading rules and indexes.
6. **NovelContributor:** `(novelId, userId, canEditNovel, canEditChapters)` with composite primary key, letting a TRANSLATOR edit assigned works only. An ADMIN may manage assignments. A MODERATOR cannot implicitly edit all content unless specifically permitted by the policy matrix.
7. **Chapter:** `id`, `novelId`, `volumeNumber`, `chapterNumber Decimal(8,2)`, optional `title`, `contentText?`, `kind` (`TEXT | IMAGES`), `isPublished`, `isVip`, `wordCount`, `viewsCount`, `publishedAt?`, `createdAt`, `updatedAt`, unique `(novelId, volumeNumber, chapterNumber)`. Use canonical decimal serialization (`14.5`, not `14.50`) in URLs. A chapter MUST have exactly the relevant content kind; validate at the API and database constraints when practicable.
8. **ChapterPage:** `id`, `chapterId`, `assetId`, `position`, `altText?`, unique `(chapterId, position)`; explicitly ordered image pages. This replaces `imageUrls String[]` for asset lifecycle integrity.
9. **Bookmark:** `id`, `userId`, `novelId`, `listType` (`READING | PLANNED | COMPLETED | DROPPED | FAVORITE`), `lastReadChapterId?`, `scrollPercent Decimal(5,2)`, `updatedAt`, unique `(userId, novelId)`; `0 <= scrollPercent <= 100`, and progress chapter MUST belong to bookmarked novel.
10. **ReaderPreference:** `userId` PK, `theme` (`DARK | LIGHT | SEPIA`), `fontFamily`, `fontSize`, `lineHeight`, `contentWidth`, `updatedAt`; optional anonymous preference storage locally with no account requirement.
11. **Rating:** `id`, `userId`, `novelId`, `score Int` (1–5), `createdAt`, `updatedAt`, unique `(userId, novelId)` and CHECK constraint. Recalculate aggregates inside a serializable or otherwise concurrency-safe transaction.
12. **Comment:** `id`, `userId`, `novelId`, `chapterId?`, `parentId?`, `body`, `isSpoiler`, `isDeleted`, `deletedAt?`, `createdAt`, `updatedAt`. Enforce reply nesting policy (max depth 3), chapter/novel consistency and no replies to deleted content when forbidden.
13. **CommentLike:** `(userId, commentId)` composite unique; derive `likesCount` transactionally or query it rather than trusting arbitrary requests.
14. **UploadAsset:** `id`, `storageKey` unique, `mimeType`, `bytes`, `width?`, `height?`, `sha256`, `createdById`, `createdAt`, `deletedAt?`; covers, banners, avatars and chapter pages reference registered assets.
15. **NovelViewEvent** or a bounded daily aggregate **NovelDailyStat:** `novelId`, `date`, `views`, unique `(novelId, date)`. This is required for genuinely daily/weekly/monthly rankings, not a relabeling of lifetime `viewsCount`.
16. **SearchLog:** `id`, normalized or redacted `query` and `normalizedQuery`, `scope`, `resultsCount`, `latencyMs`, `cacheHit`, `createdAt`; bounded retention and no identifiers unnecessarily collected.
17. **AuditLog:** `id`, `actorUserId?`, `action`, `entityType`, `entityId`, `metadata Json`, `createdAt`, with indexes on `(actorUserId, createdAt)` and `(entityType, entityId)`. Sanitize PII and never log password or token material.
18. **SiteSettings:** one fixed singleton row containing `announcementText?`, `announcementActive`, `maintenanceMode`, `maintenanceMessage?`, `updatedAt`. A singleton convention MUST be enforced in service logic and migrations.

### 7.2 Index and constraint rules

- Enable `pg_trgm`, `unaccent` and `fuzzystrmatch` in a checked-in SQL migration. PostgreSQL extensions may require DBA permissions in managed hosting; document that deployment requirement.
- Create GIN trigram indexes on `Novel.normalizedTitle`, `NovelAlias.normalizedName`, `Novel.normalizedAuthor`; create appropriate btree indexes for equality, status/type sorting, chapter ordering and published timestamps.
- A separate searchable `tsvector` projection/index for **catalog metadata** MUST exclude chapter bodies. Use PostgreSQL `simple` configuration for mixed Uzbek/Latin text, or justify a better supported tokenizer with repeatable tests. Prefer generated columns or indexed expressions whose contents are actually maintained by the chosen ORM/migrations.
- Index **chapter text separately** (`Chapter.contentText`, `isPublished`, `novelId`) and restrict results to published/access-allowed chapters. PostgreSQL full-text search behavior on Uzbek and Cyrillic MUST be covered by explicit normalization tests; do not assume `english` stemming works for Uzbek.
- Normalize all aliases after create/update; prevent alias collisions within one work and detect duplicates across works for admin review, but do not globally prohibit legitimate shared aliases.
- Maintain aggregate view/rating/chapter counts transactionally or via documented eventual consistency; never show arbitrary counter values.
- Define cascade/restrict behavior for each relation. Prefer soft-deleting public content when it would otherwise orphan audit/history. Hard deletion in admin must require confirmation and log actions.
- Test forward migrations on an empty DB and on a previously seeded DB. Use Prisma migrations plus manual SQL for unsupported indexes/checks; do not rely solely on `prisma db push`.

### 7.3 Seed and auth safety invariants

Seeds are repeatable and deterministic. Seed only fictional/original prose and original/generated illustration assets. Real popular titles may appear **only as metadata/search test fixtures** where useful; do not represent invented chapter text as official content from those works. Any local demo admin credentials must come from `SEED_ADMIN_EMAIL` and `SEED_ADMIN_PASSWORD`, must be disabled for production seeding, and must be explained in README without shipping a known universal password.

---

## 8. Authentication, authorization and session lifecycle

**Endpoints:** `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/refresh`, `POST /api/auth/logout`, `POST /api/auth/logout-all`, `GET /api/auth/me`, `PATCH /api/user/profile`, `PATCH /api/user/password`.

- Register with username, valid email and strong password; normalize uniqueness and block banned accounts. Hash passwords with Argon2id using explicit cost parameters. Never echo hashes.
- Issue short-lived access JWTs and one-time rotating refresh tokens stored only in secure `httpOnly` cookies on browser clients. Persist only a hash of each refresh token. Detect token reuse and revoke its token family. Protect session mutations with same-site cookies plus Origin/Referer validation and a concrete CSRF mitigation strategy documented in `docs/SECURITY.md`.
- Support `Authorization: Bearer` for trusted API clients without creating a parallel insecure token storage path in the website. Do not put access/refresh tokens in `localStorage`.
- Distinguish authentication (`401`) from authorization (`403`). Access to `/admin` requires server-side authorization, not just a hidden navigation item. On user ban, revoke active sessions and reject current access tokens with a DB-backed or bounded-revocation check.
- Optional anonymous users can browse and read public chapters; actions requiring accounts prompt login and preserve a return URL validated against open redirects.

**RBAC policy (must also exist as automated tests):**

| Capability | READER | TRANSLATOR | MODERATOR | ADMIN |
| --- | --- | --- | --- | --- |
| Browse, read public content | Yes | Yes | Yes | Yes |
| Own bookmarks, ratings, comments and profile | Yes | Yes | Yes | Yes |
| Edit assigned novel/chapters | No | Assigned only | Assigned only | All |
| Moderate comments and spoiler flags | No | No | Yes | Yes |
| Manage users' bans | No | No | Yes, not staff/admin | Yes |
| Change user roles | No | No | No | Yes |
| Manage genres, tags and featured placements | No | No | No | Yes |
| Site settings and search reindex | No | No | No | Yes |
| Read audit logs and full analytics | No | No | Restricted | Yes |

Never allow users to grant themselves higher privileges, edit another user's data by changing a path ID, or read drafts/VIP content by guessing URLs. Every mutation has a per-resource authorization decision in the service layer. An ADMIN cannot accidentally remove the last active admin account.

---

## 9. REST API contract and domain behavior

Use consistent `/api` prefixes and one OpenAPI 3.1 specification generated/validated against Zod schemas. No duplicated ambiguous endpoints. Public and authenticated representations must omit secrets and unpublished/private fields.

**Success envelope:**

```json
{
  "data": {},
  "meta": { "page": 1, "limit": 20, "total": 0, "totalPages": 0 },
  "requestId": "opaque-request-id"
}
```

For a single-resource response, `meta` may be omitted. For search use `{ "data": { "results": [], "suggestions": [] }, "meta": { "page": 1, "limit": 10, "total": 0, "latencyMs": 12.4, "cacheHit": false } }`. Do not mix response shapes in handlers and web clients.

**Error envelope:** `{"error":{"code":"VALIDATION_ERROR","message":"...","details":{}},"requestId":"..."}`. Use correct HTTP codes: 400/422 invalid input, 401 unauthenticated, 403 unauthorized, 404 missing/unpublished, 409 conflicts, 413 upload too large, 429 rate-limited, 500 unexpected. Hide internal stack traces.

### 9.1 Public catalog and chapters

- `GET /api/novels`: paginated, typed filters `type`, `status`, `genre`, `tag`, `year`, `sort=updated|rating|views|chapters|title`, `order`, `page`, `limit`; deterministic secondary sorting by `id`.
- `GET /api/novels/featured`: admin-ordered hero cards.
- `GET /api/novels/top?period=day|week|month`: daily aggregated views for real date windows, not lifetime views.
- `GET /api/novels/random`: server-selected published work, with sensible empty-catalog behavior.
- `GET /api/novels/latest-chapters`: latest published chapters with work metadata, pagination.
- `GET /api/novels/:slug`: work detail, aliases, genres, tags, published chapter counts and lists, summary statistics; logged-in bookmark/rating returned only to authorized owner.
- `GET /api/novels/:slug/chapters/:chapterNumber?volume=1`: read a published chapter, correct previous/next navigation, protect drafts and VIP content. A separate `chapterId` endpoint MAY be used internally when URLs need stable IDs.
- `POST /api/novels/:id/views`: idempotent/abuse-resistant view recording as appropriate; document unique counting or aggregation semantics. Public GET endpoints must not be required to mutate DB for every render or crawler request.

### 9.2 Search

- `GET /api/search/catalog?q=&scope=all|NOVEL|MANHWA|MANGA|MANHUA|AUTHOR&page=1&limit=10`.
- `GET /api/search/chapters?q=&novelId=&page=1&limit=10`; include snippets/highlights and access checks.
- `GET /api/search/suggestions?q=` MAY share catalog service and must obey exactly the same normalization and permission rules.

### 9.3 Account and social actions

- `GET /api/user/bookmarks?listType=...`; `PUT /api/user/bookmarks/:novelId` (upsert); `DELETE /api/user/bookmarks/:novelId`.
- `PUT /api/user/reading-progress/:novelId` (update `lastReadChapterId`, `scrollPercent`, optional version/timestamp for conflict resolution); `GET /api/user/reading-progress/:novelId`.
- `PUT /api/user/ratings/:novelId` (1–5); `DELETE /api/user/ratings/:novelId` (recalculate aggregate).
- `GET /api/novels/:novelId/comments`; `POST /api/novels/:novelId/comments` (optional chapterId/parentId); `PATCH /api/comments/:id`; `DELETE /api/comments/:id` (soft delete).
- `PUT /api/comments/:id/like`, `DELETE /api/comments/:id/like`; only count a user's vote once.
- `GET /api/user/profile`, `PATCH /api/user/profile`, `PATCH /api/user/password`, preference endpoints as specified in section 7.

### 9.4 Admin endpoints

Prefix all admin operations with `/api/admin`; enforce RBAC per route and resource:

- `GET /stats`, `GET /search/zero-results`, `GET /audit-logs`.
- `GET /novels`, `POST /novels`, `GET /novels/:id`, `PATCH /novels/:id`, `DELETE /novels/:id`.
- `PUT /novels/:id/aliases`; `PUT /novels/:id/contributors`; `PATCH /novels/:id/featured`.
- `GET /novels/:id/chapters`, `POST /novels/:id/chapters`, `PATCH /chapters/:id`, `DELETE /chapters/:id`; `POST /novels/:id/chapters/bulk` with all-or-partial success semantics documented and tested.
- `GET/POST/PATCH/DELETE /genres/:id` and `/tags/:id` (shape individual routes correctly in code and OpenAPI).
- `GET /users`, `PATCH /users/:id/role`, `PATCH /users/:id/ban`.
- `GET /comments`, `PATCH /comments/:id/moderate`, `DELETE /comments/:id`.
- `GET /settings`, `PATCH /settings`.
- `POST /search/reindex` with job status/locking; `GET /search/reindex/:jobId`.
- `POST /uploads` (authenticated) and `DELETE /uploads/:id` (when unreferenced), with strict mime/ownership checks.

Use explicit PATCH semantics; omitted values mean unchanged, `null` means clear only for nullable fields. Implement optimistic concurrency where simultaneous edits could overwrite data. Bulk uploads and deletion must expose real progress, counts and errors.

---

## 10. Backend architecture, operational correctness and security

### 10.1 Fastify module structure

Group routes, schemas, services and repositories by domain. Server startup must connect to PostgreSQL and Redis gracefully; if Redis fails, switch to bounded in-memory cache with a structured warning and no change in search correctness. Expose `GET /health/live` (process responsive) and `GET /health/ready` (database ready; cache may degrade). Handle shutdown signals, close DB pools, stop accepting requests and flush relevant queues.

### 10.2 Centralized errors and observability

Implement one Fastify error handler mapping Zod, Prisma unique/missing row, auth, upload and unknown errors to stable API codes. Use Pino structured logs with `requestId`, method, route, status and duration. Redact cookie values, authorization headers, tokens, secrets and uploaded text. Keep `SearchLog` writes asynchronous and bounded, but never make the request fail if analytics logging fails. Provide p50/p95 computed from actual recent samples and cache-hit ratio with sample counts; display `Ma’lumot yetarli emas` when insufficient samples.

### 10.3 File upload security and storage

Accept only allowlisted JPEG/PNG/WebP (possibly AVIF if supported) with verified decoded content, MIME detection **and** extension checks. Enforce size/pixel limits, streamed upload limits and image dimension validation. Re-encode images to safe image formats, strip metadata, generate unique opaque storage keys, and store upload metadata in `UploadAsset`. For text chapter imports accept UTF-8 plain text only; sanitize and validate length. Block SVG uploads from untrusted users. For deployment use S3-compatible private origin and signed reads/public CDN policy by content type; never allow arbitrary server paths, SSRF imports or traversal. Enforce ownership and cleanup after failed transactions; do not allow orphaned upload records indefinitely.

### 10.4 Web security baseline

- HTTPS in deployment, secure cookies, HSTS at edge, strict CORS for actual web origin, correct CSP, `X-Content-Type-Options`, appropriate frame/referrer policies.
- Rate-limit registration/login/refresh/password changes and public search separately; return actionable Uzbek 429 errors and appropriate `Retry-After`.
- Escape user text; sanitize rich text with an allowlist if rich text is introduced. Never render arbitrary untrusted HTML in reader or comments. Linkify only validated safe protocols.
- Apply same-origin/CSRF protections to cookie-authenticated mutations, including file uploads and admin requests. Avoid permissive CORS with credentials.
- Ownership checks on every ID, nested relation and file; reject mass assignment by using explicit input schemas and allowed fields.
- Protect against malicious queries with max normalized length, bounded page sizes, query timeouts and parameterized `Prisma.sql`.
- Explicitly test login brute force defenses, role escalation, IDOR, stored XSS, file/polyglot upload rejection, SQL injection-like input and refresh-token reuse.

### 10.5 Cache correctness

Cache only public, non-sensitive catalog/search results. Keys must include normalized query, actual scope, ordering, page, limit and a schema/index generation value; do not cache personalized state without a user-specific key. Invalidate affected entries when aliases, titles, status, genres, tags, cover, author and publication state change. Prefer a generation namespace increment over brittle wildcard deletion. Redis failure must not serve stale drafts or expose unpublished content. Use maximum TTL 60 seconds for search unless stronger invalidation is proven. `latencyMs` measures server processing, and client performance should be tracked separately.

---

## 11. Smart search: TZ sections 1–7, executable specification

Create `apps/api/src/services/search.service.ts` with pure normalization helpers in `packages/shared/src/search/`. The reference behavior is defined by tests, not guesses. Search the **catalog first**, never chapter bodies, unless the user explicitly selects chapter search.

### 11.1 Uzbek normalization

For user queries, work titles, aliases, authors and searchable taxonomy:

1. Apply Unicode normalization (`NFKC` where appropriate), lowercase with deterministic casing, collapse whitespace, trim.
2. Transliterate Uzbek Cyrillic to Latin with explicit mappings for `ў→o`, `ғ→g`, `қ→q`, `ҳ→h`, `ш→sh`, `ч→ch`, `ё→yo`, `ю→yu`, `я→ya`, `ж→j`, `ц→ts`, `ъ/ь` handling; also handle ordinary Russian letters consistently. Test mixed script and punctuation.
3. Canonicalize apostrophe variants `ʻ`, `ʼ`, `'`, `’`, `` ` ``, and distinguish `oʻ`/`gʻ` consistently. Preserve meaningful word boundaries. Document whether `oʻ→o` and `gʻ→g` are lossy; use the same rule for stored data and incoming queries.
4. Normalize hyphen variants, repeated punctuation, duplicate spaces and accent marks where safe. Do not strip numerals or rewrite meaningful title text indiscriminately.
5. Detect optional content-type suffixes (`manhwa`, `manga`, `manhua`, `novel`, `ranobe`) **only** if a credible base title remains; use the removed suffix as a soft type hint unless the user set an explicit scope. `Solo Leveling manhwa` should still match `Solo Leveling` and never force a false exact title.
6. Reject or return an empty response for empty normalized queries (and for queries exceeding documented limits) instead of issuing an unbounded table scan. Set `min query length` carefully: short exact-title queries must remain searchable.

### 11.2 Candidate retrieval and ranking

Implement a bounded, indexed candidate pipeline rather than loading all novels into JavaScript. De-duplicate by `Novel.id` **before** pagination. Every hit has `matchType`, `matchField`, `displayScore` (0–100, calibrated as relevance, **not a fake probability**) and a stable tie-breaking order.

**Tier order is lexicographic: lower number always outranks a higher tier, regardless of score.**

| Tier | Description | Examples |
| --- | --- | --- |
| 1 | Exact normalized canonical title | `solo leveling` |
| 2 | Exact normalized alias | `yakkalikda daraja oshirish` |
| 3 | Credible fuzzy title/alias typo match (1–2 edits, adjusted for string length) | `solo leving`, `sololevelingg` |
| 4 | Prefix match on title/alias | `solo lev` |
| 5 | Title/alias substring, author and translator-group matches | `leveling`, author name |
| 6 | Genre/tag and bounded description relevance | `fantastika`, `sarguzasht` |

**Special ranking resolution:** a short prefix must not be misinterpreted as a typo simply because edit distance to a longer title is high. Tier 3 only includes genuine near-whole-string edits; evaluate prefix separately. All tiers require a positive, explainable match signal. Full exact title MUST rank #1. If the user selected `scope=AUTHOR`, search author/translator fields directly and use an author-specific rank matrix, while still returning relevant novel records.

For fuzzy retrieval use indexed trigram operators (`%`, `similarity`, `word_similarity` as appropriate) and a verified bounded edit distance (`levenshtein_less_equal` where available) on a small prefiltered candidate set. Thresholds vary with length to avoid matching unrelated short titles; define and justify precise constants in code. A 2-character edit in a 3-character query should not automatically match. Build a deterministic SQL query (CTEs or UNION ALL candidates) using `Prisma.sql` with bound parameters. Return exact `total` and stable `page`/`limit` results. Do not rank by database storage order.

### 11.3 False positives, suggestions and caching

- Query `asdfghjkl123` MUST return `results=[]`, `meta.total=0`, with optional separately labeled `suggestions` that are **not** counted as matches.
- Do not fill empty result pages with trending titles disguised as search results.
- Report `matchType` in Uzbek (`Aniq nom`, `Muqobil nom`, `Imlo o‘xshashligi`, `Nomning boshi`, `Matndagi moslik`, `Janr yoki teg`). Show client-side relevance percentages as a search score, not certainty.
- Debounce UI input by 200 ms and cancel stale requests using AbortController; rapidly changing query text must never show older results as the new query.
- Cache public result sets for up to 60 seconds with generation-based invalidation and Redis→bounded LRU fallback. Track cache hits accurately and separately test cold-cache performance.

### 11.4 Chapter full-text search

Implement `GET /api/search/chapters` with an entirely separate `tsvector` index. Normalize search terms compatibly with document indexing; test apostrophes, Cyrillic and Latin title/body text. Use a fixed, escaped, short `ts_headline` snippet or safe application-level highlight spans; never return raw HTML in the browser without sanitization. Exclude drafts and inaccessible VIP chapters; filter by `novelId` only when permitted. Keep chapter FTS out of catalog search, including SQL planner paths and cache keys.

### 11.5 Measurable performance target

Target p95 under **300 ms** on 10,000 seeded novel metadata records (minimum 20,000 aliases), cache bypassed. Define the measurement as end-to-end API handler duration on localhost using a warmed database, 200+ requests over a representative mix of exact, alias, prefix, typo, no-result and paginated queries, concurrency of 10, with fixtures and hardware/container limits recorded in `docs/SEARCH.md`. Exclude initial migration/seed time and report p50, p95, max and sample size. A benchmark failing on resource-starved CI must report actual measurements rather than silently lowering the threshold. Use `EXPLAIN (ANALYZE, BUFFERS)` to diagnose slow SQL; do not simply cache over bad indexing.

---

## 12. Public website, search experience and reader

### 12.1 Global layout

Every public page has a semantic header, skip link, accessible navigation, site announcement when active, footer, readable empty/error screens and mobile navigation. Routes:

- `/` — home
- `/catalog` — full filtered catalog
- `/new` — latest published chapters
- `/ranking` — time-window rankings
- `/novel/[slug]` — work detail
- `/novel/[slug]/chapter/[chapterNumber]` — reader; query `volume` when needed
- `/login`, `/register` — auth
- `/profile`, `/library`, `/settings/reader` — authenticated user
- `/search` — accessible full-page search fallback (dialog is not the only way to search)

### 12.2 Header and search UI

Header must look like an editorial reading platform, not a generic navbar. Include an original NovelUZ logo, `Bosh sahifa`, `Katalog`, `Yangi boblar`, `Reyting`, `Tasodifiy asar`, `Xatcho‘plar`, auth menu. `Ctrl+K` / `Cmd+K` opens an accessible search modal; Escape closes it; keyboard arrows move among results with correct aria-activedescendant or roving focus. Include: 200 ms debounced catalog search, scopes (Hammasi / Novel / Manhwa / Manga / Manhua / Muallif), search history stored locally with explicit clear, exact/alias/fuzzy labels, relevance scores, result count and loading/error states. Show diagnostic latency only in a restrained footer/developer view, never as invented status or as a homepage badge. Provide a separate tab `Boblar ichidan qidirish` with snippets, a clear empty-state message and correct VIP permissions. Results must use direct links and preserve browser back behavior.

### 12.3 Homepage, catalog-first IA and navigation

**THIS SUBSECTION OVERRIDES any older "cinematic full-screen hero" expectation.** The user explicitly selected **Option 2: a premium image-rich catalog**. Visual priority is discovery; a compact curated feature is subordinate to a strong, visible cover grid. Implement sections below as real Next.js App Router components, not HTML strings served from a custom `.mjs` server.

**Required home module tree:**

```text
app/(public)/page.tsx                          # server-rendered home with initial data
components/layout/SiteHeader.tsx              # real navigation / profile / search
components/home/FeaturedShelf.tsx            # compact editorial feature and selectors
components/home/ContinueReadingStrip.tsx     # only when real progress exists
components/home/HomeDiscovery.tsx            # section orchestration / responsive grid
components/cards/NovelCoverCard.tsx          # reusable cover-first card
components/cards/NovelCoverSkeleton.tsx      # dimension-stable loading
components/catalog/CatalogFilterBar.tsx      # real query params and API state
components/home/LatestChapterFeed.tsx        # real chapter links
components/home/RankingRail.tsx              # real daily / weekly / monthly data
components/search/GlobalSearchDialog.tsx     # accessible live search
```

**Data integration:** initial home route fetches `/api/novels/featured`, `/api/novels`, `/api/novels/latest-chapters` and `/api/novels/top?period=...` (via coherent server API adapter; consolidate calls when justified). Filters/sort/pagination reflected in URL; back/forward and refresh preserve state. Every card uses canonical `/novel/[slug]`, not `href="#"`. Only published content available to public; a deleted image gets a truthful fallback. Avoid fabricated recent activity, rating scores or "trending" lists. Feature/order comes from `Novel.isFeatured` and editorial ordering; ranking from real aggregates.

**Visual composition:** compact header → curated feature shelf (approx. 300–390px desktop) → cover-rich `Trenddagi asarlar` grid → genre/type selectors and discovery → latest updates → real ranking rail/footer. On mobile a compact feature precedes a **2-column** cover grid. Balance density and breathing room. Do not let a full-height hero, gigantic empty gradients, status counters or repetitive stats push covers below the fold.

**Visual asset rule:** seed 18+ original cover-distinct works and capture homepage screenshots with genuine rendered images. No site release with only abstract repeated placeholder card backgrounds. Production data may be sparse; provide graceful empty state, not synthetic cards.

**Minimum real interactions:** featured choice updates highlighted work; `O‘qishni boshlash` opens the first public chapter or clear no-chapters state; cover card opens detail; `Xatcho‘p` persists for signed-in users or redirects with return URL; search opens on Ctrl/Cmd+K; genre/type selects and URL filters; ranking period changes backend query; latest chapter row opens correct chapter; load-more or pagination fetches correct next results; mobile navigation opens/closes with focus control.

**Acceptance:** browser screenshot inspected at 390×844, 768×1024 and 1440×900. At desktop the image grid must be visually present in or near the first viewport; at mobile at least the start of the two-cover row appears soon after a compact feature. No overlap, horizontal scrolling, inaccessible controls, 404 cover art, `undefined`, English placeholders or fake click handlers. Document deviations with exact screenshots and fixes in `docs/VISUAL_QA.md`.

**Full `/catalog`:** type, genre, tag, status, sort; search within catalog; URL-persisted controls; paginated server results; stable cover aspect ratio; real loading/error/empty states; accessible filter reset; responsive grid with appropriate item density. Catalog page is not the same bare text list as home.

### 12.4 Detail and reading rules

Novel detail: original cover/banner, description, aliases, author, translator group, year, genre/tag chips, views, average rating/count, chapter groups, chapter sort/filter, bookmark dropdown, user ratings and threaded comments. Enforce spoiler concealment both visually and for assistive technology; reveal only on explicit user action.

Novel reader: font family, size 14–28 px, line-height, max width, dark/sepia/light themes and hideable controls. Restore anonymous preferences locally; sync signed-in preferences through API. Use sane paragraph formatting and never inject unsafe HTML from chapter text. Progress sync is throttled/debounced and flushed on navigation/unload where feasible; use monotonic timestamp/version semantics to prevent an old device overwriting newer progress. Keyboard shortcuts must be disabled when focus is in an input, editor or dialog. For manga/manhwa images, vertical-strip view with ordered pages, aspect-ratio preservation, lazy loading, retryable image errors and progress/page indication. Support chapter navigation at both ends, accessible previous/next labels, and linked chapter comments.

**VIP policy (Tier A):** there is no checkout, currency, wallet or billing. Staff may mark a chapter VIP. VIP chapters must require an explicit staff/admin entitlement rule; until entitlement features exist, treat them as **staff-only early access** and show a clear locked explanation to public readers. No client-side-only gating, leaked text in metadata, cached API responses or search snippets. Tests must prove unauthorized users cannot fetch VIP content by changing URL or API IDs.

### 12.5 Auth, profile, library

Registration/login: validation, password visibility, reasonable rate-limit messaging, keyboard support, return route. User library has real sections `O‘qiyapman`, `Rejada`, `Tugatdim`, `Tashladim`, `Sevimlilar`; one active listType per work. Profile editing includes avatar upload, username, bio and password change; show actual success/error states and no dead save button. Guest actions that require auth lead to login rather than failing silently.

---

## 13. Complete admin panel and editorial workflows

Build `/admin` with a distinct protected layout, persistent desktop sidebar, mobile-friendly admin drawer, breadcrumbs and route-level RBAC enforced on both server and API. Do not expose navigation items a role cannot use. All admin mutations generate an audit record with actor/action/entity/timestamp and sanitized metadata.

### 13.1 Dashboard (`/admin`)

Show actual counts of published/draft works, chapters, users and views; recent publications; search p50/p95, cache hit ratio and sample count; a table of frequent zero-result queries with normalized query, count and last occurrence. When there are no logs, render `Hozircha ma’lumot yo‘q`. Provide a link to search aliases editing for actionable zero-result entries.

### 13.2 Works (`/admin/novels` and `/admin/novels/new`, `/admin/novels/[id]/edit`)

CRUD with validation for canonical title, slug, aliases chip editor, type, status, age rating, author, translator group, years, genres, tags, original cover/banner upload, published/draft status, featured toggle and featured order. Duplicate slug gives field-level error. Save via real API; navigation and success toast only after response confirms persistence. Deleting a work requires typed confirmation with an explanation of chapter/comment consequences; protect audit data. Updating a title or alias MUST reindex its search representation and invalidate caches automatically.

### 13.3 Chapters (`/admin/novels/[id]/chapters`)

Volume-grouped table, add/edit/soft-delete, reorder within the canonical chapter numbering convention, text editor for novel chapters and multi-image ordered upload for webtoons. Include draft/publish control, staff-only VIP flag, word count, preview (not public publication), duplicate chapter validation, bulk upload and per-item error reporting. A translator sees only assigned works; an admin sees all. Upload errors must not leave partially published chapters or leaked orphan assets.

### 13.4 Taxonomy, users, comments and settings

- `/admin/taxonomy`: create/rename/delete genres and tags; show usage counts; enforce slug uniqueness; warn before deleting taxonomy with associated works.
- `/admin/users`: search/sort users; ban/unban; admin-only role changes and contributor assignment; prevent self-demotion of last admin and privilege escalation.
- `/admin/comments`: filter by novel, chapter, spoilers and moderation state; soft-delete/restore where supported; log moderation reason.
- `/admin/settings`: announcement text/status, maintenance mode, site settings; admin-only manual reindex with progress status; clear search cache generation; audit log viewer with filters and pagination.
- `/admin/uploads` MAY be a simple asset-usage view if it materially improves cleanup; full asset-library UX is not needed for Tier A as long as admin uploads and deletion work.

**Maintenance mode:** public pages show an Uzbek maintenance response, admin/staff can authenticate and operate, readiness endpoint remains meaningful for infrastructure. The API must not expose drafts or break scheduled health checks. Require confirmation before enabling maintenance.

**Admin acceptance scenario:** create a new novel with alias and cover → attach genres → create a draft chapter → preview as staff → publish → search by alias → read publicly → edit title → verify new title search and cache invalidation → delete/comment moderate as authorized → view audit record. Automate this entire flow in Playwright.

---

## 14. Content publishing, moderation and legal requirements

**Content source policy:** NovelUZ is an original/authorized translation platform. Do not scrape or reproduce third-party book chapters, paid works, manga panels, copyrighted blurbs or cover art without permission. For seed data, invent at least 18 original fictional titles and 3–5 original short chapters per text work; supply 18+ visually distinct, carefully composed original cover SVG/PNG/WebP assets (not repetitive gradient placeholders). The presence of popular names such as `Solo Leveling` in search fixtures is only for search acceptance testing; they must never imply licensing or availability of official chapters. Clearly label fictional demonstration content as demo in the local/dev environment.

**Publication workflow:** draft chapters cannot appear in public list/search/sitemap, while public and staff previews must use distinct authorization-aware handlers. Publishing updates latest-chapters feed, chapter counters, search indexes and caches. Unpublishing revokes public access immediately; avoid stale CDN/API leaks. Delete operations preserve essential audit history. Comments support spoiler flags, limited nesting, abuse/report handling if implemented, soft deletion and author-owned editing. Prevent spam via rate limits and content length limits.

**Age ratings:** age-rating metadata must be displayed, not used as a claim of identity verification. Do not auto-import adult content or bypass age restrictions. Provide accessible reporting/moderation pathways and basic Terms/Privacy pages in Uzbek, marked as drafts for legal review rather than falsely claiming compliance with all jurisdictions.

**Data privacy:** minimize query and IP retention, explain logs and account-data storage in privacy docs, never log passwords or tokens, and document an admin-assisted account/data deletion process. For production, legal wording and hosting requirements require human review; report this as a launch prerequisite, not as a hidden omission.

---

## 15. SEO, web performance and accessibility

**SEO:** SSR or server-rendered metadata for home, catalog and novel pages; per-novel title/description/Open Graph data; canonical URLs; structured data only when truthful and relevant; `robots.txt`, sitemap of published works only, sensible 404/410 for deleted/hidden works, noindex for auth/admin/search/internal previews. Prevent duplicate query-parameter canonicals. Do not publish random demonstration metadata or non-public chapters in production sitemap.

**Performance:** route-level code splitting, image width/height/aspect ratios, next/image for appropriate formats, priority only on the true above-fold featured/first-row artwork, font-display swap, streamed or paginated chapters, controlled hydration, server-side initial catalog retrieval. Avoid sequential API waterfalls; keep search query cancellation and cache invalidation correct. Index queries, paginate server-side, and cap serialized payloads. Document measured LCP/CLS/Lighthouse budgets rather than assuming them.

**Accessibility:** WCAG 2.2 AA target, semantic headings/landmarks, label every form control, escape/focus keyboard handling in search modal, no inaccessible clickable `<div>`, alt text for covers, visible focus and contrast, no motion-only interactions. Provide a skip link, clear validation messages, accessible spoiler reveal, appropriate image reader alt for page number/scene when available. Run `axe` checks and manual keyboard testing.

**Budgets and honest reporting:** production-build Lighthouse ≥95 Accessibility, ≥95 Best Practices, ≥95 SEO, ≥85 Performance on `/` and one novel page; LCP <2.5 s and CLS <0.1 in the documented test environment. If metrics differ on local/CI hardware, record exact reports and remediation rather than claiming automatic compliance.

---

## 16. Quality tooling, CI, documentation and delivery artifacts

Every configured script must operate on the real project. No fake green checks. **The Gemini 114 KB prototype failure mode is explicitly disallowed:** custom `node scripts/run-build.mjs` scripts that only emit manifests; `run-typecheck.mjs` that uses regex/text scans; `db-migrate.mjs` that only checks SQL tokens; Node `Map` used as the authoritative store; `src/runtime/web-server.mjs` rendering HTML-string pages instead of `next build` / App Router components; browser tests that only fetch a homepage string or simulate navigation without a real browser. A wrapper script is permissible ONLY when it invokes the genuine framework/compiler/database/browser tools and propagates nonzero exits. Include an audit in `scripts/check-production-integrity.mjs` plus an actual DB-backed integration test and Playwright browser test. A lockfile and dependencies alone do not prove use of frameworks.

**Genuine command minimum:** `pnpm --filter @noveluz/web exec next build`, `pnpm --filter @noveluz/web exec tsc --noEmit`, `pnpm --filter @noveluz/api exec tsc --noEmit`, real Prisma migration on an isolated DB, `vitest run` invoking DB-backed tests, `playwright test` opening a production build in Chromium. Never invent substitute outputs. If a tool is unavailable, say `BLOCKED` and stop short of a success claim.

**Visual gate:** Playwright real screenshots and `docs/VISUAL_QA.md` with a reviewer checklist are mandatory. Not every judgment can be machine-scored; the human review record is required. No assertion of aesthetic quality based solely on line count or file size. `scripts/check-placeholders.mjs` scans source code for accidental TODO/FIXME, forbidden `@ts-ignore`, unsafe `alert(` and dummy event handlers; exclude vendor/build outputs and deliberate fixtures/tests with documented exceptions. Do not flag legitimate `console.error` for server diagnostics or arbitrary strings inside user-controlled content. ESLint must enforce TypeScript safety, hooks, promise handling and restricted patterns.

**Required files and deliverables:**

- `README.md`: prerequisites, supported OS, Node/pnpm, copy env, secrets setup, local startup, migration, seed, commands, API and Web URLs, demo login creation, troubleshooting.
- `docs/DECISIONS.md`: dated architecture decisions and prompt ambiguities.
- `docs/UI_BRIEF.md`: the agreed Option 2 catalog-first brief, home hierarchy, anti-patterns, mobile behavior and component map.
- `docs/DESIGN_SYSTEM.md`: tokens, typography, cover card anatomy, responsive grid, component and state contracts, image licensing/origin.
- `docs/VISUAL_QA.md`: actual screenshot paths, viewport and timestamp, 23.x acceptance checklist, found issues, repairs and unresolved aesthetic decisions.
- `docs/API.md`: public API endpoints with request/response examples, auth, errors, pagination.
- `docs/SEARCH.md`: normalization tables, ranking tie-breakers, query/index architecture, false-positive policy, performance fixture and benchmark outputs.
- `docs/ADMIN_GUIDE.md`: roles, workflows, uploads, publishing, aliases, rollback/reindex.
- `docs/SECURITY.md`: threats, authorization matrix, CSRF/cookies, uploads, logging, security test results.
- `docs/DEPLOYMENT.md`: reverse proxy/TLS, env/secrets, migrations, object storage, database backups, health, monitoring and rollback.
- `docs/KNOWN_ISSUES.md`: only honest limitations with impact, workaround and next step; never use it to declare incomplete Tier A features finished.
- `PROGRESS.md`: authoritative phases, gate evidence, outstanding failures and exact resume instructions.
- `openapi.json` or generated OpenAPI route plus codegen consistency checks.
- `.github/workflows/ci.yml`: locked installs, PostgreSQL/Redis services, migrations, REAL Next/TypeScript compilation, lint/typecheck/unit/integration/build/E2E and security checks; uploaded Playwright screenshots/traces and Lighthouse reports on failure.

**Evidence rule:** after each phase append to PROGRESS.md the date, commit, commands run, exit codes and compact representative outputs. If a command could not run because the environment lacks Docker/browser/registry access, record `BLOCKED`, explain why and do not claim success. Never invent benchmark results, screenshots or green CI status. Human-only deployment steps must be explicit launch blockers if production readiness depends on them.

---

## 17. Exact implementation phases, prerequisites and gates

**Mandatory ordering:** implement **Phase 0 → Phase 12** without skipping. Each phase has a scope, deliverables and gate. Before a phase, inspect existing files and avoid rewriting completed work. Commit only after passing the phase gate; if Git author settings or Git is unavailable, record an uncommitted phase state rather than force-configuring someone else's environment. The root `pnpm verify` command must be valid from Phase 0; it can cover the suites implemented **so far** until later phases add more suites, but must never silently skip tests that already exist. Run baseline `pnpm verify` after every phase in addition to the explicit phase checks below.

### Phase 0 — Workspace bootstrap and architectural ledger

**Implement:** pnpm monorepo; locked compatible dependencies; **real** Next.js and Fastify skeletons (not HTML-string runtimes); shared TypeScript config and Zod schema package; working local `dev`, `build`, `typecheck`, `lint`, `verify` commands; lint/format settings; `.env.example`; Compose PostgreSQL/Redis base; `PROGRESS.md`; decisions, issues and README. Set up basic CI, test harness, placeholder checker and `check:production-integrity` at the outset. Create `docs/UI_BRIEF.md` and `docs/DESIGN_SYSTEM.md` from section 6; record the approved catalog-first design and component hierarchy before coding.

**Gate:** `pnpm install --frozen-lockfile`, `pnpm typecheck`, `pnpm lint`, `pnpm check:placeholders`, `pnpm build`, `pnpm verify`. Both apps start and their basic home/health response works; prove `next build` and `tsc --noEmit` actually execute, and DB config is genuine. No fake green wrappers.

### Phase 1 — Prisma schema, constraints, migrations and seeds

**Implement:** all section 7 models/enums/relations; raw SQL extensions/indexes/check constraints; DB access layer; deterministic idempotent **18+ original distinct titles and covers** for visual seed data; tests for uniqueness, references and migration invariants. Production-safe credentials.

**Gate:** `pnpm db:up`, `pnpm db:migrate`, `pnpm db:seed` (run twice without duplicating rows), DB integration tests, `pnpm verify`. Demonstrate query plans use intended indexes for representative search candidate shapes.

### Phase 2 — Authentication, account security and RBAC

**Implement:** session table, Argon2id register/login, refresh rotation/reuse detection, logout/logout-all, `/me`, profile, admin permissions and assignment checks, CSRF/origin controls. Auth UI may be created here or wired in Phase 6, but API must be testable now.

**Gate:** API integration tests for register/login/refresh/logout, invalid input, ban, privilege escalation, last-admin guard, cookie flags and token reuse; `pnpm verify`.

### Phase 3 — Catalog, chapters, files and metadata APIs

**Implement:** public catalog and detail, featured, rankings via daily aggregates, latest chapters, chapter read guards, upload adapters and secure upload pipeline, published/draft integrity. CRUD services for works/chapters needed by later admin UI.

**Gate:** Fastify integration tests for filters/pagination/publication, file validation, cover refs, chapter numbering, view ranking, unpublished/VIP exposure and no anonymous private fields; `pnpm verify`.

### Phase 4 — TZ-compliant search service

**Implement:** pure Uzbek transliteration, aliases, all six match tiers, indexed SQL retrieval, pagination, accurate metadata, chapter FTS, Redis/LRU caching and invalidation, zero-result suggestions, search analytics.

**Gate:** `pnpm test:search`, inspect cold-query plans, verify exact/typo/prefix/Cyrillic/alias/no-result/chapters with realistic fixtures, `pnpm verify`.

### Phase 5 — Bookmarks, progress, ratings and comments

**Implement:** API transactions for state and aggregate counts, profile preference endpoints, nested comments and spoiler flags, likes, ownership checks and moderation service foundations.

**Gate:** integration tests for update, delete, duplicate request, race/concurrency, invalid progress/foreign chapter ID, comment permissions, rating aggregate; `pnpm verify`.

### Phase 6 — Public shell, homepage, catalog and live search

**Implement:** the approved **Option 2 COVER-RICH CATALOG-FIRST frontend** from section 6 and 12.3: genuine Next.js App Router page, original brand assets, 18+ differentiated covers, compact featured shelf, discoverable six-column desktop / two-column mobile cover grid, elegant filters, ranking rail, latest chapter feed, continue reading, auth forms, accessible global search and real loading/error/empty states. Connect every content feature to API and PostgreSQL; no static array masquerading as DB data; no plain text-only homepage. Capture and review actual desktop and mobile screenshots before declaring PASS.

**Gate:** REAL Playwright Chromium screenshots (`home-desktop-1440.png`, `home-mobile-390.png`, `catalog-desktop.png`, `catalog-mobile.png`) at production-build URLs with seeded DB; fill ALL applicable section 23 checks; validate 18 distinct cover URLs/assets, first viewport discovery, real card routes, 2-column mobile layout and no image errors/overflow. Search dialog keyboard flow, catalog filters, persisted login, axe smoke test, `pnpm check:production-integrity` and `pnpm verify`. **If visually weak or screenshot missing, Phase 6 = FAIL regardless of test count.**

### Phase 7 — Detail page, immersive readers, user library

**Implement:** novel details, rating/bookmark/comments widgets, novel and image reader, keyboard controls, reading settings/progress, library/profile, VIP/draft protection and page navigation.

**Gate:** Playwright browse→read→resume→bookmark→rate→comment, reader preferences, mobile image handling, anonymous protected action redirection; actual `novel-detail.png` and `reader-desktop.png` screenshots inspected for readability, overlays and typography; `pnpm verify`.

### Phase 8 — Full admin panel and editorial flows

**Implement:** protected admin layout and every section 13 route; admin CRUD, uploads, draft/publish, alias editing, users/roles, moderation, settings, audit logs and background-safe reindex status.

**Gate:** comprehensive admin Playwright workflow (section 13), role-denial tests, upload/reindex/cache tests, zero dead controls, actual `admin-desktop.png` screenshot reviewed; `pnpm verify`.

### Phase 9 — SEO, accessibility and security hardening

**Implement:** OG/canonicals/sitemap/robots, CSP and security headers, error handling and throttling audit, accessible keyboard flows, performance optimizations, privacy and policy pages.

**Gate:** `pnpm test:security`, axe scans, manual keyboard checklist, Lighthouse production reports, visual QA re-review at six responsive widths, `pnpm check:production-integrity` and `pnpm verify`.

### Phase 10 — Large fixtures, performance and regression suite

**Implement:** 10k novel / 20k alias benchmark fixture, deterministic load tool, warm and cold cache stats, index analysis, all unit/integration/E2E regression suites, explicit nine TZ tests and edge cases.

**Gate:** `pnpm perf:seed`, `pnpm perf:search` (p95 <300 ms under specified baseline), full `pnpm verify`, no flaky tests across three consecutive runs. Record numbers and environment details.

### Phase 11 — Docker, CI, operational docs and deployment readiness

**Implement:** multi-stage Dockerfiles, Compose health/volumes, env validation, CI services and artifacts, OpenAPI docs, README, admin/search/security/deployment guides, backup/restore scripts and smoke tests.

**Gate:** clean build via `docker compose up --build -d`, check healthy services, `pnpm smoke`, real `next build` and `tsc`, full `pnpm verify` and CI equivalent; validate docs against actual commands. No secrets in images.

### Phase 12 — Fresh-clone audit and final acceptance

**Implement:** no new scope; reproduce setup on clean DB and clean install, complete all Tier A walkthroughs, remove accidental dead UI, resolve all blocking issues, capture evidence and write final report. Verify no features were only simulated with mocks.

**Gate:** `cp .env.example .env` (with explicitly documented local-only secret setup), `pnpm install --frozen-lockfile`, `pnpm db:up`, REAL `pnpm db:migrate`, `pnpm db:seed`, `pnpm check:production-integrity`, REAL `next build`/`tsc`/`playwright test`, `pnpm verify`, `pnpm smoke`, `docker compose up --build -d`, production build Lighthouse, p95 benchmark, documented security/RBAC checklist AND approved screenshots documented in `docs/VISUAL_QA.md`. Mark complete only with real passing evidence. If any mandatory gate is blocked, report `PARTIAL/BLOCKED` and do not claim production-ready.

**After every phase:** update `PROGRESS.md` and `docs/DECISIONS.md` before committing. Append the exact next task. A context-window failure is not a reason to start the project over.

---

## 18. Test matrix and acceptance criteria

Automated tests MUST prove behavior rather than merely checking DOM elements exist. Use a dedicated isolated test PostgreSQL DB, known seed fixture, deterministic clocks when needed, and cleanup between tests. Tests must cover 401/403/404/409/422/429 and accessible empty/error UX.

### 18.1 Nine mandatory TZ search tests

| ID | Input | Expected |
| --- | --- | --- |
| TZ-01 | `Solo Leveling` | exact normalized title ranked #1 |
| TZ-02 | `solo leving` | title found via one-edit typo route |
| TZ-03 | `sololevelingg` | title found via documented typo/normalization behavior |
| TZ-04 | `solo lev` | title found via prefix route |
| TZ-05 | `соло левелинг`, and alternate apostrophe/Cyrillic sample `oʻlmas qirol` | correct script normalization for preseeded appropriate fixture |
| TZ-06 | `Yakkalikda daraja oshirish` | matches a seeded alias for `Solo Leveling` |
| TZ-07 | `asdfghjkl123` | zero result count, no fabricated result, suggestions separate |
| TZ-08 | `limit=4`, pages 1 and 2 | stable, distinct paginated IDs and correct totals |
| TZ-09 | 10k records, 20k aliases, cache off, 200+ mixed requests | p95 below 300 ms in documented baseline |

**Do not claim TZ-05 passes** unless your fixture contains normalized Cyrillic and apostrophe-equivalent forms that truly resolve to the same record. Test `gʻ` and `oʻ` variants, title-type suffixes, aliases with spaces, short input false positives, duplicate alias hits, empty/overlong input, `AUTHOR` scope, case differences and cache invalidation after admin edits.

### 18.2 Other acceptance suites

- **Database:** duplicate username in a different case blocked; unique chapter volume+decimal number; deleting/publishing chapters preserves consistent counts; constraints work across parallel requests; seed is idempotent.
- **Auth:** refresh replay revokes family, logout invalidates session, banned account blocked, cross-origin mutation rejected, no tokens in local storage, unauthorized admin page/API forbidden.
- **RBAC:** each row of section 8 matrix plus owner/assignee checks, last-admin protection and IDOR attempts.
- **Search:** public only, drafts/VIP never leak via snippets or caches; exact outranks alias/fuzzy regardless of counts; fuzzy SQL cannot return gibberish.
- **Social:** bookmark persisted, reading progress within 0–100 and correct novel, update rating recalculates aggregate without double count, nested comment spoiler remains hidden until reveal, user cannot edit other's comment.
- **Admin:** full create→publish→search→read→edit→reindex→moderate→audit workflow; upload security; destructive confirmation; rollback of failures.
- **Web:** mobile widths, empty/loading/error, offline search, keyboard navigation, screen-reader labels, route redirects, images load and reader preferences persist. **Visual:** distinct 18+ cover assets, image-rich catalog, compact feature, correct 2-column mobile grid, no giant dead hero, no dummy counters. Section 23 screenshots pass.
- **Quality:** real browser visual snapshots (not as a substitute for behavior), Playwright traces on failures, Lighthouse/axe reports, `pnpm check:placeholders`, `pnpm check:production-integrity`, real Next/TypeScript build and working PostgreSQL integration.

---

## 19. Demonstration content and deterministic fixtures

Seed **at least 18 distinct fictional original works** spanning NOVEL, MANHWA, MANGA and MANHUA, with accurate Uzbek titles, authors/translator metadata clearly marked fictional, 2+ aliases, genre/tag links, varied statuses and **18+ distinct attractive original/generated covers with real filenames and image dimensions**. Do not reuse one generic cover or show empty card placeholders. At least 8 text works must have 3–5 short original chapters, while image-format demo works need ordered **original** demo images. Add several users with all four roles for RBAC tests, but do not distribute reusable production credentials.

For acceptance cases, create a **test-only** popular-title metadata dataset including `Solo Leveling` with alias `Yakkalikda daraja oshirish` and one suitable `O‘lmas qirol` fixture. The metadata fixtures MUST NOT include copied chapters, copyrighted cover files or unlicensed translation text. Separate test fixtures from public production seed so users never confuse them with available licensed works.

Ensure seeded cover records are accessible by the real web image loader; screenshot coverage MUST show varied nonbroken covers. For ranking, create dated view aggregates whose daily/weekly/monthly orderings are genuinely different. For comments and bookmarks, insert predictable authenticated relationships. For 10k performance testing, generate deterministic titles, aliases, authors and topics with a fixed random seed; record fixture generation time, DB size and test commands. Never use random external images or uncontrolled API content in tests.

---

## 20. Docker, production deployment, operations and recovery

Docker Compose MUST offer `postgres`, `redis`, `api`, `web` with volumes, correct service hostnames and explicit health checks. Separate development and production behavior: do not mount mutable code into production images or ship development keys. Web app cannot assume `localhost` is the API from inside a container; distinguish internal service URLs from browser-accessible URLs. Ensure migration runs once safely before serving requests, not independently in multiple racing replicas.

**Deployment runbook:** choose a documented reverse proxy (Nginx/Caddy or managed equivalent), HTTPS/TLS termination, DNS/domain setup, environment and secret storage, PostgreSQL persistent volume or managed DB, S3-compatible image storage, Redis, CDN cache rules, migrations, health endpoints, monitoring and log rotation. Describe at least one credible small-server deployment and a path toward separate managed services. Do not invent cloud credentials, a live domain, deployment status or payment integration.

**Backups:** nightly encrypted PostgreSQL backups with retention, separately protected asset backups, backup verification and a documented restore rehearsal. Database schema migration rollback guidance must distinguish backward-compatible code rollback from destructive schema down migration. Add smoke tests for homepage, catalog, search, login and admin deny/allow behavior. Document how to flush caches/rebuild search indexes without stopping public read operations longer than necessary.

**Operational targets:** health and error monitoring, no secrets in logs, reasonable upload retention, test data isolation, rate limit telemetry, disk/storage capacity checks, resource limits for Postgres and API, graceful shutdown and safe maintenance toggles. Security review and author/content licensing remain mandatory human launch approvals; do not label them as automatically satisfied by running tests.

---

## 21. Tier B enhancements (never before Tier A completion)

These features are strictly optional. Each requires an explicit default-off feature flag, hidden UI when off, a documented migration path and its own tests. Do **not** add inert buttons for them during Tier A.

- **B1: Advanced discovery:** personalized recommendations, smart synonym dictionary, saved searches; use real opt-in data, not fabricated intelligence.
- **B2: Editorial collaboration:** translation groups, chapter assignments, draft review queues and revision history.
- **B3: Reader convenience:** offline-compatible PWA shell and opt-in download of **authorized** content, text-to-speech when licensing permits.
- **B4: Community:** reports, notifications, follows, user reading lists and moderation tools.
- **B5: Monetization:** optional payment/entitlement infrastructure only after separate legal/payment/age-policy requirements, threat modeling and human authorization. No Stripe/Payme/Click or wallet/payment code in mandatory Tier A.
- **B6: Internationalization:** future multilingual UI and SEO, while Uzbek remains the only mandatory language.

For any Tier B requested later: design → threat model → migration → implement → unit/integration/E2E → flag rollout → document. Do not change the Tier A Definition of Done to include Tier B.

---

## 22. Self-review checklist, phase output protocol and final handoff

### 22.1 Self-review before each gate

Before running a phase gate verify: genuine toolchain commands (not wrappers returning fake green), genuine DB persistence and Next.js rendering; and correct strict types; Zod validation at all new boundaries; no unescaped HTML/SQL; no secrets committed; actual DB persistence for data mutations; loading/empty/error states in Uzbek; role/ownership checked on server; no duplicated route contracts; proper index/use of transaction; keyboard and mobile behavior; tests cover positive/negative paths; no unsupported claims; new env vars documented; README and decision log consistent with actual code. For public visual phases also inspect real screenshots, two-column mobile cover cards, compact hero, no placeholder covers and correct image paths.

### 22.2 Required agent output at the end of EVERY phase

Output in this exact compact structure (fill with real values, do not fabricate):

```text
PHASE: <number and name>
STATUS: PASS | FAIL | BLOCKED
FILES CREATED: <paths>
FILES MODIFIED: <paths>
DECISIONS: <important choices and reasons>
COMMANDS RUN: <actual command + exit code; trimmed key output>
TESTS: <counts; failed/skipped reasons>
SECURITY/RBAC REVIEW: <specific result>
VISUAL QA: <actual screenshot paths + inspected width + pass/fail + issues, when applicable>
KNOWN ISSUES: <none, or issue with concrete impact>
COMMIT: <real commit hash, or 'not committed' plus reason>
NEXT PHASE: <number + first action>
```

Add the same facts to PROGRESS.md, including timestamps. Never output 1,000 lines of command logs when 30 meaningful lines will do; link/file the full logs if needed. When code generation context is nearly exhausted, save complete file changes, record the exact failing command/next action and **stop cleanly rather than outputting partial files**. Never claim a future run was performed.

### 22.3 Required `PROGRESS.md` skeleton

```markdown
# NovelUZ Implementation Progress

## Environment
- Node/pnpm versions:
- OS and container environment:
- Database and Redis availability:
- Repository HEAD:

## Phases
- [ ] Phase 0 — Bootstrap
- [ ] Phase 1 — Database and seed
- [ ] Phase 2 — Authentication and RBAC
- [ ] Phase 3 — Catalog/chapter/upload API
- [ ] Phase 4 — Search engine
- [ ] Phase 5 — User interactions
- [ ] Phase 6 — Public shell/home/catalog/search
- [ ] Phase 7 — Detail/reader/library
- [ ] Phase 8 — Admin panel
- [ ] Phase 9 — SEO/a11y/security
- [ ] Phase 10 — Benchmark/regression
- [ ] Phase 11 — Docker/CI/docs
- [ ] Phase 12 — Fresh-clone acceptance

## Latest gate evidence
- Visual screenshot artifacts and reviewer notes:
- Real compiler/DB/browser tool evidence:
- Phase:
- Command:
- Exit code:
- Actual output excerpt:
- Outstanding failures:

## Next action
- First unfinished phase:
- First concrete task:
```

Use `[~]` for phase in progress and `[x]` only for a complete tested phase.

### 22.4 Final report requirements

When Phase 12 passes, the final response MUST include: repository architecture; implemented feature matrix; commands with verified exits; TZ-01 to TZ-09 status; cold-cache p50/p95 with fixture/hardware metadata; Lighthouse scores, screenshot links and section 23 VISUAL_QA assessment, accessibility test status, Docker/CI evidence, admin setup procedure without exposing credentials, security risks, deployment prerequisites and exact known issues. Provide working local URLs only when a running server has been verified. Separate `IMPLEMENTED`, `TESTED`, `DEPLOYED` and `HUMAN APPROVAL REQUIRED` status labels; one does not imply another.

### 22.5 Copy-paste recovery prompt for Claude/Codex/Cursor

> You are resuming an existing NovelUZ codebase governed by **NovelUZ Ultimate Master Prompt v3.0**. First inspect `PROGRESS.md`, `docs/DECISIONS.md`, `docs/KNOWN_ISSUES.md`, `docs/VISUAL_QA.md`, and `git log --oneline -20` (if Git is available). Identify the earliest incomplete phase, check files and real test status, then implement **only** its missing work. Never recreate an already working project or overwrite tested files unnecessarily. Do not skip implementation, invent verification output, suppress tests, use placeholders or weaken security. Run the applicable phase gate, real `next build`/`tsc`/DB tests, visual screenshot gate where required and `pnpm verify`; record real outcomes and update `PROGRESS.md`. If blocked by missing prerequisites, report the exact blocker and the smallest human action needed. Continue deterministically from the first unfinished task.

### 22.6 Immediate start instruction

**READ SECTION 23 FIRST, THEN BEGIN NOW.** If the repository is empty, start Phase 0 and create the actual files, not an architecture-only answer. If code exists, execute the resume protocol first. If it resembles the Gemini prototype (HTML-string server, Map store or fake tool scripts), document the defects and replace these with actual framework/DB infrastructure, preserving only validated reusable logic. Show the short phase plan, implement the files, run actual gates and record evidence. Do not ask permission for ordinary reversible local edits. Never claim Phase 12 done without the complete recorded evidence.

---

## 23. HARD VISUAL ACCEPTANCE CONTRACT, ANTI-FAKE AUDIT AND REJECTION CONDITIONS (NEW IN V3)

This section exists because the previous generated project **technically had many files but was visually weak and not a genuine implementation**. It is a mandatory Tier A extension, not a marketing wish list. If it contradicts an older interpretation of "hero-centric" design, this section controls the homepage.

### 23.1 Visual comparison: explicit FAIL vs PASS

| Dimension | Reject (FAIL) | Required (PASS target) |
| --- | --- | --- |
| First impression | Empty black page, small text, giant blank gradients, statistics | Recognizable reading catalog; appealing cover art dominates discovery |
| Cover presentation | Missing covers, default identical SVGs, generic colored blocks | 18+ distinct original attractive covers in seeded browsing states |
| Hierarchy | Random boxes and boilerplate sections | Clear header → short feature → browse grid → updates/ranking |
| Information density | One item per enormous row, mostly whitespace | Multi-column compact cards with readable metadata and balanced spacing |
| Mobile | Desktop shrink, clipped covers, hamburger with dead links | Two-cover grid, compact header and functional accessible mobile navigation |
| Interactions | `href="#"`, fake alerts, static filters and dummy login | Real routes, actual API calls, persisted state and meaningful loading/error |
| Brand | Default framework logo, toy emoji, generic SaaS layout | Original NovelUZ identity, consistent typography, restrained accents |
| Verification | File exists, generated PNG mockup, "looks fine" claim | Screenshots captured from running app + inspected report + actual interaction tests |

**When in doubt, favor more distinct cover artwork and better typography/layout over additional glowing boxes.** Do not pad line count. Quality is determined by rendered usability and implementation proof, not thousands of lines of boilerplate.

### 23.2 Hard screenshot protocol

1. Bring up actual Postgres, migrate, seed 18+ original titles/covers, start the real API and real Next.js production server. Record which processes listen on which ports and their health-check responses.
2. With Playwright Chromium, navigate to real `/`, `/catalog`, `/novel/[slug]`, `/novel/[slug]/chapter/[chapterNumber]`, and `/admin` using seeded access as appropriate. Capture images, no mock HTML renderer.
3. Required viewports: desktop **1440×900**, mobile **390×844**; also smoke widths 360, 768, 1024, 1920. Save images and browser console/page errors; reject missing images, navigation failures and horizontal overflow.
4. Review each screenshot for actual content density, cover differentiation, text clipping, alignment, spacing, responsive layout, legibility, header height, button hierarchy, featured size, loading-state jumps and any giant empty regions.
5. Record `PASS`, `FAIL` or `BLOCKED` and concrete remedial action per screenshot in `docs/VISUAL_QA.md`. Never assign arbitrary numerical aesthetic scores as evidence.
6. If any hard criterion fails, fix in code, rerun the real browser, overwrite the screenshot with the newly verified frame, update report and rerun Playwright flows.
7. If screenshots cannot be captured due to unavailable browser, keep the phase `BLOCKED`, clearly disclose the environment limitation; do not draw a fictional design and claim the screenshot gate passed.

### 23.3 Front page screenshot checklist (all mandatory)

- [ ] At 1440×900, the page is visually dominated by imagery/content, not empty black space or giant single-line title.
- [ ] A real featured book with visible cover appears before the main grid; curated feature remains compact, not full viewport height.
- [ ] The user can see the start of the main cover grid in or very near the first desktop viewport.
- [ ] The grid renders **distinct** recognizable covers; at wide desktop it is a dense 5–6-column row when rail layout allows.
- [ ] Every card has title, type/status and useful contextual metadata; long title layout is stable.
- [ ] Filters and ranking tabs trigger real API calls, not state-only mock data.
- [ ] At 390px viewport, catalog is 2 columns, no horizontal scroll; cover/title/metadata are usable.
- [ ] Search dialog and menu are keyboard/touch operable, close correctly, restore focus.
- [ ] No default gradient-only repeated covers, broken URL images, fake telemetry, empty boxes or generic dashboard KPIs.
- [ ] Cover card → detail → first public chapter works; back navigation behaves correctly.
- [ ] Empty/error cases do not collapse layout or invent titles; retry and filter reset work.
- [ ] Font contrast and image alt text follow accessibility guidelines; no hover-only action on mobile.

### 23.4 Anti-fake implementation checks

An agent MUST demonstrate the following, with commands and observed outputs:

- `pnpm --filter @noveluz/web exec next build` actually invokes the Next CLI. Inspect generated `.next` production artifacts and the build log; don't accept a handwritten build manifest as proof.
- `pnpm --filter @noveluz/web exec tsc --noEmit` and API equivalent actually invoke TypeScript. A syntax/typing failure should make exit code nonzero; script-only regex scanning is insufficient.
- `pnpm --filter @noveluz/api exec prisma migrate deploy` actually connects to Postgres and checks/applies committed migrations. Database tables and indexes must be confirmed via `psql` or Prisma inspector. `SELECT`/`INSERT`/`UPDATE`/`DELETE` via real API routes demonstrate persistence across service restarts.
- The Fastify routes are registered in `app.ts/server.ts` and use Prisma service/repository layer; a `Map` may cache derived reads but cannot be the source of truth. Read/write smoke test changes a record, restarts API, confirms record still exists, and cleans up.
- Playwright `page.goto()` opens the real site and verifies clicking a card, search, login and a selected admin flow. No DOM string-only assertion counts as end-to-end browser proof.
- The screenshots are generated from the running application. Verify image network requests and console errors; do not rely on a polished standalone mockup unrelated to source code.
- CI must run the same real commands on a fresh environment; unavailable CI provider access is `NOT VERIFIED`, never `CI GREEN`.
- Docker should launch actual `web` and `api` services plus `postgres` and `redis`, not only database containers. `docker compose ps` and health endpoints must support the claim.

### 23.5 Specific forbidden escapes and completion language

**Forbidden:** replacing React pages with string templates, substituting data with hardcoded JavaScript arrays, claiming "production-ready" because a ZIP exists, replacing `next build` with manifest generation, fake Prisma migrations, outputting a 400-line demo instead of the agreed product, or silently cutting features to meet context limits. Do not equate "92 files" with quality. Do not mark completed phases until real tools pass. Never inflate line count on purpose.

**If the environment is limited:** deliver all valid source files and the honest report. Mark failing/unrun gates individually. The resulting project is a `PARTIAL IMPLEMENTATION`, not a completed website. Offer precise commands for the next agent to resume; no invented deployment URL or screenshots.

### 23.6 Targeted recovery from the existing Gemini archive

If the user provides `noveluz.zip` or an extracted folder, first inventory it. Treat its search normalization logic, schema ideas, docs and test cases as candidates, not as trusted complete implementation. Review `package.json`, `scripts/run-build.mjs`, `scripts/run-typecheck.mjs`, `scripts/db-migrate.mjs`, `apps/web/src/runtime/web-server.mjs`, `apps/api/src/runtime/store.mjs` and related files for deceptive success paths and missing actual framework calls. Replace weak layers with real Next.js App Router pages, Fastify TypeScript services, Prisma/Postgres persistence and native tool commands. Record all preserved/replaced modules and rationale in `docs/DECISIONS.md`. Do not delete any user data, overwrite the original archive or deploy without explicit authorization. Recover in-place when practical; use versioned backups.

### 23.7 Final delivery acceptance checklist

The release package MUST include the actual source tree, `pnpm-lock.yaml`, tested Prisma migrations, real setup scripts, original cover assets, visual QA screenshots/report, tests and truthful setup notes. The final message MUST give:

1. What was built and what remains incomplete.
2. The real `next build`, TypeScript, migration, integration, Playwright, and screenshot gate outcomes with exact pass/fail/blocked state.
3. The real catalog-first interface screenshot paths at desktop/mobile sizes.
4. The database persistence and admin CRUD verification evidence.
5. Precise next steps for local launch; deployment readiness only when actually demonstrated.

**IMMEDIATE DIRECTIVE:** Do not start by writing an ornate 400-line `index.html`. Begin with source inventory and approved design brief, implement real Next.js/Prisma infrastructure, then make the catalog-first homepage visually compelling using real data and distinct original artwork. The proof is a running site in a browser — not a persuasive description.

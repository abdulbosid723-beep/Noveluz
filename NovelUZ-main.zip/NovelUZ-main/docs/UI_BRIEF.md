# NovelUZ UI Brief — Option 2: premium, cover-rich, catalog-first

Approved direction (master prompt §6, §12.3, §23): NovelUZ is a **cover-first discovery platform**.
The first viewport shows books, not marketing. Artwork supplies the color; the chrome stays calm.

## Audience and promise

Uzbek readers of web novels, ranobe, manhwa, manga and manhua. In under three seconds a first-time
visitor must recognise "this is a reading catalog", see one featured work, see at least six distinct
covers (desktop) or a two-cover row (mobile), and find search.

## Home hierarchy (top → bottom)

1. **Announcement bar** (only when `SiteSettings.announcementActive`), 28 px.
2. **Sticky header** (70 px): wordmark · Bosh sahifa · Katalog · Yangi boblar · Reyting · Tasodifiy asar ·
   search field (opens dialog, `Ctrl/Cmd+K`) · Xatcho‘plar · profile/entry.
3. **Featured shelf** (≈ 320–380 px desktop): one highlighted work — cover, type/status chips, title,
   2–3 line excerpt, genres, `O‘qishni boshlash` + `Batafsil` — and a column of 3–4 featured mini-covers
   that switch the highlighted work. Backdrop is a blurred, darkened crop of the active cover.
4. **Main row** (two columns ≥ 1360 px): left = `Trenddagi asarlar` 5–6-column cover grid with type tabs
   (Hammasi / Novel / Manhwa / Manga / Manhua) that update the URL and the API query; right = ranking
   rail (`Reyting`, kun / hafta / oy tabs from real daily aggregates).
5. **Continue reading** strip — only for signed-in users with real progress.
6. **Genre chips** → link into `/catalog?genre=…`.
7. **Yangi boblar** feed — compact rows: thumbnail, work, chapter, relative time.
8. **Yangi qo‘shilganlar** cover grid (recently published works).
9. **Footer** — navigation, legal drafts (Foydalanish shartlari, Maxfiylik), contact for takedowns.

## Anti-patterns (rejected)

Full-viewport hero, gradient-only or repeated covers, KPI/statistics boxes ("1000+ o‘quvchi"), public
latency badges, glassmorphism everywhere, text-only cards, `href="#"`, fake progress, English labels.

## Mobile (360–767 px)

Compact header (logo, search icon, menu button opening an accessible drawer), compact featured card
(cover 112 px wide + text), then the **2-column** cover grid with 12 px gaps. Ranking and latest
chapters stack below. No horizontal scroll; touch targets ≥ 44 px.

## Route / component map

| Route                                      | Server page                     | Key components                                                                                                                             |
| ------------------------------------------ | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| `/`                                        | `app/(public)/page.tsx`         | `SiteHeader`, `FeaturedShelf`, `HomeDiscovery`, `NovelCoverCard`, `RankingRail`, `ContinueReadingStrip`, `LatestChapterFeed`, `SiteFooter` |
| `/catalog`                                 | `app/(public)/catalog/page.tsx` | `CatalogFilterBar`, cover grid, `Pagination`, empty/error states                                                                           |
| `/new`                                     | `app/(public)/new/page.tsx`     | `LatestChapterFeed` (paginated)                                                                                                            |
| `/ranking`                                 | `app/(public)/ranking/page.tsx` | period tabs, ranked list                                                                                                                   |
| `/search`                                  | `app/(public)/search/page.tsx`  | full-page catalog + chapter search                                                                                                         |
| `/novel/[slug]`                            | detail                          | cover/banner header, chapters, rating, bookmark, comments                                                                                  |
| `/novel/[slug]/chapter/[n]`                | reader                          | text reader / vertical image strip, settings panel                                                                                         |
| `/login`, `/register`                      | auth                            | RHF + Zod forms                                                                                                                            |
| `/library`, `/profile`, `/settings/reader` | account                         | bookmarks by list, profile & password, reader prefs                                                                                        |
| `/admin/**`                                | protected layout                | dashboard, novels, chapters, taxonomy, users, comments, settings                                                                           |

Global: `GlobalSearchDialog` (Ctrl/Cmd+K), skip link, mobile drawer, toast region.

# Known Issues

Only honest, current limitations. Each entry: impact → workaround → next step.

## Build environment (agent sandbox)

- **No container runtime in the build sandbox.** `docker`/`podman` exist but fail (`could not find a working conmon binary`).
  Impact: `pnpm db:up` via Compose, `docker compose up --build` and Redis cannot be exercised here.
  Workaround: PostgreSQL 18.1 runs from official binaries via `scripts/local-pg.mjs`; the API uses its in-memory cache fallback.
  Next step: run `docker compose up --build -d` on a host with Docker and record the result in PROGRESS.md (Phase 11 gate).
- **Processes do not survive between agent shell invocations.** Every gate that needs PostgreSQL is executed inside one
  `node scripts/local-pg.mjs run -- <command>` invocation, which starts the server, runs the command and stops it.

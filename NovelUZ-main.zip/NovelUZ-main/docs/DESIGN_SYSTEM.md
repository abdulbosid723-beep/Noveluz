# NovelUZ Design System

Source of truth: `apps/web/src/styles/globals.css` (CSS variables, exposed to Tailwind v4 via `@theme inline`).

## Tokens

| Token                           | Value                   | Use                                                                     |
| ------------------------------- | ----------------------- | ----------------------------------------------------------------------- |
| `--bg-base`                     | `#0b0d13`               | page background                                                         |
| `--bg-surface`                  | `#131722`               | cards, header, panels                                                   |
| `--bg-elevated`                 | `#1a2030`               | popovers, hovered rows, inputs                                          |
| `--bg-soft`                     | `#181b27`               | quiet section backgrounds                                               |
| `--primary` / `--primary-hover` | `#818cf8` / `#a5b4fc`   | links, active tabs, primary button (dark ink on indigo: 6.5:1)          |
| `--accent`                      | `#f4ba61`               | genuine rating stars, featured marker only                              |
| `--success` / `--danger`        | `#34d399` / `#fb7185`   | status, destructive actions                                             |
| `--text-primary`                | `#f5f6fb`               | headings, titles (18.0:1 on base, 16.6:1 on surface)                    |
| `--text-secondary`              | `#afb8ce`               | body/meta (9.8:1 on base, 9.0:1 on surface)                             |
| `--text-muted`                  | `#8792a8`               | tertiary meta (6.2:1 on base, 5.7:1 on surface, 5.2:1 on elevated — AA) |
| `--border`                      | `rgba(220,228,250,.12)` | hairlines                                                               |
| radii                           | 6 / 9 / 14 / 20 px      | chips / buttons, inputs / cards / sheets                                |

Tailwind aliases: `bg-base bg-surface bg-elevated bg-soft text-fg text-fg-2 text-fg-3 border-line
text-primary bg-primary text-accent`.

## Typography

- UI & headings: **Plus Jakarta Sans** (`next/font`, `display: swap`, latin + latin-ext).
- Reading: **Literata** (latin, latin-ext, cyrillic).
- Scale: masthead 28–34 px / 700; section heading 20–24 px / 700; card title 14 px / 600, two lines
  (`line-clamp-2`); card meta 12 px / 500; body 15–16 px; reader 14–28 px user-selected.

## Cover card anatomy (`NovelCoverCard`)

```
┌──────────────┐  2:3 cover image (next/image via API asset loader, fixed aspect ratio)
│ [Manhwa] ★4.6│  type chip (top-left, solid dark), rating chip only when ratingCount > 0
│              │
│   artwork    │  hover/focus: 1.035 scale on image, ring + lift on card (160 ms)
│              │
└──────────────┘
Title in two lines (14 px, 600)
Bob 12 · Davom etmoqda   (12 px, muted)
```

- The whole card is one `<a href="/novel/[slug]">`; `alt` = title + type.
- Missing / failed image → honest fallback panel with the title set in type, never a fake cover.
- Long titles clamp to two lines; height is stable across the grid.

## Grid contract

`.cover-grid`: 2 cols < 640 px · 3 cols ≥ 640 · 4 cols ≥ 900 · 5 cols ≥ 1180 · 6 cols ≥ 1360.
With the ranking rail (`data-rail="true"`) the grid drops one column at ≥ 1360 px (5 + rail).
Gaps 12 px mobile, 16–18 px desktop. Content max width 1440 px with 16 / 28 / 36 px gutters.

## Components and states

- **Buttons**: primary (indigo fill, dark ink), secondary (surface + border), ghost; 40 px default, 44 px touch.
- **Chips**: 28 px, radius 999, used for genres/types; active = indigo tint + border.
- **Tabs**: underline indicator; `role="tablist"` with arrow-key support.
- Every data region has: skeleton (same dimensions as content), empty state (Uzbek message + action),
  error state (`Qayta urinish` button that refetches).
- Focus: 2 px `--primary-hover` outline, 2 px offset, always visible for keyboard users.
- Motion: 120–220 ms; disabled by `prefers-reduced-motion`.

## Imagery and licensing

All 18+ demo covers are **original SVG illustrations authored for NovelUZ** in
`apps/api/prisma/seed/covers/` (distinct scene per title: mountains, cities, sea, desert, space,
forest, etc.), rasterised to WebP by `sharp` during seeding and stored as `UploadAsset` rows.
No external, copyrighted or hot-linked artwork is used. Manhwa/manga demo pages are likewise
generated original panel art. The wordmark/icon (`apps/web/public/icon.svg`, `Logo` component) is original.

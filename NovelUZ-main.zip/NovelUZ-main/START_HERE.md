# NovelUZ v3.0 — Agentga yuborish uchun START PROMPT

You are implementing **NovelUZ Ultimate Master Prompt v3.0 — Catalog-First Premium Edition**. The accompanying `.md` file is the authoritative full specification, including mandatory section 23. Read the entire document before making architectural decisions. **Do not replace the 23-section specification with this start instruction.**

The user has explicitly chosen **Option 2: a premium, visually rich, cover-first catalog**. Avoid empty heroes, fake statistics, generic SaaS UI and text-only cards. Keep a compact featured shelf and show real book/manhwa covers early in the first viewport. Mobile must have two columns at 390px.

If a workspace or the previous Gemini `noveluz.zip` exists, inventory before coding. Preserve validated assets and functions, but reject manifest-only fake build/typecheck, dummy migrations, HTML-string web servers and in-memory Map stores masquerading as PostgreSQL. Do not equate file count with completion.

Start Phase 0 (or first unfinished phase in PROGRESS.md). Use real Next.js App Router, TypeScript, Fastify, Prisma and PostgreSQL. Create UI_BRIEF and DESIGN_SYSTEM first, then implement and test progressively. Execute native framework/compiler/database/browser tests; every phase needs real evidence, and public UI phases need Playwright Chromium screenshots and `docs/VISUAL_QA.md` review. If tools are unavailable, state BLOCKED rather than claiming PASS.

Deliver source code, not a long description. Record every actual result and resume point. Never omit the required functionality just to present a pretty static prototype.

-- Creates the isolated database used by integration/E2E tests (docker compose only).
CREATE DATABASE noveluz_test OWNER noveluz;

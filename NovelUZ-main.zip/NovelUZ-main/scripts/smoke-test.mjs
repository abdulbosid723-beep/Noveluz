#!/usr/bin/env node
/**
 * Post-deploy smoke test against RUNNING services.
 *   SMOKE_WEB_URL (default http://localhost:3000), SMOKE_API_URL (default http://localhost:4000)
 * Optional SMOKE_ADMIN_LOGIN / SMOKE_ADMIN_PASSWORD verify the admin allow path.
 */
import { loadRootEnv, out } from './lib/env.mjs';

loadRootEnv();
const WEB = process.env.SMOKE_WEB_URL ?? 'http://localhost:3000';
const API = process.env.SMOKE_API_URL ?? 'http://localhost:4000';
const results = [];

async function check(name, fn) {
  try {
    await fn();
    results.push({ name, ok: true });
  } catch (error) {
    results.push({ name, ok: false, error: error instanceof Error ? error.message : String(error) });
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

await check('API liveness', async () => {
  const res = await fetch(`${API}/health/live`);
  assert(res.status === 200, `status ${res.status}`);
});
await check('API readiness (database up)', async () => {
  const res = await fetch(`${API}/health/ready`);
  const body = await res.json();
  assert(res.status === 200 && body.database === 'up', `status ${res.status} ${JSON.stringify(body)}`);
});
await check('homepage renders catalog covers', async () => {
  const res = await fetch(`${WEB}/`);
  const html = await res.text();
  assert(res.status === 200, `status ${res.status}`);
  assert(html.includes('lang="uz"'), 'missing lang="uz"');
  assert(/\/api\/assets\/[0-9a-f-]{36}/.test(html), 'no cover asset URLs in homepage HTML');
});
await check('catalog page', async () => {
  const res = await fetch(`${WEB}/catalog`);
  assert(res.status === 200, `status ${res.status}`);
});
await check('catalog search through web proxy', async () => {
  const res = await fetch(`${WEB}/api/search/catalog?q=a&limit=3`);
  const body = await res.json();
  assert(res.status === 200 && Array.isArray(body.data?.results), `status ${res.status}`);
});
await check('gibberish search returns zero results', async () => {
  const res = await fetch(`${API}/api/search/catalog?q=asdfghjkl123`);
  const body = await res.json();
  assert(res.status === 200 && body.meta.total === 0 && body.data.results.length === 0, JSON.stringify(body.meta));
});
await check('login rejects bad credentials', async () => {
  const res = await fetch(`${API}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ login: 'nobody-smoke', password: 'wrong-password-1' }),
  });
  assert(res.status === 401, `status ${res.status}`);
});
await check('admin API denies anonymous access', async () => {
  const res = await fetch(`${API}/api/admin/stats`);
  assert(res.status === 401, `status ${res.status}`);
});
if (process.env.SMOKE_ADMIN_LOGIN && process.env.SMOKE_ADMIN_PASSWORD) {
  await check('admin API allows an administrator', async () => {
    const login = await fetch(`${API}/api/auth/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ login: process.env.SMOKE_ADMIN_LOGIN, password: process.env.SMOKE_ADMIN_PASSWORD }),
    });
    assert(login.status === 200, `login status ${login.status}`);
    const cookie = login.headers
      .getSetCookie()
      .map((c) => c.split(';')[0])
      .join('; ');
    const res = await fetch(`${API}/api/admin/stats`, { headers: { cookie } });
    assert(res.status === 200, `stats status ${res.status}`);
  });
}

for (const r of results) out(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.ok ? '' : ` — ${r.error}`}`);
const failed = results.filter((r) => !r.ok).length;
if (failed > 0) {
  console.error(`smoke FAILED (${failed}/${results.length})`);
  process.exit(1);
}
out(`smoke OK (${results.length} checks)`);

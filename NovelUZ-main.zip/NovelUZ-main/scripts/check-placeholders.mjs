#!/usr/bin/env node
/**
 * Fails when source code contains placeholder/unsafe patterns:
 * TODO/FIXME markers, @ts-ignore/@ts-nocheck, alert(), console.log, lorem ipsum,
 * `any` types, href="#", "coming soon" copy, empty click handlers and elided-code markers.
 * Scans hand-written sources only (generated Prisma client, builds and vendor code excluded).
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { ROOT, out } from './lib/env.mjs';

const SCAN_DIRS = [
  'apps/api/src',
  'apps/api/prisma',
  'apps/api/tests',
  'apps/api/scripts',
  'apps/web/src',
  'apps/web/tests',
  'packages/shared/src',
  'scripts',
];
const EXTENSIONS = new Set(['.ts', '.tsx', '.mjs', '.js', '.css']);
const EXCLUDED_DIRS = new Set(['node_modules', 'generated', 'dist', '.next', 'migrations']);
const SELF = path.join(ROOT, 'scripts', 'check-placeholders.mjs');

const RULES = [
  { name: 'TODO marker', re: /\bTODO\b/ },
  { name: 'FIXME marker', re: /\bFIXME\b/ },
  { name: '@ts-ignore', re: /@ts-ignore/ },
  { name: '@ts-nocheck', re: /@ts-nocheck/ },
  { name: 'alert() call', re: /(^|[^.\w])alert\(/ },
  { name: 'console.log', re: /console\.log\(/ },
  { name: 'lorem ipsum', re: /lorem ipsum/i },
  { name: 'explicit any', re: /(:\s*any\b|\bas any\b|<any>|any\[\])/, tsOnly: true },
  { name: 'dead href="#"', re: /href=["']#["']/ },
  { name: '"coming soon" copy', re: /coming soon|tez orada qo.shiladi/i },
  { name: 'empty click handler', re: /on[A-Z]\w*=\{\(\)\s*=>\s*\{\s*\}\}/ },
  { name: 'elided code marker', re: /\.\.\.\s*(existing|rest of) (code|file)/i },
];

function* walk(dir) {
  let entries;
  try {
    entries = readdirSync(dir);
  } catch {
    return;
  }
  for (const entry of entries) {
    if (EXCLUDED_DIRS.has(entry)) continue;
    const full = path.join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) yield* walk(full);
    else if (EXTENSIONS.has(path.extname(entry))) yield full;
  }
}

const findings = [];
let files = 0;
for (const rel of SCAN_DIRS) {
  for (const file of walk(path.join(ROOT, rel))) {
    if (file === SELF) continue;
    files += 1;
    const isTs = file.endsWith('.ts') || file.endsWith('.tsx');
    const lines = readFileSync(file, 'utf8').split('\n');
    lines.forEach((line, i) => {
      for (const rule of RULES) {
        if (rule.tsOnly && !isTs) continue;
        if (rule.re.test(line))
          findings.push(`${path.relative(ROOT, file)}:${i + 1}  ${rule.name}: ${line.trim().slice(0, 120)}`);
      }
    });
  }
}

if (findings.length > 0) {
  console.error(`check:placeholders FAILED — ${findings.length} finding(s) in ${files} files:`);
  for (const f of findings) console.error(`  ${f}`);
  process.exit(1);
}
out(`check:placeholders OK — scanned ${files} files, 0 findings`);

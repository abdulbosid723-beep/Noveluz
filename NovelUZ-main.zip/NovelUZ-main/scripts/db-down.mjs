#!/usr/bin/env node
import { existsSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { ROOT } from './lib/env.mjs';

if (existsSync(path.join(ROOT, '.local', 'pgdata', 'postmaster.pid'))) {
  spawnSync('node', ['scripts/local-pg.mjs', 'stop'], { cwd: ROOT, stdio: 'inherit' });
}
const probe = spawnSync('docker', ['compose', 'version'], { stdio: 'ignore' });
if (probe.status === 0) {
  const res = spawnSync('docker', ['compose', 'stop', 'postgres', 'redis'], { cwd: ROOT, stdio: 'inherit' });
  process.exit(res.status ?? 0);
}

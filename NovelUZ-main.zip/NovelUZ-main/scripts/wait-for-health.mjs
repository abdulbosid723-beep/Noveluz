#!/usr/bin/env node
/** Usage: node scripts/wait-for-health.mjs <url> [timeoutSeconds] — polls until HTTP 200. */
import { out } from './lib/env.mjs';
const [url, timeoutArg] = process.argv.slice(2);
if (!url) {
  console.error('usage: wait-for-health.mjs <url> [timeoutSeconds]');
  process.exit(2);
}
const deadline = Date.now() + Number(timeoutArg ?? 60) * 1000;
for (;;) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(3000) });
    if (res.status === 200) {
      out(`[wait-for-health] ${url} → 200`);
      process.exit(0);
    }
  } catch {
    // not up yet
  }
  if (Date.now() > deadline) {
    console.error(`[wait-for-health] timed out waiting for ${url}`);
    process.exit(1);
  }
  await new Promise((r) => setTimeout(r, 500));
}

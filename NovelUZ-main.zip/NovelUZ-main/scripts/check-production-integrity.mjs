#!/usr/bin/env node
/**
 * Anti-fake audit (master prompt §16 / §23.4):
 *  1. Package scripts must invoke the genuine tools (next, tsc, eslint, prisma, vitest, playwright).
 *  2. Known fake-runtime files from the rejected prototype must not exist.
 *  3. The Fastify app must be wired to Prisma (no in-memory primary store).
 *  4. A LIVE smoke test starts the real API on a random port against the test
 *     PostgreSQL database and performs an HTTP write → read → cleanup.
 */
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { ROOT, loadRootEnv, out } from './lib/env.mjs';

loadRootEnv();
const failures = [];
const pass = [];
const readJson = (p) => JSON.parse(readFileSync(path.join(ROOT, p), 'utf8'));

function expectScript(pkgPath, name, pattern) {
  const script = readJson(pkgPath).scripts?.[name] ?? '';
  if (pattern.test(script)) pass.push(`${pkgPath} "${name}" → ${script}`);
  else failures.push(`${pkgPath} script "${name}" must match ${pattern} (got: "${script}")`);
}

expectScript('apps/web/package.json', 'build', /^next build$/);
expectScript('apps/web/package.json', 'typecheck', /\btsc\b.*--noEmit/);
expectScript('apps/web/package.json', 'test:e2e', /\bplaywright test\b/);
expectScript('apps/api/package.json', 'build', /\btsc\b/);
expectScript('apps/api/package.json', 'typecheck', /\btsc\b.*--noEmit/);
expectScript('apps/api/package.json', 'db:migrate', /^prisma migrate deploy$/);
expectScript('apps/api/package.json', 'test:integration', /^vitest run\b/);
expectScript('apps/api/package.json', 'test:unit', /^vitest run\b/);
expectScript('packages/shared/package.json', 'typecheck', /\btsc\b.*--noEmit/);
expectScript('package.json', 'lint', /^eslint\b/);

const forbidden = [
  'scripts/run-build.mjs',
  'scripts/run-typecheck.mjs',
  'scripts/db-migrate.mjs',
  'apps/web/src/runtime/web-server.mjs',
  'apps/api/src/runtime/store.mjs',
];
for (const f of forbidden) {
  if (existsSync(path.join(ROOT, f))) failures.push(`forbidden fake-runtime file present: ${f}`);
}
pass.push('no fake-runtime files from the rejected prototype');

const required = [
  'apps/web/src/app/layout.tsx',
  'apps/web/next.config.ts',
  'apps/api/prisma/schema.prisma',
  'apps/api/src/app.ts',
  'apps/api/src/lib/prisma.ts',
];
for (const f of required)
  if (!existsSync(path.join(ROOT, f))) failures.push(`required real-framework file missing: ${f}`);
const migrations = path.join(ROOT, 'apps/api/prisma/migrations/migration_lock.toml');
if (!existsSync(migrations)) failures.push('no committed Prisma migrations');
const appSource = readFileSync(path.join(ROOT, 'apps/api/src/app.ts'), 'utf8');
if (!/createPrisma\(/.test(appSource)) failures.push('apps/api/src/app.ts does not construct the Prisma client');
else pass.push('Fastify app constructs the Prisma client');

if (failures.length === 0) {
  out('[integrity] static checks passed; running live API ↔ PostgreSQL smoke test');
  const res = spawnSync('pnpm', ['--filter', '@noveluz/api', 'exec', 'tsx', 'scripts/integrity-smoke.ts'], {
    cwd: ROOT,
    stdio: 'inherit',
    env: process.env,
  });
  if (res.status !== 0) failures.push(`live API ↔ PostgreSQL smoke test failed (exit ${res.status})`);
  else pass.push('live API ↔ PostgreSQL write/read/cleanup smoke test');
}

for (const p of pass) out(`  ✓ ${p}`);
if (failures.length > 0) {
  console.error('check:production-integrity FAILED:');
  for (const f of failures) console.error(`  ✗ ${f}`);
  process.exit(1);
}
out('check:production-integrity OK');

#!/usr/bin/env node
/**
 * `pnpm verify` — runs the REAL quality gates in a stable order and stops at the
 * first failure (non-zero exit propagates). No step is skipped silently.
 *   typecheck → lint → check:placeholders → check:production-integrity →
 *   test:unit → test:integration → build → test:e2e
 */
import { spawnSync } from 'node:child_process';
import { ROOT, loadRootEnv, out } from './lib/env.mjs';

loadRootEnv();

const steps = [
  'typecheck',
  'lint',
  'check:placeholders',
  'check:production-integrity',
  'test:unit',
  'test:integration',
  'build',
  'test:e2e',
];

const results = [];
for (const step of steps) {
  const started = Date.now();
  out(`\n━━━ verify: pnpm ${step} ━━━`);
  const res = spawnSync('pnpm', ['run', step], { cwd: ROOT, stdio: 'inherit', env: process.env });
  const seconds = ((Date.now() - started) / 1000).toFixed(1);
  results.push({ step, code: res.status ?? 1, seconds });
  if (res.status !== 0) break;
}

out('\n━━━ verify summary ━━━');
for (const r of results) out(`  ${r.code === 0 ? 'PASS' : 'FAIL'}  ${r.step.padEnd(28)} exit=${r.code}  ${r.seconds}s`);
const failed = results.find((r) => r.code !== 0);
if (failed || results.length !== steps.length) {
  console.error(`verify FAILED at "${failed?.step ?? 'unknown'}"`);
  process.exit(1);
}
out('verify OK — all gates passed');

#!/usr/bin/env node
/**
 * Starts PostgreSQL (and Redis) for local development.
 * Primary: `docker compose up -d postgres redis`.
 * Fallback when no working container runtime exists: the embedded PostgreSQL
 * binaries via scripts/local-pg.mjs (Redis is then absent and the API uses its
 * bounded in-memory cache fallback).
 */
import { spawnSync } from 'node:child_process';
import { ROOT } from './lib/env.mjs';

const probe = spawnSync('docker', ['compose', 'version'], { stdio: 'ignore' });
const info = probe.status === 0 ? spawnSync('docker', ['info'], { stdio: 'ignore' }) : probe;
if (probe.status === 0 && info.status === 0) {
  const res = spawnSync('docker', ['compose', 'up', '-d', '--wait', 'postgres', 'redis'], {
    cwd: ROOT,
    stdio: 'inherit',
  });
  process.exit(res.status ?? 1);
}
console.warn('[db:up] Docker is unavailable; starting embedded PostgreSQL instead (no Redis).');
const res = spawnSync('node', ['scripts/local-pg.mjs', 'start'], { cwd: ROOT, stdio: 'inherit' });
process.exit(res.status ?? 1);

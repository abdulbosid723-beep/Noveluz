#!/usr/bin/env node
/**
 * Local PostgreSQL without Docker, using the official PostgreSQL binaries
 * shipped by the `@embedded-postgres/<platform>` package (contains contrib
 * extensions pg_trgm, unaccent and fuzzystrmatch).
 *
 *   node scripts/local-pg.mjs start        # start as a background daemon (pg_ctl)
 *   node scripts/local-pg.mjs stop
 *   node scripts/local-pg.mjs status
 *   node scripts/local-pg.mjs run -- <cmd> # start, run <cmd> with the DB available, stop
 *
 * This is a real PostgreSQL server, not an emulator. Docker Compose remains
 * the primary path (`pnpm db:up`); this fallback exists for hosts without a
 * container runtime. Data lives in .local/pgdata (git-ignored).
 */
import { spawn, spawnSync } from 'node:child_process';
import { chownSync, existsSync, mkdirSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import net from 'node:net';
import path from 'node:path';
import { ROOT, loadRootEnv, requireEnv, out } from './lib/env.mjs';

loadRootEnv();

const require = createRequire(import.meta.url);
const DATA_DIR = path.join(ROOT, '.local', 'pgdata');
const NOBODY = 65534;

function binDir() {
  const pkg = `@embedded-postgres/${process.platform}-${process.arch}`;
  const dir = path.join(ROOT, 'node_modules', pkg, 'native', 'bin');
  if (!existsSync(path.join(dir, 'postgres'))) {
    console.error(`[local-pg] ${pkg} is not installed. Use Docker (pnpm db:up) or install PostgreSQL 16+.`);
    process.exit(1);
  }
  return dir;
}

const BIN = binDir();
const isRoot = typeof process.getuid === 'function' && process.getuid() === 0;

/** PostgreSQL refuses to run as root; drop to `nobody` when necessary. */
function cmd(binary, args) {
  const exe = path.join(BIN, binary);
  if (!isRoot) return { file: exe, args };
  return { file: 'setpriv', args: [`--reuid=${NOBODY}`, `--regid=${NOBODY}`, '--clear-groups', exe, ...args] };
}

function chownRecursive(dir) {
  chownSync(dir, NOBODY, NOBODY);
  for (const entry of readdirSync(dir)) {
    const p = path.join(dir, entry);
    const st = statSync(p);
    chownSync(p, NOBODY, NOBODY);
    if (st.isDirectory()) chownRecursive(p);
  }
}

function connectionInfo() {
  const url = new URL(requireEnv('DATABASE_URL'));
  const testUrl = process.env.TEST_DATABASE_URL ? new URL(process.env.TEST_DATABASE_URL) : null;
  return {
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    port: Number(url.port || 5432),
    databases: [url.pathname.slice(1), testUrl?.pathname.slice(1)].filter(Boolean),
  };
}

function initIfNeeded(info) {
  if (existsSync(path.join(DATA_DIR, 'PG_VERSION'))) return;
  mkdirSync(DATA_DIR, { recursive: true });
  const pwFile = path.join(ROOT, '.local', 'pwfile');
  writeFileSync(pwFile, info.password, { mode: 0o600 });
  if (isRoot) {
    chownRecursive(path.join(ROOT, '.local'));
  }
  const { file, args } = cmd('initdb', [
    '-D',
    DATA_DIR,
    '-U',
    info.user,
    `--pwfile=${pwFile}`,
    '--auth=scram-sha-256',
    '-E',
    'UTF8',
    '--locale=C.UTF-8',
  ]);
  const res = spawnSync(file, args, { stdio: 'inherit' });
  rmSync(pwFile, { force: true });
  if (res.status !== 0) {
    console.error('[local-pg] initdb failed');
    process.exit(res.status ?? 1);
  }
}

function serverArgs(info) {
  return ['-D', DATA_DIR, '-p', String(info.port), '-k', DATA_DIR, '-c', 'listen_addresses=127.0.0.1'];
}

function waitForPort(port, timeoutMs = 30_000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const attempt = () => {
      const socket = net.connect(port, '127.0.0.1');
      socket.once('connect', () => {
        socket.end();
        resolve();
      });
      socket.once('error', () => {
        socket.destroy();
        if (Date.now() - started > timeoutMs) reject(new Error(`PostgreSQL did not open port ${port}`));
        else setTimeout(attempt, 250);
      });
    };
    attempt();
  });
}

async function ensureDatabases(info) {
  const pg = require(require.resolve('pg', { paths: [path.join(ROOT, 'apps', 'api')] }));
  const client = new pg.Client({
    host: '127.0.0.1',
    port: info.port,
    user: info.user,
    password: info.password,
    database: 'postgres',
  });
  // The server may accept TCP before it accepts logins; retry briefly.
  for (let i = 0; ; i += 1) {
    try {
      await client.connect();
      break;
    } catch (error) {
      if (i > 40) throw error;
      await new Promise((r) => setTimeout(r, 250));
    }
  }
  for (const db of info.databases) {
    const exists = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [db]);
    if (exists.rowCount === 0) {
      await client.query(`CREATE DATABASE "${db.replace(/"/g, '')}"`);
      out(`[local-pg] created database ${db}`);
    }
  }
  await client.end();
}

function removeStalePid() {
  const pid = path.join(DATA_DIR, 'postmaster.pid');
  if (existsSync(pid)) {
    const { file, args } = cmd('pg_ctl', ['-D', DATA_DIR, 'status']);
    const res = spawnSync(file, args, { stdio: 'ignore' });
    if (res.status !== 0) rmSync(pid, { force: true });
  }
}

async function start(info) {
  initIfNeeded(info);
  removeStalePid();
  const { file, args } = cmd('pg_ctl', [
    '-D',
    DATA_DIR,
    '-l',
    path.join(DATA_DIR, 'server.log'),
    '-o',
    serverArgs(info).slice(2).join(' '),
    '-w',
    'start',
  ]);
  const res = spawnSync(file, args, { stdio: 'inherit' });
  if (res.status !== 0) process.exit(res.status ?? 1);
  await waitForPort(info.port);
  await ensureDatabases(info);
  out(`[local-pg] PostgreSQL ready on 127.0.0.1:${info.port}`);
}

function stop() {
  const { file, args } = cmd('pg_ctl', ['-D', DATA_DIR, '-m', 'fast', 'stop']);
  const res = spawnSync(file, args, { stdio: 'inherit' });
  process.exit(res.status ?? 0);
}

async function run(info, command) {
  if (command.length === 0) {
    console.error('[local-pg] usage: local-pg.mjs run -- <command...>');
    process.exit(2);
  }
  initIfNeeded(info);
  removeStalePid();
  const { file, args } = cmd('postgres', serverArgs(info));
  const server = spawn(file, args, { stdio: ['ignore', 'ignore', 'pipe'] });
  let serverLog = '';
  server.stderr.on('data', (d) => {
    serverLog = (serverLog + d.toString()).slice(-8000);
  });
  const stopServer = () => {
    if (server.exitCode === null) server.kill('SIGINT');
  };
  process.on('SIGINT', stopServer);
  process.on('SIGTERM', stopServer);
  try {
    await waitForPort(info.port);
    await ensureDatabases(info);
  } catch (error) {
    console.error(`[local-pg] failed to start: ${error.message}\n${serverLog}`);
    stopServer();
    process.exit(1);
  }
  out(`[local-pg] PostgreSQL ready on 127.0.0.1:${info.port}; running: ${command.join(' ')}`);
  const child = spawn(command[0], command.slice(1), { stdio: 'inherit', shell: command.length === 1 });
  const code = await new Promise((resolve) => child.on('exit', (c) => resolve(c ?? 1)));
  stopServer();
  await new Promise((resolve) => (server.exitCode === null ? server.on('exit', resolve) : resolve()));
  process.exit(code);
}

const [action, ...rest] = process.argv.slice(2);
const info = connectionInfo();
switch (action) {
  case 'start':
    await start(info);
    break;
  case 'stop':
    stop();
    break;
  case 'status': {
    const { file, args } = cmd('pg_ctl', ['-D', DATA_DIR, 'status']);
    process.exit(spawnSync(file, args, { stdio: 'inherit' }).status ?? 1);
    break;
  }
  case 'run':
    await run(info, rest[0] === '--' ? rest.slice(1) : rest);
    break;
  default:
    console.error('usage: local-pg.mjs <start|stop|status|run -- cmd>');
    process.exit(2);
}

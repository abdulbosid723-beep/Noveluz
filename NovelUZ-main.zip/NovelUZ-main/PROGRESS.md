# NovelUZ Implementation Progress

## Environment

- Node/pnpm versions: Node v22.23.4, pnpm 12.21.0 (corepack)
- OS and container environment: Amazon Linux 2023 agent sandbox, 8 vCPU, 30 GiB RAM. Docker/podman present but
  non-functional (`could not find a working conmon binary`) → **Docker gates BLOCKED here**. Background processes do
  not survive between shell invocations, so DB-dependent gates run inside `node scripts/local-pg.mjs run -- <cmd>`.
- Database and Redis availability: PostgreSQL **18.1** (official binaries from `@embedded-postgres/linux-x64`, run as
  uid `nobody`) with pg_trgm, unaccent, fuzzystrmatch. Redis: **not available** → API uses bounded LRU fallback.
- Browser: Playwright 1.65.1 Chromium headless shell 159 (installed, launches).
- Repository HEAD: see `git log --oneline -20`.

## Phases

- [x] Phase 0 — Bootstrap
- [ ] Phase 1 — Database and seed
- [ ] Phase 2 — Authentication and RBAC
- [ ] Phase 3 — Catalog/chapter/upload API
- [ ] Phase 4 — Search engine
- [ ] Phase 5 — User interactions
- [ ] Phase 6 — Public shell/home/catalog/search
- [ ] Phase 7 — Detail/reader/library
- [ ] Phase 8 — Admin panel
- [ ] Phase 9 — SEO/a11y/security
- [ ] Phase 10 — Benchmark/regression
- [ ] Phase 11 — Docker/CI/docs
- [ ] Phase 12 — Fresh-clone acceptance

## Gate evidence

### Phase 0 — Bootstrap (2026-11-18) — PASS

Implemented: pnpm monorepo (`apps/api`, `apps/web`, `packages/shared`), strict TS config, ESLint flat config
(typescript-eslint strictTypeChecked + next core-web-vitals), Prettier, real Next.js 16 App Router skeleton with
Tailwind 4 tokens, real Fastify 5 app (helmet, CORS, cookies, rate-limit, multipart, OpenAPI 3.1, Zod type provider,
centralized error handler, CSRF origin+header check, DB-backed auth context, maintenance gate), Prisma 7 schema with
all §7 models + raw-SQL migration (extensions, trigram/pattern/GIN indexes, CHECKs, composite FKs, settings
singleton), Argon2id auth service with rotating refresh tokens, shared Zod schemas/DTOs/Uzbek dictionary/search
normalization, `check:placeholders`, `check:production-integrity` (static anti-fake audit + live HTTP API ↔ PostgreSQL
write → restart → read → cleanup), `verify`, `db:up/down` (Compose with embedded-PG fallback), `smoke`,
docker-compose (postgres, redis, migrate, api, web), Dockerfiles, CI workflow, UI_BRIEF, DESIGN_SYSTEM, DECISIONS,
KNOWN_ISSUES.

| Command                                                                     | Exit | Output excerpt                                                                                                                                                                                |
| --------------------------------------------------------------------------- | ---- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pnpm install --frozen-lockfile`                                            | 0    | `Lockfile is up to date, resolution step is skipped`                                                                                                                                          |
| `prisma migrate dev --create-only` / `prisma migrate deploy` (real PG 18.1) | 0    | `All migrations have been successfully applied.` 85 indexes; extensions plpgsql, pg_trgm, unaccent, fuzzystrmatch                                                                             |
| API `node dist/server.js` + `curl /health/ready`                            | 0    | `{"status":"ok","database":"up","cache":"memory","latencyMs":1.43}`                                                                                                                           |
| `next build` (standalone, Turbopack)                                        | 0    | `✓ Compiled successfully` · `Running TypeScript … Finished` · routes `/`, `/_not-found`                                                                                                       |
| `node scripts/local-pg.mjs run -- pnpm verify`                              | 0    | typecheck 5.6s · lint 7.9s · check:placeholders 0.1s · check:production-integrity 2.3s · test:unit 1.9s · test:integration 2.4s · build 7.8s · test:e2e 4.4s → `verify OK — all gates passed` |

Tests: shared unit 18/18, API unit 7/7, API integration (real PG) 3/3, Playwright Chromium E2E 2/2 (production
`next start` + built API). Real failures found and fixed during the gate: maintenance hook hit the DB on unmatched
routes (unit test caught a 500 instead of 404); `NODE_ENV=development` leaking from `.env` broke `next build`.

Not verifiable here: `docker compose up` (BLOCKED, see KNOWN_ISSUES), GitHub Actions run (NOT VERIFIED until pushed CI runs).

## Next action

- First unfinished phase: Phase 1 — Database and seed.
- First concrete task: write `apps/api/prisma/seed.ts` with 18+ original works, original SVG covers rasterised to
  WebP via sharp, taxonomy, chapters, dated daily stats, role users; DB invariant integration tests; seed twice.

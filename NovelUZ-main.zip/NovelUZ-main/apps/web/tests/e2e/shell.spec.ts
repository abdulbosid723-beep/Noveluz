import { expect, test } from '@playwright/test';

test('production Next.js server renders the Uzbek document shell', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  const response = await page.goto('/');
  expect(response?.status()).toBe(200);
  await expect(page.locator('html')).toHaveAttribute('lang', 'uz');
  await expect(page).toHaveTitle(/NovelUZ/);
  expect(errors).toEqual([]);
});

test('web origin proxies the real API', async ({ request }) => {
  const res = await request.get('/api/openapi.json');
  expect(res.status()).toBe(200);
  const body = (await res.json()) as { openapi: string };
  expect(body.openapi).toBe('3.1.0');
});

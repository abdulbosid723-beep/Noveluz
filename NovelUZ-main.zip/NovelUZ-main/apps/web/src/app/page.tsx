import { siteConfig } from '@/lib/site';

export default function HomePage() {
  return (
    <main id="main" className="shell py-16">
      <h1 className="text-3xl font-bold">{siteConfig.name}</h1>
      <p className="mt-3 text-fg-2">{siteConfig.description}</p>
    </main>
  );
}

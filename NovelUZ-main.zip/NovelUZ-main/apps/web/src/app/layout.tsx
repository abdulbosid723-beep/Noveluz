import type { Metadata, Viewport } from 'next';
import { Literata, Plus_Jakarta_Sans } from 'next/font/google';
import type { ReactNode } from 'react';
import '../styles/globals.css';
import { siteConfig } from '@/lib/site';

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin', 'latin-ext'],
  variable: '--font-jakarta',
  display: 'swap',
});

const literata = Literata({
  subsets: ['latin', 'latin-ext', 'cyrillic'],
  variable: '--font-literata',
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.origin),
  title: { default: siteConfig.title, template: `%s — ${siteConfig.name}` },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  openGraph: { siteName: siteConfig.name, locale: 'uz_UZ', type: 'website' },
  icons: { icon: '/icon.svg' },
};

export const viewport: Viewport = {
  themeColor: '#0b0d13',
  colorScheme: 'dark',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="uz" className={`${jakarta.variable} ${literata.variable}`}>
      <body>{children}</body>
    </html>
  );
}

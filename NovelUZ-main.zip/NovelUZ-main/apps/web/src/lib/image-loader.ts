/**
 * next/image custom loader: covers and pages are served by the API asset
 * endpoint, which resizes to an allow-listed width and re-encodes to WebP.
 */
const WIDTHS = [96, 160, 240, 320, 360, 480, 640, 768, 1024, 1280, 1600] as const;

export function nearestWidth(width: number): number {
  for (const w of WIDTHS) if (w >= width) return w;
  return WIDTHS[WIDTHS.length - 1] ?? 1600;
}

export default function imageLoader({ src, width }: { src: string; width: number; quality?: number }): string {
  if (!src.startsWith('/api/assets/')) return src;
  const sep = src.includes('?') ? '&' : '?';
  return `${src}${sep}w=${nearestWidth(width)}`;
}

export const siteConfig = {
  name: 'NovelUZ',
  title: 'NovelUZ — novella, manhwa va manga o‘zbek tilida',
  description:
    'NovelUZ — o‘zbek tilidagi novella, ranobe, manhwa, manga va manhua katalogi: yangi boblar, reytinglar va qulay o‘quvchi.',
  origin: process.env.APP_ORIGIN ?? process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3000',
} as const;

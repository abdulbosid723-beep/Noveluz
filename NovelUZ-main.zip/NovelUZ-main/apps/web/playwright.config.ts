import { existsSync } from 'node:fs';
import path from 'node:path';
import { defineConfig, devices } from '@playwright/test';

const rootEnv = path.resolve(import.meta.dirname, '../../.env');
if (existsSync(rootEnv)) process.loadEnvFile(rootEnv);

const testDb = process.env.TEST_DATABASE_URL;
if (!testDb) throw new Error('TEST_DATABASE_URL is required for E2E tests');

const WEB_URL = 'http://localhost:3000';
const serverEnv: Record<string, string> = {
  ...(process.env as Record<string, string>),
  // The API runs its production build (dist/) with NODE_ENV=test so local http
  // origins and development secrets are accepted; the web runs `next start`.
  NODE_ENV: 'test',
  DATABASE_URL: testDb,
  APP_ORIGIN: WEB_URL,
  REDIS_URL: process.env.E2E_REDIS_URL ?? '',
  RATE_LIMIT_MULTIPLIER: '50',
  LOG_LEVEL: 'warn',
  UPLOAD_DIR: path.resolve(import.meta.dirname, '../../.data/e2e-uploads'),
};

export default defineConfig({
  testDir: './tests',
  outputDir: '../../test-results',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: Boolean(process.env.CI),
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: [['list'], ['html', { open: 'never', outputFolder: '../../playwright-report' }]],
  use: {
    baseURL: WEB_URL,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    locale: 'uz-UZ',
    timezoneId: 'Asia/Tashkent',
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: [
    {
      command: 'node dist/server.js',
      cwd: path.resolve(import.meta.dirname, '../api'),
      url: 'http://127.0.0.1:4000/health/ready',
      env: serverEnv,
      reuseExistingServer: false,
      timeout: 60_000,
      stdout: 'ignore',
      stderr: 'pipe',
    },
    {
      command: 'pnpm exec next start --port 3000',
      cwd: import.meta.dirname,
      url: WEB_URL,
      env: { ...serverEnv, NODE_ENV: 'production', API_INTERNAL_URL: 'http://127.0.0.1:4000' },
      reuseExistingServer: false,
      timeout: 90_000,
      stdout: 'ignore',
      stderr: 'pipe',
    },
  ],
});

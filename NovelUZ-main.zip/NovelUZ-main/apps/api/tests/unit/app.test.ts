import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../../src/app.js';
import { loadEnv } from '../../src/config/env.js';

const baseEnv = {
  NODE_ENV: 'test',
  DATABASE_URL: 'postgresql://user:pass@127.0.0.1:1/unused',
  ACCESS_TOKEN_SECRET: 'unit-test-access-secret-0123456789abcdefghijkl',
  REFRESH_TOKEN_SECRET: 'unit-test-refresh-secret-0123456789abcdefghijk',
  REDIS_URL: '',
  LOG_LEVEL: 'silent',
};

describe('environment validation', () => {
  it('fails fast with actionable messages and without echoing secret values', () => {
    expect(() => loadEnv({ ...baseEnv, ACCESS_TOKEN_SECRET: 'short' })).toThrow(
      /ACCESS_TOKEN_SECRET must be at least 32/,
    );
    expect(() => loadEnv({ ...baseEnv, DATABASE_URL: '' })).toThrow(/DATABASE_URL/);
    try {
      loadEnv({ ...baseEnv, ACCESS_TOKEN_SECRET: 'short-secret-value' });
    } catch (error) {
      expect(String(error)).not.toContain('short-secret-value');
    }
  });

  it('rejects development secrets in production', () => {
    expect(() =>
      loadEnv({
        ...baseEnv,
        NODE_ENV: 'production',
        APP_ORIGIN: 'https://noveluz.example',
        ACCESS_TOKEN_SECRET: 'dev-only-access-secret-change-me-0123456789abcdef',
      }),
    ).toThrow(/development value/);
  });

  it('accepts upper-case LOG_LEVEL values', () => {
    expect(loadEnv({ ...baseEnv, LOG_LEVEL: 'INFO' }).LOG_LEVEL).toBe('info');
  });
});

describe('app shell', () => {
  let app: FastifyInstance;
  beforeAll(async () => {
    app = await buildApp({ env: loadEnv(baseEnv), logger: false });
    await app.ready();
  });
  afterAll(async () => {
    await app.close();
  });

  it('serves liveness without touching the database', async () => {
    const res = await app.inject({ method: 'GET', url: '/health/live' });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toEqual({ status: 'ok' });
    expect(res.headers['x-request-id']).toMatch(/[0-9a-f-]{36}/);
  });

  it('reports not-ready when the database is unreachable', async () => {
    const res = await app.inject({ method: 'GET', url: '/health/ready' });
    expect(res.statusCode).toBe(503);
    expect(res.json()).toMatchObject({ status: 'unavailable', database: 'down' });
  });

  it('returns the standard error envelope for unknown routes', async () => {
    const res = await app.inject({ method: 'GET', url: '/api/does-not-exist' });
    expect(res.statusCode).toBe(404);
    const json = res.json<{ error: { code: string; message: string }; requestId: string }>();
    expect(json.error.code).toBe('NOT_FOUND');
    expect(json.error.message).toBe('Topilmadi');
    expect(json.requestId).toBeTypeOf('string');
  });

  it('sets security headers', async () => {
    const res = await app.inject({ method: 'GET', url: '/health/live' });
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['content-security-policy']).toContain("default-src 'none'");
  });
});

import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { FastifyInstance } from 'fastify';
import { createTestApp, resetDatabase, testPrisma } from '../helpers/app.js';

describe('real PostgreSQL wiring', () => {
  let app: FastifyInstance;
  beforeAll(async () => {
    await resetDatabase();
    app = await createTestApp();
  });
  afterAll(async () => {
    await app.close();
  });

  it('reports ready against the live database', async () => {
    const res = await app.inject({ method: 'GET', url: '/health/ready' });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toMatchObject({ status: 'ok', database: 'up', cache: 'memory' });
  });

  it('has the search extensions and the settings singleton installed by migrations', async () => {
    const prisma = testPrisma();
    const ext = await prisma.$queryRaw<Array<{ extname: string }>>`SELECT extname FROM pg_extension ORDER BY extname`;
    expect(ext.map((e) => e.extname)).toEqual(expect.arrayContaining(['fuzzystrmatch', 'pg_trgm', 'unaccent']));
    const settings = await prisma.siteSettings.findMany();
    expect(settings).toHaveLength(1);
    await expect(prisma.$executeRaw`INSERT INTO "SiteSettings" (id, "updatedAt") VALUES (2, now())`).rejects.toThrow();
  });

  it('round-trips a write through PostgreSQL', async () => {
    const prisma = testPrisma();
    const genre = await prisma.genre.create({ data: { slug: 'smoke-genre', name: 'Smoke', normalizedName: 'smoke' } });
    const found = await prisma.genre.findUnique({ where: { id: genre.id } });
    expect(found?.slug).toBe('smoke-genre');
    await prisma.genre.delete({ where: { id: genre.id } });
    expect(await prisma.genre.count({ where: { slug: 'smoke-genre' } })).toBe(0);
  });
});

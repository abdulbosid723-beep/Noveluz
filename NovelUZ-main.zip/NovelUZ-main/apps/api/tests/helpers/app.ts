import { existsSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import type { FastifyInstance } from 'fastify';
import { buildApp } from '../../src/app.js';
import { loadEnv } from '../../src/config/env.js';
import type { Env } from '../../src/config/env.js';
import { createPrisma } from '../../src/lib/prisma.js';
import type { Db } from '../../src/lib/prisma.js';
import { resetSettingsCache } from '../../src/services/settings.service.js';

const rootEnv = path.resolve(import.meta.dirname, '../../../../.env');
if (existsSync(rootEnv)) process.loadEnvFile(rootEnv);

export const TEST_ORIGIN = 'http://localhost:3000';

export function testEnv(overrides: Partial<Record<string, string>> = {}): Env {
  const url = process.env.TEST_DATABASE_URL;
  if (!url) throw new Error('TEST_DATABASE_URL is required');
  return loadEnv({
    ...process.env,
    NODE_ENV: 'test',
    DATABASE_URL: url,
    REDIS_URL: '',
    LOG_LEVEL: 'silent',
    APP_ORIGIN: TEST_ORIGIN,
    UPLOAD_DIR: mkdtempSync(path.join(tmpdir(), 'noveluz-test-uploads-')),
    ...overrides,
  });
}

let sharedPrisma: Db | null = null;
export function testPrisma(): Db {
  if (!sharedPrisma) {
    const url = process.env.TEST_DATABASE_URL;
    if (!url) throw new Error('TEST_DATABASE_URL is required');
    sharedPrisma = createPrisma(url);
  }
  return sharedPrisma;
}

export async function createTestApp(overrides: Partial<Record<string, string>> = {}): Promise<FastifyInstance> {
  const app = await buildApp({ env: testEnv(overrides), prisma: testPrisma(), logger: false });
  await app.ready();
  return app;
}

const TABLES = [
  'AuditLog',
  'SearchLog',
  'SearchReindexJob',
  'NovelDailyStat',
  'CommentLike',
  'Comment',
  'Rating',
  'Bookmark',
  'ReaderPreference',
  'ChapterPage',
  'Chapter',
  'NovelContributor',
  'NovelTag',
  'NovelGenre',
  'NovelAlias',
  'Novel',
  'Tag',
  'Genre',
  'RefreshSession',
  'User',
  'UploadAsset',
];

/** Empties every application table (keeps migrations) and restores the settings singleton. */
export async function resetDatabase(prisma: Db = testPrisma()): Promise<void> {
  const list = TABLES.map((t) => `"${t}"`).join(', ');
  await prisma.$executeRawUnsafe(`TRUNCATE ${list} RESTART IDENTITY CASCADE`);
  await prisma.$executeRawUnsafe(
    `UPDATE "SiteSettings" SET "announcementText" = NULL, "announcementActive" = false, "maintenanceMode" = false, "maintenanceMessage" = NULL WHERE id = 1`,
  );
  resetSettingsCache();
}

-- NovelUZ: search extensions, trigram/FTS indexes, CHECK constraints and
-- relational consistency rules that Prisma's schema language cannot express.
-- NOTE: these objects are intentionally managed here; review any future
-- `prisma migrate dev` output so it does not drop them (see docs/DECISIONS.md).

-- Extensions (managed hosting may require a DBA to allow them).
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;
CREATE EXTENSION IF NOT EXISTS fuzzystrmatch;

-- Trigram indexes (fuzzy, substring, similarity) on normalized catalog fields.
CREATE INDEX "Novel_normalizedTitle_trgm_idx" ON "Novel" USING GIN ("normalizedTitle" gin_trgm_ops);
CREATE INDEX "Novel_compactTitle_trgm_idx" ON "Novel" USING GIN ("compactTitle" gin_trgm_ops);
CREATE INDEX "Novel_normalizedAuthor_trgm_idx" ON "Novel" USING GIN ("normalizedAuthor" gin_trgm_ops);
CREATE INDEX "Novel_normalizedTranslatorGroup_trgm_idx" ON "Novel" USING GIN ("normalizedTranslatorGroup" gin_trgm_ops);
CREATE INDEX "NovelAlias_normalizedName_trgm_idx" ON "NovelAlias" USING GIN ("normalizedName" gin_trgm_ops);
CREATE INDEX "NovelAlias_compactName_trgm_idx" ON "NovelAlias" USING GIN ("compactName" gin_trgm_ops);

-- Btree pattern indexes for exact and prefix (LIKE 'q%') lookups independent of collation.
CREATE INDEX "Novel_normalizedTitle_pattern_idx" ON "Novel" ("normalizedTitle" varchar_pattern_ops);
CREATE INDEX "Novel_compactTitle_pattern_idx" ON "Novel" ("compactTitle" varchar_pattern_ops);
CREATE INDEX "Novel_normalizedAuthor_pattern_idx" ON "Novel" ("normalizedAuthor" varchar_pattern_ops);
CREATE INDEX "NovelAlias_normalizedName_pattern_idx" ON "NovelAlias" ("normalizedName" varchar_pattern_ops);
CREATE INDEX "NovelAlias_compactName_pattern_idx" ON "NovelAlias" ("compactName" varchar_pattern_ops);

-- Full-text: catalog metadata vector (no chapter bodies) and a SEPARATE chapter-body vector.
CREATE INDEX "Novel_searchVector_idx" ON "Novel" USING GIN ("searchVector");
CREATE INDEX "Chapter_searchVector_idx" ON "Chapter" USING GIN ("searchVector") WHERE "isPublished" AND "deletedAt" IS NULL;

-- Public listing helper: published, not deleted.
CREATE INDEX "Novel_public_idx" ON "Novel" ("lastChapterAt" DESC, "id") WHERE "publishedAt" IS NOT NULL AND "deletedAt" IS NULL;
CREATE INDEX "Chapter_public_latest_idx" ON "Chapter" ("publishedAt" DESC, "id") WHERE "isPublished" AND "deletedAt" IS NULL;

-- CHECK constraints.
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_score_check" CHECK ("score" BETWEEN 1 AND 5);
ALTER TABLE "Bookmark" ADD CONSTRAINT "Bookmark_scrollPercent_check" CHECK ("scrollPercent" >= 0 AND "scrollPercent" <= 100);
ALTER TABLE "Novel" ADD CONSTRAINT "Novel_ratingAvg_check" CHECK ("ratingAvg" >= 0 AND "ratingAvg" <= 5);
ALTER TABLE "Novel" ADD CONSTRAINT "Novel_counts_check" CHECK ("viewsCount" >= 0 AND "ratingCount" >= 0 AND "chapterCount" >= 0);
ALTER TABLE "Novel" ADD CONSTRAINT "Novel_normalized_check" CHECK (length("normalizedTitle") > 0 AND length("compactTitle") > 0);
ALTER TABLE "Chapter" ADD CONSTRAINT "Chapter_number_check" CHECK ("chapterNumber" >= 0 AND "volumeNumber" >= 0);
ALTER TABLE "Chapter" ADD CONSTRAINT "Chapter_text_kind_check" CHECK ("kind" <> 'TEXT' OR ("contentText" IS NOT NULL AND length("contentText") > 0));
ALTER TABLE "Chapter" ADD CONSTRAINT "Chapter_published_at_check" CHECK (NOT "isPublished" OR "publishedAt" IS NOT NULL);
ALTER TABLE "ChapterPage" ADD CONSTRAINT "ChapterPage_position_check" CHECK ("position" >= 0);
ALTER TABLE "Comment" ADD CONSTRAINT "Comment_depth_check" CHECK ("depth" BETWEEN 0 AND 2);
ALTER TABLE "Comment" ADD CONSTRAINT "Comment_likes_check" CHECK ("likesCount" >= 0);
ALTER TABLE "NovelDailyStat" ADD CONSTRAINT "NovelDailyStat_views_check" CHECK ("views" >= 0);
ALTER TABLE "UploadAsset" ADD CONSTRAINT "UploadAsset_bytes_check" CHECK ("bytes" > 0);
ALTER TABLE "User" ADD CONSTRAINT "User_username_normalized_check" CHECK ("usernameNormalized" = lower("username"));
ALTER TABLE "User" ADD CONSTRAINT "User_email_lower_check" CHECK ("email" = lower("email"));
ALTER TABLE "SiteSettings" ADD CONSTRAINT "SiteSettings_singleton_check" CHECK ("id" = 1);

-- Cross-table consistency: a bookmark's progress chapter and a comment's chapter
-- MUST belong to the same novel. Enforced with composite foreign keys.
CREATE UNIQUE INDEX "Chapter_id_novelId_key" ON "Chapter" ("id", "novelId");
ALTER TABLE "Bookmark"
  ADD CONSTRAINT "Bookmark_progress_chapter_same_novel_fkey"
  FOREIGN KEY ("lastReadChapterId", "novelId") REFERENCES "Chapter" ("id", "novelId")
  ON DELETE SET NULL ("lastReadChapterId") ON UPDATE CASCADE;
ALTER TABLE "Comment"
  ADD CONSTRAINT "Comment_chapter_same_novel_fkey"
  FOREIGN KEY ("chapterId", "novelId") REFERENCES "Chapter" ("id", "novelId")
  ON DELETE CASCADE ON UPDATE CASCADE;

-- Singleton settings row.
INSERT INTO "SiteSettings" ("id", "announcementActive", "maintenanceMode", "updatedAt")
VALUES (1, false, false, now())
ON CONFLICT ("id") DO NOTHING;

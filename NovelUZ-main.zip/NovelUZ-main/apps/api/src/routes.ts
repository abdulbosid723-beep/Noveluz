import type { FastifyInstance } from 'fastify';
import { authRoutes } from './modules/auth/routes.js';
import { healthRoutes } from './modules/health/routes.js';

export async function registerRoutes(app: FastifyInstance): Promise<void> {
  await app.register(healthRoutes);
  await app.register(authRoutes);
  app.get('/api/openapi.json', { config: { allowDuringMaintenance: true }, schema: { hide: true } }, async () =>
    app.swagger(),
  );
}

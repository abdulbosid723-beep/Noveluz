import type { Env } from './config/env.js';
import type { Cache } from './lib/cache.js';
import type { Db } from './lib/prisma.js';
import type { Storage } from './services/storage.js';
import type { Role } from '@noveluz/shared';

export interface AppContext {
  env: Env;
  prisma: Db;
  cache: Cache;
  storage: Storage;
}

export interface AuthUser {
  id: string;
  username: string;
  role: Role;
  sessionId: string;
}

declare module 'fastify' {
  interface FastifyInstance {
    ctx: AppContext;
  }
  interface FastifyRequest {
    auth: AuthUser | null;
  }
  interface FastifyContextConfig {
    /** Skip the maintenance-mode gate for this route (health, auth, admin). */
    allowDuringMaintenance?: boolean;
  }
}

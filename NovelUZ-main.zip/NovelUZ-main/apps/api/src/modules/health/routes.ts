import type { FastifyInstance } from 'fastify';

export async function healthRoutes(app: FastifyInstance): Promise<void> {
  const config = { allowDuringMaintenance: true };

  app.get('/health/live', { config }, async () => ({ status: 'ok' }));

  app.get('/health/ready', { config }, async (_request, reply) => {
    const started = performance.now();
    try {
      await app.ctx.prisma.$queryRaw`SELECT 1`;
    } catch {
      return reply.status(503).send({ status: 'unavailable', database: 'down', cache: app.ctx.cache.backend() });
    }
    return {
      status: 'ok',
      database: 'up',
      cache: app.ctx.cache.backend(),
      latencyMs: Math.round((performance.now() - started) * 100) / 100,
    };
  });
}

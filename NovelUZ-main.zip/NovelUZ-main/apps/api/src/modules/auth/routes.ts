import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { LoginSchema, PasswordChangeSchema, ProfileUpdateSchema, RegisterSchema } from '@noveluz/shared';
import { AppError, unauthenticated } from '../../lib/errors.js';
import { ok } from '../../lib/http.js';
import { limit } from '../../lib/rate-limits.js';
import { requireUser } from '../../plugins/auth.js';
import * as auth from './service.js';
import type { IssuedTokens } from './service.js';
import { ACCESS_COOKIE, ACCESS_TTL_SECONDS, REFRESH_COOKIE, REFRESH_TTL_SECONDS } from './tokens.js';

function cookieBase(app: FastifyInstance): {
  httpOnly: true;
  secure: boolean;
  sameSite: 'lax';
  path: string;
  domain?: string;
} {
  const { env } = app.ctx;
  const base = { httpOnly: true as const, secure: env.NODE_ENV === 'production', sameSite: 'lax' as const, path: '/' };
  return env.COOKIE_DOMAIN ? { ...base, domain: env.COOKIE_DOMAIN } : base;
}

function setAuthCookies(app: FastifyInstance, reply: FastifyReply, tokens: IssuedTokens): void {
  const base = cookieBase(app);
  // The access cookie expires slightly before the JWT so clients refresh proactively.
  void reply.setCookie(ACCESS_COOKIE, tokens.accessToken, { ...base, maxAge: ACCESS_TTL_SECONDS - 30 });
  void reply.setCookie(REFRESH_COOKIE, tokens.refreshToken, { ...base, maxAge: REFRESH_TTL_SECONDS });
}

function clearAuthCookies(app: FastifyInstance, reply: FastifyReply): void {
  const base = cookieBase(app);
  void reply.clearCookie(ACCESS_COOKIE, base);
  void reply.clearCookie(REFRESH_COOKIE, base);
}

function meta(request: FastifyRequest): auth.ClientMeta {
  return { userAgent: request.headers['user-agent'], ip: request.ip };
}

export async function authRoutes(appBase: FastifyInstance): Promise<void> {
  const app = appBase.withTypeProvider<ZodTypeProvider>();
  const { ctx } = appBase;
  const allow = { allowDuringMaintenance: true };

  app.post(
    '/api/auth/register',
    { schema: { body: RegisterSchema, tags: ['auth'] }, config: { ...limit(ctx.env, 'register') } },
    async (request, reply) => {
      const { user, tokens } = await auth.register(ctx, request.body, meta(request));
      setAuthCookies(appBase, reply, tokens);
      return reply.status(201).send(ok(request, user));
    },
  );

  app.post(
    '/api/auth/login',
    { schema: { body: LoginSchema, tags: ['auth'] }, config: { ...allow, ...limit(ctx.env, 'login') } },
    async (request, reply) => {
      const { user, tokens } = await auth.login(ctx, request.body, meta(request));
      setAuthCookies(appBase, reply, tokens);
      return ok(request, user);
    },
  );

  app.post(
    '/api/auth/refresh',
    { schema: { tags: ['auth'] }, config: { ...allow, ...limit(ctx.env, 'refresh') } },
    async (request, reply) => {
      const raw = request.cookies[REFRESH_COOKIE];
      if (!raw || raw.length > 200) throw unauthenticated('Sessiya topilmadi');
      try {
        const tokens = await auth.refresh(ctx, raw, meta(request));
        setAuthCookies(appBase, reply, tokens);
        return ok(request, { refreshed: true });
      } catch (error) {
        if (!(error instanceof AppError && error.details?.reason === 'ROTATED')) {
          clearAuthCookies(appBase, reply);
        }
        throw error;
      }
    },
  );

  app.post('/api/auth/logout', { schema: { tags: ['auth'] }, config: allow }, async (request, reply) => {
    await auth.logout(ctx, request.cookies[REFRESH_COOKIE], request.auth?.sessionId ?? null);
    clearAuthCookies(appBase, reply);
    return ok(request, { loggedOut: true });
  });

  app.post('/api/auth/logout-all', { schema: { tags: ['auth'] }, config: allow }, async (request, reply) => {
    const user = requireUser(request);
    const revoked = await auth.logoutAll(ctx, user.id);
    clearAuthCookies(appBase, reply);
    return ok(request, { revokedSessions: revoked });
  });

  app.get('/api/auth/me', { schema: { tags: ['auth'] }, config: allow }, async (request) => {
    const user = requireUser(request);
    return ok(request, await auth.getMe(ctx, user.id));
  });

  app.get('/api/user/profile', { schema: { tags: ['user'] } }, async (request) => {
    const user = requireUser(request);
    return ok(request, await auth.getMe(ctx, user.id));
  });

  app.patch('/api/user/profile', { schema: { body: ProfileUpdateSchema, tags: ['user'] } }, async (request) => {
    const user = requireUser(request);
    return ok(request, await auth.updateProfile(ctx, user.id, request.body));
  });

  app.patch(
    '/api/user/password',
    { schema: { body: PasswordChangeSchema, tags: ['user'] }, config: { ...limit(ctx.env, 'password') } },
    async (request) => {
      const user = requireUser(request);
      await auth.changePassword(ctx, user.id, user.sessionId, request.body);
      return ok(request, { changed: true });
    },
  );
}

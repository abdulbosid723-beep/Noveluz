import { randomUUID } from 'node:crypto';
import type { LoginInput, MeUser, PasswordChangeInput, ProfileUpdateInput, RegisterInput } from '@noveluz/shared';
import type { AppContext } from '../../context.js';
import { hmacHex, randomToken, sha256Hex } from '../../lib/crypto.js';
import { AppError, conflict, forbidden, notFound, unauthenticated, validation } from '../../lib/errors.js';
import { assetRef, iso, num } from '../../lib/serialize.js';
import { audit } from '../../services/audit.service.js';
import { hashPassword, verifyPassword } from './password.js';
import { REFRESH_TTL_SECONDS, ROTATION_GRACE_MS, signAccessToken } from './tokens.js';

export interface ClientMeta {
  userAgent: string | undefined;
  ip: string;
}

export interface IssuedTokens {
  accessToken: string;
  refreshToken: string;
}

const userSelect = {
  id: true,
  username: true,
  email: true,
  role: true,
  bio: true,
  createdAt: true,
  lastLoginAt: true,
  isBanned: true,
  avatar: { select: { id: true, width: true, height: true, deletedAt: true } },
  readerPreference: true,
} as const;

type UserRow = {
  id: string;
  username: string;
  email: string;
  role: MeUser['role'];
  bio: string | null;
  createdAt: Date;
  lastLoginAt: Date | null;
  avatar: { id: string; width: number | null; height: number | null; deletedAt: Date | null } | null;
  readerPreference: {
    theme: 'DARK' | 'LIGHT' | 'SEPIA';
    fontFamily: 'LITERATA' | 'JAKARTA' | 'SYSTEM_SERIF';
    fontSize: number;
    lineHeight: { toString(): string };
    contentWidth: number;
  } | null;
};

export function toMe(user: UserRow): MeUser {
  const pref = user.readerPreference;
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    bio: user.bio,
    avatar: assetRef(user.avatar),
    createdAt: user.createdAt.toISOString(),
    lastLoginAt: iso(user.lastLoginAt),
    readerPreference: pref
      ? {
          theme: pref.theme,
          fontFamily: pref.fontFamily,
          fontSize: pref.fontSize,
          lineHeight: num(pref.lineHeight),
          contentWidth: pref.contentWidth,
        }
      : null,
  };
}

function hashRefresh(ctx: AppContext, raw: string): string {
  return hmacHex(ctx.env.REFRESH_TOKEN_SECRET, raw);
}

function ipHash(ctx: AppContext, ip: string): string {
  return sha256Hex(`${ctx.env.REFRESH_TOKEN_SECRET}:${ip}`).slice(0, 32);
}

async function issueSession(
  ctx: AppContext,
  user: { id: string; role: MeUser['role'] },
  meta: ClientMeta,
  familyId: string = randomUUID(),
): Promise<IssuedTokens> {
  const refreshToken = randomToken(32);
  await ctx.prisma.refreshSession.create({
    data: {
      userId: user.id,
      familyId,
      tokenHash: hashRefresh(ctx, refreshToken),
      expiresAt: new Date(Date.now() + REFRESH_TTL_SECONDS * 1000),
      userAgent: meta.userAgent?.slice(0, 300) ?? null,
      ipHash: ipHash(ctx, meta.ip),
    },
  });
  const accessToken = await signAccessToken(ctx.env.ACCESS_TOKEN_SECRET, {
    userId: user.id,
    familyId,
    role: user.role,
  });
  return { accessToken, refreshToken };
}

export async function register(
  ctx: AppContext,
  input: RegisterInput,
  meta: ClientMeta,
): Promise<{ user: MeUser; tokens: IssuedTokens }> {
  const email = input.email.toLowerCase();
  const usernameNormalized = input.username.toLowerCase();
  const existing = await ctx.prisma.user.findFirst({
    where: { OR: [{ email }, { usernameNormalized }] },
    select: { email: true },
  });
  if (existing) {
    const field = existing.email === email ? 'email' : 'username';
    throw conflict(field === 'email' ? 'Bu pochta allaqachon ro‘yxatdan o‘tgan' : 'Bu foydalanuvchi nomi band', {
      fields: { [field]: field === 'email' ? 'Bu pochta band' : 'Bu nom band' },
    });
  }
  const passwordHash = await hashPassword(input.password);
  const user = await ctx.prisma.user.create({
    data: { username: input.username, usernameNormalized, email, passwordHash, lastLoginAt: new Date() },
    select: userSelect,
  });
  const tokens = await issueSession(ctx, user, meta);
  return { user: toMe(user), tokens };
}

export async function login(
  ctx: AppContext,
  input: LoginInput,
  meta: ClientMeta,
): Promise<{ user: MeUser; tokens: IssuedTokens }> {
  const loginKey = input.login.toLowerCase();
  const found = await ctx.prisma.user.findFirst({
    where: loginKey.includes('@') ? { email: loginKey } : { usernameNormalized: loginKey },
    select: { ...userSelect, passwordHash: true },
  });
  const valid = await verifyPassword(found?.passwordHash ?? null, input.password);
  if (!found || !valid) throw unauthenticated('Login yoki parol noto‘g‘ri');
  if (found.isBanned) throw forbidden('Hisobingiz bloklangan');
  const user = await ctx.prisma.user.update({
    where: { id: found.id },
    data: { lastLoginAt: new Date() },
    select: userSelect,
  });
  const tokens = await issueSession(ctx, user, meta);
  return { user: toMe(user), tokens };
}

/**
 * One-time rotating refresh tokens. Presenting an already-rotated token
 * outside the short race window is treated as theft: the whole family is revoked.
 */
export async function refresh(ctx: AppContext, rawToken: string, meta: ClientMeta): Promise<IssuedTokens> {
  const tokenHash = hashRefresh(ctx, rawToken);
  const session = await ctx.prisma.refreshSession.findUnique({
    where: { tokenHash },
    include: { user: { select: { id: true, role: true, isBanned: true } } },
  });
  if (!session) throw unauthenticated('Sessiya topilmadi');
  const now = new Date();

  if (session.revokedAt) {
    const benignRace = session.rotatedAt !== null && now.getTime() - session.rotatedAt.getTime() < ROTATION_GRACE_MS;
    if (!benignRace) {
      await ctx.prisma.refreshSession.updateMany({
        where: { familyId: session.familyId, revokedAt: null },
        data: { revokedAt: now },
      });
      await audit(ctx.prisma, {
        actorUserId: session.userId,
        action: 'auth.refresh_reuse_detected',
        entityType: 'RefreshSession',
        entityId: session.familyId,
      });
    }
    throw new AppError('UNAUTHENTICATED', 'Sessiya yaroqsiz, qayta kiring', {
      reason: benignRace ? 'ROTATED' : 'REUSED',
    });
  }
  if (session.expiresAt <= now) throw unauthenticated('Sessiya muddati tugagan');
  if (session.user.isBanned) {
    await ctx.prisma.refreshSession.updateMany({
      where: { userId: session.userId, revokedAt: null },
      data: { revokedAt: now },
    });
    throw forbidden('Hisobingiz bloklangan');
  }

  // Atomic rotation: only one concurrent request can flip revokedAt from NULL.
  const rotated = await ctx.prisma.refreshSession.updateMany({
    where: { id: session.id, revokedAt: null },
    data: { revokedAt: now, rotatedAt: now, lastUsedAt: now },
  });
  if (rotated.count !== 1) {
    throw new AppError('UNAUTHENTICATED', 'Sessiya yangilangan, qayta urinib ko‘ring', { reason: 'ROTATED' });
  }
  return issueSession(ctx, session.user, meta, session.familyId);
}

export async function logout(ctx: AppContext, rawToken: string | undefined, familyId: string | null): Promise<void> {
  const now = new Date();
  let family = familyId;
  if (!family && rawToken) {
    const session = await ctx.prisma.refreshSession.findUnique({
      where: { tokenHash: hashRefresh(ctx, rawToken) },
      select: { familyId: true },
    });
    family = session?.familyId ?? null;
  }
  if (family) {
    await ctx.prisma.refreshSession.updateMany({
      where: { familyId: family, revokedAt: null },
      data: { revokedAt: now },
    });
  }
}

export async function logoutAll(ctx: AppContext, userId: string): Promise<number> {
  const res = await ctx.prisma.refreshSession.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return res.count;
}

export async function getMe(ctx: AppContext, userId: string): Promise<MeUser> {
  const user = await ctx.prisma.user.findUnique({ where: { id: userId }, select: userSelect });
  if (!user) throw notFound();
  return toMe(user);
}

export async function updateProfile(ctx: AppContext, userId: string, input: ProfileUpdateInput): Promise<MeUser> {
  const data: { username?: string; usernameNormalized?: string; bio?: string | null; avatarAssetId?: string | null } =
    {};
  if (input.username !== undefined) {
    const usernameNormalized = input.username.toLowerCase();
    const taken = await ctx.prisma.user.findFirst({
      where: { usernameNormalized, NOT: { id: userId } },
      select: { id: true },
    });
    if (taken) throw conflict('Bu foydalanuvchi nomi band', { fields: { username: 'Bu nom band' } });
    data.username = input.username;
    data.usernameNormalized = usernameNormalized;
  }
  if (input.bio !== undefined) data.bio = input.bio && input.bio.length > 0 ? input.bio : null;
  if (input.avatarAssetId !== undefined) {
    if (input.avatarAssetId !== null) {
      const asset = await ctx.prisma.uploadAsset.findFirst({
        where: { id: input.avatarAssetId, createdById: userId, deletedAt: null },
        select: { id: true },
      });
      if (!asset) throw validation('Avatar fayli topilmadi', { avatarAssetId: 'Avval rasmni yuklang' });
    }
    data.avatarAssetId = input.avatarAssetId;
  }
  const user = await ctx.prisma.user.update({ where: { id: userId }, data, select: userSelect });
  return toMe(user);
}

export async function changePassword(
  ctx: AppContext,
  userId: string,
  familyId: string,
  input: PasswordChangeInput,
): Promise<void> {
  const user = await ctx.prisma.user.findUnique({ where: { id: userId }, select: { passwordHash: true } });
  if (!user) throw notFound();
  const valid = await verifyPassword(user.passwordHash, input.currentPassword);
  if (!valid) throw validation('Joriy parol noto‘g‘ri', { currentPassword: 'Joriy parol noto‘g‘ri' });
  const passwordHash = await hashPassword(input.newPassword);
  await ctx.prisma.$transaction([
    ctx.prisma.user.update({ where: { id: userId }, data: { passwordHash } }),
    // Every OTHER session is revoked; the current device stays signed in.
    ctx.prisma.refreshSession.updateMany({
      where: { userId, revokedAt: null, NOT: { familyId } },
      data: { revokedAt: new Date() },
    }),
  ]);
  await audit(ctx.prisma, {
    actorUserId: userId,
    action: 'user.password_changed',
    entityType: 'User',
    entityId: userId,
  });
}

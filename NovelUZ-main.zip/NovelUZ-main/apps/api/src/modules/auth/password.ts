import argon2 from 'argon2';

/** Argon2id with explicit OWASP-recommended cost parameters (m=19 MiB, t=2, p=1). */
const OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19_456,
  timeCost: 2,
  parallelism: 1,
} as const;

export function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, OPTIONS);
}

let dummyHash: Promise<string> | null = null;

/**
 * Verifies a password. When the account does not exist we still run a full
 * Argon2 verification against a dummy hash so response timing does not reveal
 * which usernames exist.
 */
export async function verifyPassword(hash: string | null, password: string): Promise<boolean> {
  if (!hash) {
    dummyHash ??= argon2.hash('noveluz-timing-equalizer-password', OPTIONS);
    await argon2.verify(await dummyHash, password).catch(() => false);
    return false;
  }
  try {
    return await argon2.verify(hash, password);
  } catch {
    return false;
  }
}

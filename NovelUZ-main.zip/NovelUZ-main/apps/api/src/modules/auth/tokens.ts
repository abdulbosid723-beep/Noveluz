import { SignJWT, jwtVerify } from 'jose';
import type { Role } from '@noveluz/shared';
import { RoleSchema } from '@noveluz/shared';

export const ACCESS_COOKIE = 'nuz_at';
export const REFRESH_COOKIE = 'nuz_rt';
export const ACCESS_TTL_SECONDS = 15 * 60;
export const REFRESH_TTL_SECONDS = 30 * 24 * 60 * 60;
/** Window in which reuse of a just-rotated token is treated as a benign parallel-request race. */
export const ROTATION_GRACE_MS = 20_000;

const ISSUER = 'noveluz-api';
const AUDIENCE = 'noveluz';

export interface AccessClaims {
  userId: string;
  familyId: string;
  role: Role;
}

export async function signAccessToken(secret: string, claims: AccessClaims): Promise<string> {
  return new SignJWT({ fid: claims.familyId, role: claims.role })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(claims.userId)
    .setIssuer(ISSUER)
    .setAudience(AUDIENCE)
    .setIssuedAt()
    .setExpirationTime(`${ACCESS_TTL_SECONDS}s`)
    .sign(new TextEncoder().encode(secret));
}

export async function verifyAccessToken(secret: string, token: string): Promise<AccessClaims | null> {
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(secret), {
      issuer: ISSUER,
      audience: AUDIENCE,
      algorithms: ['HS256'],
    });
    const role = RoleSchema.safeParse(payload.role);
    if (typeof payload.sub !== 'string' || typeof payload.fid !== 'string' || !role.success) return null;
    return { userId: payload.sub, familyId: payload.fid, role: role.data };
  } catch {
    return null;
  }
}

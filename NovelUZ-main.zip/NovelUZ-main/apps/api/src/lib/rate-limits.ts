import type { Env } from '../config/env.js';

/** Documented per-IP limits (docs/SECURITY.md). */
const BASE = {
  register: { max: 5, timeWindow: '10 minutes' },
  login: { max: 10, timeWindow: '1 minute' },
  refresh: { max: 60, timeWindow: '1 minute' },
  password: { max: 5, timeWindow: '10 minutes' },
  search: { max: 120, timeWindow: '1 minute' },
  comment: { max: 10, timeWindow: '1 minute' },
  upload: { max: 30, timeWindow: '10 minutes' },
  view: { max: 120, timeWindow: '1 minute' },
} as const;

export type LimitName = keyof typeof BASE;

export function limit(env: Env, name: LimitName): { rateLimit: { max: number; timeWindow: string } } {
  const base = BASE[name];
  return { rateLimit: { max: Math.round(base.max * env.RATE_LIMIT_MULTIPLIER), timeWindow: base.timeWindow } };
}

import type { FastifyRequest } from 'fastify';
import type { PageMeta } from '@noveluz/shared';
import { pageMeta } from '@noveluz/shared';

export interface Envelope<T, M> {
  data: T;
  meta?: M;
  requestId: string;
}

export function ok<T>(request: FastifyRequest, data: T): Envelope<T, never> {
  return { data, requestId: request.id };
}

export function okMeta<T, M>(request: FastifyRequest, data: T, meta: M): Envelope<T, M> {
  return { data, meta, requestId: request.id };
}

export function paged<T>(
  request: FastifyRequest,
  data: T[],
  page: number,
  limit: number,
  total: number,
): Envelope<T[], PageMeta> {
  return { data, meta: pageMeta(page, limit, total), requestId: request.id };
}

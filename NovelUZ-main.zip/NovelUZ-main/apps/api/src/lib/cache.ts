import { Redis } from 'ioredis';
import { LRUCache } from 'lru-cache';
import type { FastifyBaseLogger } from 'fastify';

/**
 * Cache for PUBLIC, non-personalized derived data only. PostgreSQL stays the
 * source of truth; everything here is safe to drop at any moment.
 * Redis is used when reachable; otherwise a bounded in-process LRU.
 */
export interface Cache {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ttlSeconds: number): Promise<void>;
  /** Sets the key only if absent. Returns true when the key was created. */
  setIfAbsent(key: string, ttlSeconds: number): Promise<boolean>;
  /** Current generation number of a namespace (used inside cache keys). */
  generation(namespace: string): Promise<number>;
  /** Invalidates every key built with the previous generation. */
  bumpGeneration(namespace: string): Promise<number>;
  readonly backend: () => 'redis' | 'memory';
  close(): Promise<void>;
}

const MAX_TTL_SECONDS = 60 * 60 * 24;

class MemoryStore {
  private readonly lru = new LRUCache<string, string>({ max: 5000, ttlAutopurge: false });
  private readonly gens = new Map<string, number>();

  get(key: string): string | null {
    return this.lru.get(key) ?? null;
  }
  set(key: string, value: string, ttlSeconds: number): void {
    this.lru.set(key, value, { ttl: Math.min(ttlSeconds, MAX_TTL_SECONDS) * 1000 });
  }
  setIfAbsent(key: string, ttlSeconds: number): boolean {
    if (this.lru.has(key)) return false;
    this.set(key, '1', ttlSeconds);
    return true;
  }
  generation(ns: string): number {
    return this.gens.get(ns) ?? 0;
  }
  bump(ns: string): number {
    const next = this.generation(ns) + 1;
    this.gens.set(ns, next);
    return next;
  }
  clear(): void {
    this.lru.clear();
  }
}

export function createCache(redisUrl: string, log: FastifyBaseLogger): Cache {
  const memory = new MemoryStore();
  let redis: Redis | null = null;
  if (redisUrl) {
    redis = new Redis(redisUrl, {
      lazyConnect: false,
      enableOfflineQueue: false,
      maxRetriesPerRequest: 1,
      connectTimeout: 1500,
      retryStrategy: (times) => Math.min(times * 500, 10_000),
    });
    let warned = false;
    redis.on('error', (error: Error) => {
      if (!warned) {
        log.warn({ err: error.message }, 'redis unavailable; using bounded in-memory cache fallback');
        warned = true;
      }
    });
    redis.on('ready', () => {
      warned = false;
      // Entries written to the fallback may be stale relative to Redis generations.
      memory.clear();
      log.info('redis connected');
    });
  }
  const ready = (): Redis | null => (redis && redis.status === 'ready' ? redis : null);

  return {
    backend: () => (ready() ? 'redis' : 'memory'),
    async get(key) {
      const r = ready();
      if (r) {
        try {
          return await r.get(key);
        } catch {
          return null;
        }
      }
      return memory.get(key);
    },
    async set(key, value, ttlSeconds) {
      const r = ready();
      if (r) {
        try {
          await r.set(key, value, 'EX', Math.min(ttlSeconds, MAX_TTL_SECONDS));
          return;
        } catch {
          // fall through to memory
        }
      }
      memory.set(key, value, ttlSeconds);
    },
    async setIfAbsent(key, ttlSeconds) {
      const r = ready();
      if (r) {
        try {
          const res = await r.set(key, '1', 'EX', Math.min(ttlSeconds, MAX_TTL_SECONDS), 'NX');
          return res === 'OK';
        } catch {
          // fall through to memory
        }
      }
      return memory.setIfAbsent(key, ttlSeconds);
    },
    async generation(ns) {
      const r = ready();
      if (r) {
        try {
          const v = await r.get(`gen:${ns}`);
          return v ? Number(v) : 0;
        } catch {
          // fall through
        }
      }
      return memory.generation(ns);
    },
    async bumpGeneration(ns) {
      const local = memory.bump(ns);
      const r = ready();
      if (r) {
        try {
          return await r.incr(`gen:${ns}`);
        } catch {
          return local;
        }
      }
      return local;
    },
    async close() {
      if (redis) {
        redis.disconnect();
      }
    },
  };
}

import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '../generated/prisma/client.js';

export type Db = InstanceType<typeof PrismaClient>;

export function createPrisma(connectionString: string): Db {
  const adapter = new PrismaPg({ connectionString, max: 10, statement_timeout: 10_000 });
  return new PrismaClient({ adapter });
}

export { Prisma } from '../generated/prisma/client.js';
export type * from '../generated/prisma/client.js';

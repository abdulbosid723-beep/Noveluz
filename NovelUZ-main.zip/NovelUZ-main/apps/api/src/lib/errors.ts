import type { ApiErrorCode } from '@noveluz/shared';
import { errorMessages } from '@noveluz/shared';

const STATUS: Readonly<Record<ApiErrorCode, number>> = {
  VALIDATION_ERROR: 422,
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  PAYLOAD_TOO_LARGE: 413,
  UNSUPPORTED_MEDIA: 415,
  RATE_LIMITED: 429,
  MAINTENANCE: 503,
  CSRF_REJECTED: 403,
  INTERNAL_ERROR: 500,
};

export class AppError extends Error {
  readonly code: ApiErrorCode;
  readonly statusCode: number;
  readonly details: Record<string, unknown> | undefined;

  constructor(code: ApiErrorCode, message?: string, details?: Record<string, unknown>) {
    super(message ?? errorMessages[code]);
    this.name = 'AppError';
    this.code = code;
    this.statusCode = STATUS[code];
    this.details = details;
  }
}

export const notFound = (message?: string): AppError => new AppError('NOT_FOUND', message);
export const forbidden = (message?: string, details?: Record<string, unknown>): AppError =>
  new AppError('FORBIDDEN', message, details);
export const unauthenticated = (message?: string): AppError => new AppError('UNAUTHENTICATED', message);
export const conflict = (message?: string, details?: Record<string, unknown>): AppError =>
  new AppError('CONFLICT', message, details);
export const validation = (message: string, fields?: Record<string, string>): AppError =>
  new AppError('VALIDATION_ERROR', message, fields ? { fields } : undefined);

export function statusForCode(code: ApiErrorCode): number {
  return STATUS[code];
}

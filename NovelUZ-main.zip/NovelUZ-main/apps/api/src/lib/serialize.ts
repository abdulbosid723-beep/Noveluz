import type { AssetRef } from '@noveluz/shared';
import { formatChapterNumber } from '@noveluz/shared';

interface AssetLike {
  id: string;
  width: number | null;
  height: number | null;
  deletedAt?: Date | null;
}

export function assetRef(asset: AssetLike | null | undefined): AssetRef | null {
  if (!asset || asset.deletedAt) return null;
  return { id: asset.id, url: `/api/assets/${asset.id}`, width: asset.width, height: asset.height };
}

/** Prisma Decimal / number / string → JS number. */
export function num(value: { toString(): string } | number | string | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === 'number' ? value : Number(value.toString());
}

export function chapterNo(value: { toString(): string } | number | string): string {
  return formatChapterNumber(num(value));
}

export function iso(date: Date | null | undefined): string | null {
  return date ? date.toISOString() : null;
}

/** Raw SQL bigint → number (counts never exceed 2^53 here). */
export function big(value: bigint | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  return typeof value === 'bigint' ? Number(value) : value;
}

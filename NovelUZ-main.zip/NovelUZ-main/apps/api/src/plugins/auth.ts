import type { FastifyInstance, FastifyRequest } from 'fastify';
import fp from 'fastify-plugin';
import type { Role } from '@noveluz/shared';
import type { AuthUser } from '../context.js';
import { forbidden, unauthenticated } from '../lib/errors.js';
import { ACCESS_COOKIE, verifyAccessToken } from '../modules/auth/tokens.js';

function extractToken(request: FastifyRequest): string | null {
  const header = request.headers.authorization;
  if (header?.startsWith('Bearer ')) return header.slice(7).trim() || null;
  const cookie = request.cookies[ACCESS_COOKIE];
  return cookie && cookie.length < 4096 ? cookie : null;
}

/**
 * Resolves `request.auth` from the access token (cookie or Bearer). The token is
 * verified cryptographically AND against the database: the session family must
 * still be active and the user must not be banned, so bans and logouts take
 * effect immediately.
 */
export const authPlugin = fp(async (app: FastifyInstance) => {
  app.decorateRequest('auth', null);
  app.addHook('onRequest', async (request) => {
    request.auth = null;
    const token = extractToken(request);
    if (!token) return;
    const claims = await verifyAccessToken(app.ctx.env.ACCESS_TOKEN_SECRET, token);
    if (!claims) return;
    const session = await app.ctx.prisma.refreshSession.findFirst({
      where: { familyId: claims.familyId, userId: claims.userId, revokedAt: null, expiresAt: { gt: new Date() } },
      select: { id: true, user: { select: { id: true, username: true, role: true, isBanned: true } } },
    });
    if (!session || session.user.isBanned) return;
    request.auth = {
      id: session.user.id,
      username: session.user.username,
      // The DB role is authoritative (role changes apply without waiting for token expiry).
      role: session.user.role,
      sessionId: claims.familyId,
    };
  });
});

export function requireUser(request: FastifyRequest): AuthUser {
  if (!request.auth) throw unauthenticated();
  return request.auth;
}

export function requireRole(request: FastifyRequest, roles: readonly Role[]): AuthUser {
  const user = requireUser(request);
  if (!roles.includes(user.role)) throw forbidden();
  return user;
}

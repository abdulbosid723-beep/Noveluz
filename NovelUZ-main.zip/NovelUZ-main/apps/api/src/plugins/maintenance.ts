import type { FastifyInstance } from 'fastify';
import fp from 'fastify-plugin';
import { STAFF_ROLES } from '@noveluz/shared';
import { AppError } from '../lib/errors.js';
import { getSettings } from '../services/settings.service.js';

/**
 * Maintenance mode: public API routes answer 503 MAINTENANCE while staff
 * (translator/moderator/admin) keep working. Health, auth, settings and admin
 * routes opt out via `config.allowDuringMaintenance`.
 */
export const maintenancePlugin = fp(async (app: FastifyInstance) => {
  app.addHook('preHandler', async (request) => {
    // Unmatched routes (404 handler) and opted-out routes never hit the settings table.
    if (!request.routeOptions.url || request.routeOptions.config.allowDuringMaintenance) return;
    const settings = await getSettings(app.ctx.prisma);
    if (!settings.maintenanceMode) return;
    if (request.auth && STAFF_ROLES.includes(request.auth.role)) return;
    throw new AppError('MAINTENANCE', settings.maintenanceMessage ?? undefined);
  });
});

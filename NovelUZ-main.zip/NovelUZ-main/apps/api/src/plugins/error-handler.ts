import type { FastifyError, FastifyInstance } from 'fastify';
import { hasZodFastifySchemaValidationErrors } from 'fastify-type-provider-zod';
import { ZodError } from 'zod';
import { errorMessages } from '@noveluz/shared';
import type { ApiErrorBody, ApiErrorCode } from '@noveluz/shared';
import { AppError } from '../lib/errors.js';
import { Prisma } from '../lib/prisma.js';

function body(code: ApiErrorCode, message: string, requestId: string, details?: Record<string, unknown>): ApiErrorBody {
  return details ? { error: { code, message, details }, requestId } : { error: { code, message }, requestId };
}

function zodFields(issues: ReadonlyArray<{ path: PropertyKey[]; message: string }>): Record<string, string> {
  const fields: Record<string, string> = {};
  for (const issue of issues) {
    const key = issue.path.map(String).join('.') || '_';
    if (!(key in fields)) fields[key] = issue.message;
  }
  return fields;
}

/** The single centralized error handler: stable codes, no stack traces or SQL in responses. */
export function registerErrorHandler(app: FastifyInstance): void {
  app.setErrorHandler((error: FastifyError, request, reply) => {
    const requestId = request.id;

    if (error instanceof AppError) {
      if (error.code === 'RATE_LIMITED' && error.details?.retryAfterSeconds) {
        void reply.header('Retry-After', String(Number(error.details.retryAfterSeconds)));
      }
      return reply.status(error.statusCode).send(body(error.code, error.message, requestId, error.details));
    }

    if (hasZodFastifySchemaValidationErrors(error)) {
      const fields: Record<string, string> = {};
      for (const v of error.validation) {
        const path = v.instancePath.replace(/^\//, '').replace(/\//g, '.') || '_';
        if (!(path in fields)) fields[path] = v.message ?? errorMessages.VALIDATION_ERROR;
      }
      return reply.status(422).send(
        body('VALIDATION_ERROR', errorMessages.VALIDATION_ERROR, requestId, {
          fields,
          location: error.validationContext,
        }),
      );
    }

    if (error instanceof ZodError) {
      return reply
        .status(422)
        .send(body('VALIDATION_ERROR', errorMessages.VALIDATION_ERROR, requestId, { fields: zodFields(error.issues) }));
    }

    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        const target = (error.meta?.target ?? error.meta?.modelName ?? null) as unknown;
        return reply
          .status(409)
          .send(body('CONFLICT', errorMessages.CONFLICT, requestId, target ? { target } : undefined));
      }
      if (error.code === 'P2025') {
        return reply.status(404).send(body('NOT_FOUND', errorMessages.NOT_FOUND, requestId));
      }
      if (error.code === 'P2003') {
        return reply.status(409).send(body('CONFLICT', 'Bog‘liq ma’lumot topilmadi yoki ishlatilmoqda', requestId));
      }
    }

    const statusCode = typeof error.statusCode === 'number' ? error.statusCode : 500;
    if (statusCode === 429) {
      return reply.status(429).send(body('RATE_LIMITED', errorMessages.RATE_LIMITED, requestId));
    }
    if (statusCode === 413 || error.code === 'FST_REQ_FILE_TOO_LARGE' || error.code === 'FST_FILES_LIMIT') {
      return reply.status(413).send(body('PAYLOAD_TOO_LARGE', errorMessages.PAYLOAD_TOO_LARGE, requestId));
    }
    if (statusCode === 415 || error.code === 'FST_ERR_CTP_INVALID_MEDIA_TYPE') {
      return reply.status(415).send(body('UNSUPPORTED_MEDIA', errorMessages.UNSUPPORTED_MEDIA, requestId));
    }
    if (statusCode >= 400 && statusCode < 500) {
      const code: ApiErrorCode = statusCode === 404 ? 'NOT_FOUND' : 'VALIDATION_ERROR';
      return reply.status(statusCode === 404 ? 404 : 400).send(body(code, errorMessages[code], requestId));
    }

    request.log.error({ err: error }, 'unhandled error');
    return reply.status(500).send(body('INTERNAL_ERROR', errorMessages.INTERNAL_ERROR, requestId));
  });

  app.setNotFoundHandler((request, reply) =>
    reply.status(404).send(body('NOT_FOUND', errorMessages.NOT_FOUND, request.id)),
  );
}

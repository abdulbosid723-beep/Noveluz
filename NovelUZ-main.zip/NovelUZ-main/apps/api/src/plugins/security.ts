import type { FastifyInstance } from 'fastify';
import fp from 'fastify-plugin';
import { AppError } from '../lib/errors.js';
import { REFRESH_COOKIE, ACCESS_COOKIE } from '../modules/auth/tokens.js';

export const CSRF_HEADER = 'x-noveluz-csrf';
const MUTATING = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/**
 * CSRF defense for cookie-authenticated mutations (documented in docs/SECURITY.md):
 *  1. Cookies are SameSite=Lax + httpOnly.
 *  2. Mutations carrying our cookies must send an Origin (or Referer) equal to APP_ORIGIN.
 *  3. They must also send the custom `X-NovelUZ-CSRF: 1` header, which cross-site
 *     forms cannot set and cross-origin scripts cannot send without a CORS preflight
 *     that our strict CORS policy rejects.
 * Bearer-token clients without cookies are not subject to CSRF and skip the check.
 */
export const csrfPlugin = fp(async (app: FastifyInstance) => {
  const allowedOrigin = new URL(app.ctx.env.APP_ORIGIN).origin;
  app.addHook('onRequest', async (request) => {
    if (!MUTATING.has(request.method)) return;
    const hasSessionCookie = Boolean(request.cookies[ACCESS_COOKIE] || request.cookies[REFRESH_COOKIE]);
    if (!hasSessionCookie) return;
    const origin = request.headers.origin;
    let source: string | null = null;
    if (typeof origin === 'string' && origin !== 'null') {
      source = origin;
    } else if (typeof request.headers.referer === 'string') {
      try {
        source = new URL(request.headers.referer).origin;
      } catch {
        source = null;
      }
    }
    if (source !== allowedOrigin || request.headers[CSRF_HEADER] !== '1') {
      throw new AppError('CSRF_REJECTED');
    }
  });
});

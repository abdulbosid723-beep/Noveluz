import { z } from 'zod';

const booleanFlag = z
  .enum(['true', 'false', '1', '0', ''])
  .default('false')
  .transform((v) => v === 'true' || v === '1');

const EnvSchema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    DATABASE_URL: z.url({ message: 'DATABASE_URL must be a postgresql:// URL' }),
    REDIS_URL: z.string().optional().default(''),
    API_PORT: z.coerce.number().int().min(1).max(65535).default(4000),
    APP_ORIGIN: z.url().default('http://localhost:3000'),
    ACCESS_TOKEN_SECRET: z.string().min(32, 'ACCESS_TOKEN_SECRET must be at least 32 characters'),
    REFRESH_TOKEN_SECRET: z.string().min(32, 'REFRESH_TOKEN_SECRET must be at least 32 characters'),
    COOKIE_DOMAIN: z.string().optional().default(''),
    STORAGE_DRIVER: z.enum(['local', 's3']).default('local'),
    UPLOAD_DIR: z.string().default('./.data/uploads'),
    S3_ENDPOINT: z.string().optional().default(''),
    S3_BUCKET: z.string().optional().default(''),
    S3_REGION: z.string().optional().default(''),
    S3_ACCESS_KEY_ID: z.string().optional().default(''),
    S3_SECRET_ACCESS_KEY: z.string().optional().default(''),
    LOG_LEVEL: z.preprocess(
      (v) => (typeof v === 'string' ? v.toLowerCase() : v),
      z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
    ),
    /** Comma-separated proxy IPs/CIDRs whose X-Forwarded-For is trusted (the web server / reverse proxy). */
    TRUST_PROXY: z.string().default('127.0.0.1,::1,::ffff:127.0.0.1'),
    /** Scales every rate limit (1 = documented production limits). Tests raise it; never set >1 in production. */
    RATE_LIMIT_MULTIPLIER: z.coerce.number().min(1).max(10_000).default(1),
    FEATURE_RECOMMENDATIONS: booleanFlag,
    FEATURE_PWA: booleanFlag,
  })
  .superRefine((env, ctx) => {
    if (env.NODE_ENV === 'production') {
      for (const key of ['ACCESS_TOKEN_SECRET', 'REFRESH_TOKEN_SECRET'] as const) {
        if (env[key].startsWith('dev-only')) {
          ctx.addIssue({ code: 'custom', path: [key], message: `${key} still uses the development value` });
        }
      }
      if (!env.APP_ORIGIN.startsWith('https://')) {
        ctx.addIssue({ code: 'custom', path: ['APP_ORIGIN'], message: 'APP_ORIGIN must be https in production' });
      }
    }
    if (env.STORAGE_DRIVER === 's3') {
      for (const key of [
        'S3_ENDPOINT',
        'S3_BUCKET',
        'S3_REGION',
        'S3_ACCESS_KEY_ID',
        'S3_SECRET_ACCESS_KEY',
      ] as const) {
        if (!env[key])
          ctx.addIssue({ code: 'custom', path: [key], message: `${key} is required when STORAGE_DRIVER=s3` });
      }
    }
  });

export type Env = z.infer<typeof EnvSchema>;

/** Parses env vars and fails fast with actionable messages (never prints values). */
export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const parsed = EnvSchema.safeParse(source);
  if (!parsed.success) {
    const lines = parsed.error.issues.map((i) => `  - ${i.path.join('.') || '(root)'}: ${i.message}`);
    throw new Error(`Invalid environment configuration:\n${lines.join('\n')}\nSee .env.example.`);
  }
  return parsed.data;
}

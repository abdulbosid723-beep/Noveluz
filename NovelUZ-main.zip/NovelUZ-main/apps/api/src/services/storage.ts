import { createReadStream } from 'node:fs';
import { mkdir, rm, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import type { Readable } from 'node:stream';

/** Storage adapter for registered UploadAsset blobs. Keys are opaque and server-generated. */
export interface Storage {
  readonly driver: 'local' | 's3';
  put(key: string, data: Buffer, contentType: string): Promise<void>;
  get(key: string): Promise<{ stream: Readable; bytes: number } | null>;
  remove(key: string): Promise<void>;
}

const SAFE_KEY = /^[a-z0-9][a-z0-9/_-]*\.(webp|png|jpg|jpeg|avif)$/;

export function assertSafeKey(key: string): void {
  if (!SAFE_KEY.test(key) || key.includes('..') || key.includes('//')) {
    throw new Error('unsafe storage key');
  }
}

export function createLocalStorage(rootDir: string): Storage {
  const root = path.resolve(rootDir);
  const resolve = (key: string): string => {
    assertSafeKey(key);
    const full = path.resolve(root, key);
    if (!full.startsWith(root + path.sep)) throw new Error('storage path traversal rejected');
    return full;
  };
  return {
    driver: 'local',
    async put(key, data) {
      const full = resolve(key);
      await mkdir(path.dirname(full), { recursive: true });
      await writeFile(full, data, { flag: 'w' });
    },
    async get(key) {
      const full = resolve(key);
      try {
        const st = await stat(full);
        return { stream: createReadStream(full), bytes: st.size };
      } catch {
        return null;
      }
    },
    async remove(key) {
      await rm(resolve(key), { force: true });
    },
  };
}

import type { SettingsPatch, SiteSettingsDto } from '@noveluz/shared';
import type { Db } from '../lib/prisma.js';

let cached: { value: SiteSettingsDto; at: number } | null = null;
const TTL_MS = 3000;

function toDto(row: {
  announcementText: string | null;
  announcementActive: boolean;
  maintenanceMode: boolean;
  maintenanceMessage: string | null;
  updatedAt: Date;
}): SiteSettingsDto {
  return {
    announcementText: row.announcementText,
    announcementActive: row.announcementActive,
    maintenanceMode: row.maintenanceMode,
    maintenanceMessage: row.maintenanceMessage,
    updatedAt: row.updatedAt.toISOString(),
  };
}

/** Singleton settings row (id = 1, enforced by CHECK constraint and upsert). */
export async function getSettings(prisma: Db, fresh = false): Promise<SiteSettingsDto> {
  if (!fresh && cached && Date.now() - cached.at < TTL_MS) return cached.value;
  const row = await prisma.siteSettings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  const value = toDto(row);
  cached = { value, at: Date.now() };
  return value;
}

export async function updateSettings(prisma: Db, patch: SettingsPatch): Promise<SiteSettingsDto> {
  const row = await prisma.siteSettings.upsert({
    where: { id: 1 },
    update: patch,
    create: { id: 1, ...patch },
  });
  const value = toDto(row);
  cached = { value, at: Date.now() };
  return value;
}

export function resetSettingsCache(): void {
  cached = null;
}

import cookie from '@fastify/cookie';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import multipart from '@fastify/multipart';
import rateLimit from '@fastify/rate-limit';
import swagger from '@fastify/swagger';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { jsonSchemaTransform, serializerCompiler, validatorCompiler } from 'fastify-type-provider-zod';
import { randomUUID } from 'node:crypto';
import { LIMITS } from '@noveluz/shared';
import type { Env } from './config/env.js';
import type { AppContext } from './context.js';
import { createCache } from './lib/cache.js';
import type { Cache } from './lib/cache.js';
import { AppError } from './lib/errors.js';
import { createPrisma } from './lib/prisma.js';
import type { Db } from './lib/prisma.js';
import { registerRoutes } from './routes.js';
import { authPlugin } from './plugins/auth.js';
import { registerErrorHandler } from './plugins/error-handler.js';
import { maintenancePlugin } from './plugins/maintenance.js';
import { csrfPlugin, CSRF_HEADER } from './plugins/security.js';
import { createLocalStorage } from './services/storage.js';
import type { Storage } from './services/storage.js';

export interface BuildOptions {
  env: Env;
  prisma?: Db;
  cache?: Cache;
  storage?: Storage;
  logger?: boolean;
}

export async function buildApp(options: BuildOptions): Promise<FastifyInstance> {
  const { env } = options;
  const app = Fastify({
    logger:
      options.logger === false
        ? false
        : {
            level: env.LOG_LEVEL,
            redact: {
              paths: [
                'req.headers.authorization',
                'req.headers.cookie',
                'res.headers["set-cookie"]',
                '*.password',
                '*.passwordHash',
                '*.token',
              ],
              censor: '[redacted]',
            },
          },
    genReqId: () => randomUUID(),
    requestIdHeader: false,
    trustProxy: env.TRUST_PROXY.split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    bodyLimit: 1024 * 1024 * 2,
  });

  app.setValidatorCompiler(validatorCompiler);
  app.setSerializerCompiler(serializerCompiler);

  const prisma = options.prisma ?? createPrisma(env.DATABASE_URL);
  const cache = options.cache ?? createCache(env.REDIS_URL, app.log);
  const storage = options.storage ?? createLocalStorage(env.UPLOAD_DIR);
  const ctx: AppContext = { env, prisma, cache, storage };
  app.decorate('ctx', ctx);

  app.addHook('onSend', async (request, reply) => {
    void reply.header('x-request-id', request.id);
  });

  registerErrorHandler(app);

  await app.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'none'"],
        imgSrc: ["'self'", 'data:'],
        frameAncestors: ["'none'"],
      },
    },
    crossOriginResourcePolicy: { policy: 'same-site' },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    hsts: env.NODE_ENV === 'production',
  });
  await app.register(cors, {
    origin: [new URL(env.APP_ORIGIN).origin],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['content-type', 'authorization', CSRF_HEADER],
    maxAge: 600,
  });
  await app.register(cookie);
  await app.register(rateLimit, {
    global: false,
    errorResponseBuilder: (_request, context) =>
      new AppError('RATE_LIMITED', undefined, { retryAfterSeconds: Math.ceil(context.ttl / 1000) }),
  });
  await app.register(multipart, {
    limits: { fileSize: LIMITS.uploadMaxBytes, files: 1, fields: 5, parts: 8 },
  });
  await app.register(swagger, {
    openapi: {
      openapi: '3.1.0',
      info: { title: 'NovelUZ API', version: '0.1.0', description: 'NovelUZ REST API (Uzbek reading platform)' },
    },
    transform: jsonSchemaTransform,
  });

  await app.register(csrfPlugin);
  await app.register(authPlugin);
  await app.register(maintenancePlugin);

  await registerRoutes(app);

  app.addHook('onClose', async () => {
    await cache.close();
    if (!options.prisma) await prisma.$disconnect();
  });

  return app;
}

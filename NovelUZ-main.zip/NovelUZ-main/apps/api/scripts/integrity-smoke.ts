/**
 * Live production-integrity smoke test: runs the REAL Fastify app over HTTP
 * against the TEST PostgreSQL database, writes a record, restarts the API
 * (new process-level app + new Prisma pool), reads the record back, cleans up.
 */
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { buildApp } from '../src/app.js';
import { loadEnv } from '../src/config/env.js';
import { createPrisma } from '../src/lib/prisma.js';

const rootEnv = path.resolve(import.meta.dirname, '../../../.env');
if (existsSync(rootEnv)) process.loadEnvFile(rootEnv);
const url = process.env.TEST_DATABASE_URL;
if (!url) throw new Error('TEST_DATABASE_URL is required');

execFileSync('pnpm', ['exec', 'prisma', 'migrate', 'deploy'], {
  cwd: path.resolve(import.meta.dirname, '..'),
  env: { ...process.env, DATABASE_URL: url },
  stdio: ['ignore', 'ignore', 'inherit'],
});

const env = loadEnv({ ...process.env, NODE_ENV: 'test', DATABASE_URL: url, REDIS_URL: '', LOG_LEVEL: 'silent' });
const origin = env.APP_ORIGIN;

async function start(): Promise<{ base: string; close: () => Promise<void> }> {
  const app = await buildApp({ env, logger: false });
  const address = await app.listen({ port: 0, host: '127.0.0.1' });
  return { base: address, close: () => app.close() };
}

function check(condition: boolean, message: string): void {
  if (!condition) throw new Error(`integrity smoke failed: ${message}`);
  process.stdout.write(`    ✓ ${message}\n`);
}

const username = `smoke_${Date.now().toString(36)}`;
const password = `Smoke-${Date.now().toString(36)}-pass1`;
const headers = { 'content-type': 'application/json', origin, 'x-noveluz-csrf': '1' };

const first = await start();
const ready = await fetch(`${first.base}/health/ready`);
const readyBody = (await ready.json()) as { database?: string };
check(ready.status === 200 && readyBody.database === 'up', 'GET /health/ready reports database up over real HTTP');

const register = await fetch(`${first.base}/api/auth/register`, {
  method: 'POST',
  headers,
  body: JSON.stringify({ username, email: `${username}@example.test`, password }),
});
check(register.status === 201, `POST /api/auth/register persisted a user (status ${register.status})`);
await first.close();

const second = await start();
const login = await fetch(`${second.base}/api/auth/login`, {
  method: 'POST',
  headers,
  body: JSON.stringify({ login: username, password }),
});
check(login.status === 200, `user still exists after API restart (login status ${login.status})`);
const cookies = login.headers
  .getSetCookie()
  .map((c) => c.split(';')[0])
  .join('; ');
const me = await fetch(`${second.base}/api/auth/me`, { headers: { cookie: cookies } });
const meBody = (await me.json()) as { data?: { username?: string } };
check(me.status === 200 && meBody.data?.username === username, 'GET /api/auth/me reads the persisted user');
await second.close();

const prisma = createPrisma(url);
const deleted = await prisma.user.deleteMany({ where: { usernameNormalized: username } });
await prisma.$disconnect();
check(deleted.count === 1, 'cleanup removed the smoke-test user');

/**
 * Prepares the isolated TEST database for browser E2E runs:
 * drop schema → `prisma migrate deploy` → demo seed → E2E-only accounts.
 * Never touches DATABASE_URL (the development database).
 */
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import pg from 'pg';

const rootEnv = path.resolve(import.meta.dirname, '../../../.env');
if (existsSync(rootEnv)) process.loadEnvFile(rootEnv);
const url = process.env.TEST_DATABASE_URL;
if (!url) throw new Error('TEST_DATABASE_URL is required');
if (url === process.env.DATABASE_URL) throw new Error('TEST_DATABASE_URL must differ from DATABASE_URL');

const client = new pg.Client({ connectionString: url });
await client.connect();
await client.query('DROP SCHEMA IF EXISTS public CASCADE');
await client.query('CREATE SCHEMA public');
await client.end();

const apiDir = path.resolve(import.meta.dirname, '..');
const env = { ...process.env, DATABASE_URL: url, NODE_ENV: 'test' };
execFileSync('pnpm', ['exec', 'prisma', 'migrate', 'deploy'], {
  cwd: apiDir,
  env,
  stdio: ['ignore', 'ignore', 'inherit'],
});
const seed = path.join(apiDir, 'prisma', 'seed.ts');
if (existsSync(seed)) {
  execFileSync('pnpm', ['exec', 'tsx', 'prisma/seed.ts', '--e2e'], {
    cwd: apiDir,
    env: { ...env, UPLOAD_DIR: path.resolve(apiDir, '../../.data/e2e-uploads') },
    stdio: 'inherit',
  });
}
process.stdout.write('[e2e] test database prepared\n');
